(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
'use strict';

module.exports = {
	Footer: require('./views/templates/Footer'),
	Header: require('./views/templates/Header'),
	Home: require('./views/templates/Home'),
	Internet: require('./views/templates/Internet'),
	Services: require('./views/templates/Services'),
	Toast: require('./views/templates/Toast'),
	ToastMessage: require('./views/templates/ToastMessage')
};

},{"./views/templates/Footer":17,"./views/templates/Header":18,"./views/templates/Home":19,"./views/templates/Internet":20,"./views/templates/Services":21,"./views/templates/Toast":27,"./views/templates/ToastMessage":28}],2:[function(require,module,exports){
'use strict';

module.exports = {
	Footer: require('./views/Footer'),
	Header: require('./views/Header'),
	Home: require('./views/Home'),
	Internet: require('./views/Internet'),
	Services: require('./views/Services'),
	Toast: require('./views/Toast'),
	ToastMessage: require('./views/ToastMessage')
};

},{"./views/Footer":10,"./views/Header":11,"./views/Home":12,"./views/Internet":13,"./views/Services":14,"./views/Toast":31,"./views/ToastMessage":32}],3:[function(require,module,exports){
"use strict";

module.exports = Object.create(Object.assign({}, require('../../lib/MyObject'), {

    Request: {
        constructor: function constructor(data) {
            var _this = this;

            var req = new XMLHttpRequest();

            if (data.onProgress) req.addEventListener("progress", function (e) {
                return data.onProgress(e.lengthComputable ? Math.floor(e.loaded / e.total * 100) : 0);
            });

            return new Promise(function (resolve, reject) {

                req.onload = function () {
                    [500, 404, 401].includes(this.status) ? reject(JSON.parse(this.response)) : resolve(JSON.parse(this.response));
                };

                if (data.method === "get" || data.method === "options") {
                    var qs = data.qs ? "?" + data.qs : '';
                    req.open(data.method, "/" + data.resource + qs);
                    _this.setHeaders(req, data.headers);
                    req.send(null);
                } else {
                    var path = "/" + data.resource + (data.id ? "/" + data.id : '');
                    req.open(data.method.toUpperCase(), path, true);
                    _this.setHeaders(req, data.headers);
                    req.send(data.data || null);
                }

                if (data.onProgress) data.onProgress('sent');
            });
        },
        plainEscape: function plainEscape(sText) {
            /* how should I treat a text/plain form encoding? what characters are not allowed? this is what I suppose...: */
            /* "4\3\7 - Einstein said E=mc2" ----> "4\\3\\7\ -\ Einstein\ said\ E\=mc2" */
            return sText.replace(/[\s\=\\]/g, "\\$&");
        },
        setHeaders: function setHeaders(req) {
            var headers = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

            req.setRequestHeader("Accept", headers.accept || 'application/json');
            req.setRequestHeader("Content-Type", headers.contentType || 'text/plain');
        }
    },

    _factory: function _factory(data) {
        return Object.create(this.Request, {}).constructor(data);
    },
    constructor: function constructor() {

        if (!XMLHttpRequest.prototype.sendAsBinary) {
            XMLHttpRequest.prototype.sendAsBinary = function (sData) {
                var nBytes = sData.length,
                    ui8Data = new Uint8Array(nBytes);
                for (var nIdx = 0; nIdx < nBytes; nIdx++) {
                    ui8Data[nIdx] = sData.charCodeAt(nIdx) & 0xff;
                }
                this.send(ui8Data);
            };
        }

        return this._factory.bind(this);
    }
}), {}).constructor();

},{"../../lib/MyObject":24}],4:[function(require,module,exports){
'use strict';

module.exports = Object.create({
    create: function create(name, opts) {
        var lower = name;
        name = name.charAt(0).toUpperCase() + name.slice(1);
        return Object.create(this.Views[name], Object.assign({
            Toast: { value: this.Toast },
            name: { value: name },
            factory: { value: this },
            template: { value: this.Templates[name] }
        }, opts)).constructor();
    }
}, {
    Templates: { value: require('../.TemplateMap') },
    Toast: { value: require('../views/Toast') },
    Views: { value: require('../.ViewMap') }
});

},{"../.TemplateMap":1,"../.ViewMap":2,"../views/Toast":31}],5:[function(require,module,exports){
'use strict';

var router = require('./router'),
    onLoad = new Promise(function (resolve) {
    return window.onload = function () {
        return resolve();
    };
});

require('./polyfill');

onLoad.then(function () {
    return router.initialize();
}).catch(function (e) {
    return console.log('Error initializing client -> ' + (e.stack || e));
});

},{"./polyfill":8,"./router":9}],6:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('./__proto__'), {

    data: {},

    fields: {
        name: {
            error: 'Please enter your name'
        },
        contact: {
            error: 'Please enter a valid email address or phone number'
        }
    },

    resource: 'person',

    validate: function validate(field, value) {
        var val = value.trim();

        if (field === 'name' && val === "") return false;

        if (field === 'contact' && !this._emailRegex.test(val) && !this._phoneRegex.test(val)) return false;

        return true;
    },


    _emailRegex: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,

    _phoneRegex: /^\(?(\d{3})\)?[-. ]?(\d{3})[-. ]?(\d{4})$/

});

},{"./__proto__":7}],7:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('../../../lib/MyObject'), require('../../../lib/Model'), require('events').EventEmitter.prototype, {

    Xhr: require('../Xhr'),

    delete: function _delete(id) {
        var _this = this;

        return this.Xhr({ method: 'DELETE', resource: this.resource, id: id }).then(function (id) {
            var datum = _this.data.find(function (datum) {
                return datum.id == id;
            });

            if (_this.store) {
                Object.keys(_this.store).forEach(function (attr) {
                    _this.store[attr][datum[attr]] = _this.store[attr][datum[attr]].filter(function (datum) {
                        return datum.id != id;
                    });
                    if (_this.store[attr][datum[attr]].length === 0) {
                        _this.store[attr][datum[attr]] = undefined;
                    }
                });
            }

            _this.data = _this.data.filter(function (datum) {
                return datum.id != id;
            });
            if (_this.ids) delete _this.ids[id];

            return Promise.resolve(id);
        });
    },
    get: function get() {
        var _this2 = this;

        var opts = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : { query: {} };

        if (opts.query || this.pagination) Object.assign(opts.query, this.pagination);

        return this.Xhr({ method: opts.method || 'get', resource: this.resource, headers: this.headers || {}, qs: opts.query ? JSON.stringify(opts.query) : undefined }).then(function (response) {

            if (opts.storeBy) {
                _this2.store = {};
                opts.storeBy.forEach(function (attr) {
                    return _this2.store[attr] = {};
                });
            }

            _this2.data = _this2.parse ? _this2.parse(response, opts.storeBy) : opts.storeBy ? _this2.storeBy(response) : response;

            _this2.emit('got');

            return Promise.resolve(_this2.data);
        });
    },
    patch: function patch(id, data) {
        var _this3 = this;

        var opts = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

        return this.Xhr({ method: 'patch', id: id, resource: this.resource, headers: this.headers || {}, data: JSON.stringify(data || this.data) }).then(function (response) {
            if (Array.isArray(_this3.data)) {
                _this3.data = _this3.data ? _this3.data.concat(response) : [response];
                if (_this3.store) Object.keys(_this3.store).forEach(function (attr) {
                    return _this3._store(response, attr);
                });
            }

            return Promise.resolve(response);
        });
    },
    post: function post(model) {
        var _this4 = this;

        var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

        return this.Xhr({ method: 'post', resource: this.resource, headers: this.headers || {}, data: JSON.stringify(model || this.data) }).then(function (response) {
            if (Array.isArray(_this4.data)) {
                _this4.data = _this4.data ? _this4.data.concat(response) : [response];
                if (_this4.store) Object.keys(_this4.store).forEach(function (attr) {
                    return _this4._store(response, attr);
                });
            }

            return Promise.resolve(response);
        });
    },
    storeBy: function storeBy(data) {
        var _this5 = this;

        data.forEach(function (datum) {
            return Object.keys(_this5.store).forEach(function (attr) {
                return _this5._store(datum, attr);
            });
        });

        return data;
    },
    _store: function _store(datum, attr) {
        if (!this.store[attr][datum[attr]]) this.store[attr][datum[attr]] = [];
        this.store[attr][datum[attr]].push(datum);
    }
});

},{"../../../lib/Model":22,"../../../lib/MyObject":24,"../Xhr":3,"events":25}],8:[function(require,module,exports){
'use strict';

//https://developer.mozilla.org/en-US/docs/Web/API/Element/closest
if (window.Element && !Element.prototype.closest) {
    Element.prototype.closest = function (s) {
        var matches = (this.document || this.ownerDocument).querySelectorAll(s),
            i,
            el = this;
        do {
            i = matches.length;
            while (--i >= 0 && matches.item(i) !== el) {};
        } while (i < 0 && (el = el.parentElement));
        return el;
    };
}

//https://gist.github.com/paulirish/1579671
var requestAnimationFramePolyfill = function () {
    var clock = Date.now();

    return function (callback) {

        var currentTime = Date.now();

        if (currentTime - clock > 16) {
            clock = currentTime;
            callback(currentTime);
        } else {
            setTimeout(function () {
                polyfill(callback);
            }, 0);
        }
    };
}();

window.requestAnimationFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || requestAnimationFramePolyfill;

require('smoothscroll-polyfill').polyfill();

module.exports = true;

},{"smoothscroll-polyfill":26}],9:[function(require,module,exports){
'use strict';

module.exports = Object.create({

    Error: require('../../lib/MyError'),

    ViewFactory: require('./factory/View'),

    Views: require('./.ViewMap'),

    Toast: require('./views/Toast'),

    capitalizeFirstLetter: function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    },

    initialize: function initialize() {
        var _this = this;

        this.contentContainer = document.querySelector('#content');

        this.Toast.constructor();

        window.onpopstate = this.handle.bind(this);

        this.header = this.ViewFactory.create('header', { insertion: { value: { el: this.contentContainer, method: 'insertBefore' } } }).on('navigate', function (route) {
            return _this.navigate(route);
        });

        this.footer = this.ViewFactory.create('footer', { insertion: { value: { el: this.contentContainer, method: 'after' } } });

        this.handle();
    },
    handle: function handle() {
        this.handler(window.location.pathname.split('/').slice(1));
    },
    handler: function handler(path) {
        var _this2 = this;

        var view = this.Views[this.capitalizeFirstLetter(path[0])] ? path[0] : 'home';

        if (view === this.currentView) return this.views[view].onNavigation(path);

        this.scrollToTop();

        Promise.all(Object.keys(this.views).map(function (view) {
            return _this2.views[view].hide();
        })).then(function () {

            _this2.currentView = view;

            if (_this2.views[view]) return _this2.views[view].onNavigation(path);

            return Promise.resolve(_this2.views[view] = _this2.ViewFactory.create(view, {
                insertion: { value: { el: _this2.contentContainer } },
                path: { value: path, writable: true }
            }).on('navigate', function (route) {
                return _this2.navigate(route);
            }).on('deleted', function () {
                return delete _this2.views[view];
            }));
        }).catch(this.Error);
    },
    navigate: function navigate(location) {
        if (location !== window.location.pathname) history.pushState({}, '', location);
        this.handle();
    },
    scrollToTop: function scrollToTop() {
        window.scroll({ top: 0, left: 0, behavior: 'smooth' });
    }
}, { currentView: { value: '', writable: true }, views: { value: {} } });

},{"../../lib/MyError":23,"./.ViewMap":2,"./factory/View":4,"./views/Toast":31}],10:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('./__proto__'), {});

},{"./__proto__":15}],11:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('./__proto__'), {

    events: {
        nav: 'click'
    },

    onNavClick: function onNavClick(e) {
        var itemEl = e.target.tagName === "LI" ? e.target : e.target.closest('li'),
            name = itemEl.getAttribute('data-name');

        this.emit('navigate', name);
    }
});

},{"./__proto__":15}],12:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('./__proto__'), {

    events: {
        services: 'click',
        internet: 'click'
    },

    onInternetClick: function onInternetClick() {
        this.emit('navigate', 'internet');
    },
    onServicesClick: function onServicesClick() {
        this.emit('navigate', 'services');
    }
});

},{"./__proto__":15}],13:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('./__proto__'), {

    events: {
        'submitBtn': 'click'
    },

    model: Object.create(require('../models/Person')),

    clearForm: function clearForm() {
        this.els.name.value = '';
        this.els.contact.value = '';
        this.els.address.value = '';
    },
    onSubmitBtnClick: function onSubmitBtnClick() {
        var _this = this;

        if (this.submitting) return;

        this.onSubmitStart();

        this.validate().then(function (result) {
            if (!result) return Promise.resolve(_this.onSubmitEnd());

            return _this.model.post().then(function (response) {
                return _this.Toast.createMessage('success', "Info sent! We'll keep you posted!").then(function () {
                    _this.emit('navigate', '/');
                    _this.onSubmitEnd();
                    _this.clearForm();
                });
            }).catch(function (e) {
                _this.Toast.createMessage('error', e && e.message ? e.message : 'There was a problem. Please try again or contact us.');
                _this.onSubmitEnd();
            });
        }).catch(function (e) {
            _this.Error(e);_this.submitting = false;
        });
    },
    onSubmitEnd: function onSubmitEnd() {
        this.submitting = false;
        this.els.submitBtn.classList.remove('submitting');
    },
    onSubmitStart: function onSubmitStart() {
        this.submitting = true;
        this.els.submitBtn.classList.add('submitting');
    },
    postRender: function postRender() {
        var _this2 = this;

        Object.keys(this.els).forEach(function (attr) {
            var el = _this2.els[attr];

            if (attr === 'name' || attr === 'contact') el.addEventListener('focus', function () {
                return el.classList.remove('error');
            });
        });

        return this;
    },
    validate: function validate() {
        var _this3 = this;

        var rv = true;

        Object.keys(this.els).forEach(function (attr) {
            var el = _this3.els[attr];

            if (attr !== 'name' && attr !== 'contact') return;

            if (rv === true && !_this3.model.validate(attr, el.value)) {
                _this3.Toast.createMessage('error', _this3.model.fields[attr].error);
                el.scrollIntoView({ behavior: 'smooth' });
                el.classList.add('error');
                rv = false;
            } else if (_this3.model.validate(attr, el.value)) {
                _this3.model.data[attr] = el.value.trim();
            }
        });

        return Promise.resolve(rv);
    }
});

},{"../models/Person":6,"./__proto__":15}],14:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('./__proto__'), {});

},{"./__proto__":15}],15:[function(require,module,exports){
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

module.exports = Object.assign({}, require('../../../lib/MyObject'), require('events').EventEmitter.prototype, {

    Model: require('../models/__proto__'),

    OptimizedResize: require('./lib/OptimizedResize'),

    bindEvent: function bindEvent(key, event, el) {
        var _this = this;

        var els = el ? [el] : Array.isArray(this.els[key]) ? this.els[key] : [this.els[key]];
        els.forEach(function (el) {
            return el.addEventListener(event || 'click', function (e) {
                return _this['on' + _this.capitalizeFirstLetter(key) + _this.capitalizeFirstLetter(event)](e);
            });
        });
    },


    capitalizeFirstLetter: function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    },

    constructor: function constructor() {
        this.subviewElements = [];

        if (this.requiresLogin && !this.user.isLoggedIn()) return this.handleLogin();
        if (this.user && !this.isAllowed(this.user)) return this.scootAway();

        return this.initialize().render();
    },
    delegateEvents: function delegateEvents(key, el) {
        var _this2 = this;

        var type = _typeof(this.events[key]);

        if (type === "string") {
            this.bindEvent(key, this.events[key], el);
        } else if (Array.isArray(this.events[key])) {
            this.events[key].forEach(function (eventObj) {
                return _this2.bindEvent(key, eventObj);
            });
        } else {
            this.bindEvent(key, this.events[key].event);
        }
    },
    delete: function _delete(isSlow) {
        var _this3 = this;

        var animate = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

        return this.hide(isSlow, animate).then(function () {
            _this3.els.container.parentNode.removeChild(_this3.els.container);
            return Promise.resolve(_this3.emit('deleted'));
        });
    },


    events: {},

    getTemplateOptions: function getTemplateOptions() {
        var rv = Object.assign(this.user ? { user: this.user.data } : {});

        if (this.model) {
            rv.model = this.model.data;

            if (this.model.meta) rv.meta = this.model.meta;
        }

        if (this.templateOptions) rv.opts = typeof this.templateOptions === 'function' ? this.templateOptions() : this.templateOptions;

        return rv;
    },
    handleLogin: function handleLogin() {
        var _this4 = this;

        this.factory.create('login', { insertion: { value: { el: document.querySelector('#content') } } }).once("loggedIn", function () {
            return _this4.onLogin();
        });

        return this;
    },
    hide: function hide(isSlow) {
        var _this5 = this;

        var animate = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
        return this.hideEl(this.els.container, isSlow, animate).then(function () {
            return _this5.emit('hidden');
        });
    },
    _hideEl: function _hideEl(el, klass, resolve, hash) {
        el.removeEventListener('animationend', this[hash]);
        el.classList.add('hidden');
        el.classList.remove(klass);
        delete this[hash];
        resolve();
    },
    hideEl: function hideEl(el, isSlow) {
        var _this6 = this;

        var animate = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;

        if (this.isHidden(el)) return Promise.resolve();

        var time = new Date().getTime(),
            hash = time + 'Hide';

        return new Promise(function (resolve) {
            if (!animate) return resolve(el.classList.add('hidden'));

            var klass = 'animate-out' + (isSlow ? '-slow' : '');
            _this6[hash] = function (e) {
                return _this6._hideEl(el, klass, resolve, hash);
            };
            el.addEventListener('animationend', _this6[hash]);
            el.classList.add(klass);
        });
    },
    htmlToFragment: function htmlToFragment(str) {
        var range = document.createRange();
        // make the parent of the first div in the document becomes the context node
        range.selectNode(document.getElementsByTagName("div").item(0));
        return range.createContextualFragment(str);
    },
    initialize: function initialize() {
        return Object.assign(this, { els: {}, slurp: { attr: 'data-js', view: 'data-view', name: 'data-name' }, views: {} });
    },
    isAllowed: function isAllowed(user) {
        if (!this.requiresRole) return true;
        return this.requiresRole && user.data.roles.includes(this.requiresRole);
    },
    isHidden: function isHidden(el) {
        var element = el || this.els.container;
        return element.classList.contains('hidden');
    },
    onLogin: function onLogin() {

        if (!this.isAllowed(this.user)) return this.scootAway();

        this.initialize().render();
    },
    onNavigation: function onNavigation() {
        return this.show();
    },
    showNoAccess: function showNoAccess() {
        alert("No privileges, son");
        return this;
    },
    postRender: function postRender() {
        return this;
    },
    render: function render() {
        if (this.data) this.model = Object.create(this.Model, {}).constructor(this.data);

        this.slurpTemplate({ template: this.template(this.getTemplateOptions()), insertion: this.insertion || { el: document.body }, isView: true });

        this.renderSubviews();

        if (this.size) {
            this.size();this.OptimizedResize.add(this.size.bind(this));
        }

        return this.postRender();
    },
    renderSubviews: function renderSubviews() {
        var _this7 = this;

        this.subviewElements.forEach(function (obj) {
            var name = obj.name;

            var opts = {};

            if (_this7.Views && _this7.Views[name]) opts = _typeof(_this7.Views[name]) === "object" ? _this7.Views[name] : Reflect.apply(_this7.Views[name], _this7, []);

            _this7.views[name] = _this7.factory.create(key, Object.assign({ insertion: { value: { el: obj.el, method: 'insertBefore' } } }, { opts: { value: opts } }));
            obj.el.remove();
        });

        delete this.subviewElements;

        return this;
    },
    scootAway: function scootAway() {
        var _this8 = this;

        this.Toast.show('error', 'You are not allowed here.  Sorry.').catch(function (e) {
            _this8.Error(e);_this8.emit('navigate', '/');
        }).then(function () {
            return _this8.emit('navigate', '/');
        });

        return this;
    },
    show: function show(isSlow) {
        var _this9 = this;

        var animate = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
        return this.showEl(this.els.container, isSlow, animate).then(function () {
            return _this9.emit('shown');
        });
    },
    _showEl: function _showEl(el, klass, resolve, hash) {
        el.removeEventListener('animationend', this[hash]);
        el.classList.remove(klass);
        delete this[hash];
        resolve();
    },
    showEl: function showEl(el, isSlow) {
        var _this10 = this;

        var animate = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;

        if (!this.isHidden(el)) return Promise.resolve();

        var time = new Date().getTime(),
            hash = time + 'Show';

        return new Promise(function (resolve) {
            el.classList.remove('hidden');

            if (!animate) return resolve();

            var klass = 'animate-in' + (isSlow ? '-slow' : '');
            _this10[hash] = function (e) {
                return _this10._showEl(el, klass, resolve, hash);
            };
            el.addEventListener('animationend', _this10[hash]);
            el.classList.add(klass);
        });
    },
    slurpEl: function slurpEl(el) {
        var key = el.getAttribute(this.slurp.attr) || 'container';

        if (key === 'container') el.classList.add(this.name);

        this.els[key] = Array.isArray(this.els[key]) ? this.els[key].concat(el) : this.els[key] !== undefined ? [this.els[key], el] : el;

        el.removeAttribute(this.slurp.attr);

        if (this.events[key]) this.delegateEvents(key, el);
    },
    slurpTemplate: function slurpTemplate(options) {
        var _this11 = this;

        var fragment = this.htmlToFragment(options.template),
            selector = '[' + this.slurp.attr + ']',
            viewSelector = '[' + this.slurp.view + ']',
            firstEl = fragment.querySelector('*');

        if (options.isView || firstEl.getAttribute(this.slurp.attr)) this.slurpEl(firstEl);
        fragment.querySelectorAll(selector + ', ' + viewSelector).forEach(function (el) {
            if (el.hasAttribute(_this11.slurp.attr)) {
                _this11.slurpEl(el);
            } else if (el.hasAttribute(_this11.slurp.view)) {
                _this11.subviewElements.push({ el: el, view: el.getAttribute(_this11.slurp.view), name: el.getAttribute(_this11.slurp.name) });
            }
        });

        options.insertion.method === 'insertBefore' ? options.insertion.el.parentNode.insertBefore(fragment, options.insertion.el) : options.insertion.el[options.insertion.method || 'appendChild'](fragment);

        return this;
    }
});

},{"../../../lib/MyObject":24,"../models/__proto__":7,"./lib/OptimizedResize":16,"events":25}],16:[function(require,module,exports){
'use strict';

module.exports = Object.create({
    add: function add(callback) {
        if (!this.callbacks.length) window.addEventListener('resize', this.onResize.bind(this));
        this.callbacks.push(callback);
    },
    onResize: function onResize() {
        if (this.running) return;

        this.running = true;

        window.requestAnimationFrame ? window.requestAnimationFrame(this.runCallbacks.bind(this)) : setTimeout(this.runCallbacks, 66);
    },
    runCallbacks: function runCallbacks() {
        this.callbacks = this.callbacks.filter(function (callback) {
            return callback();
        });
        this.running = false;
    }
}, { callbacks: { writable: true, value: [] }, running: { writable: true, value: false } });

},{}],17:[function(require,module,exports){
"use strict";

module.exports = function (p) {
    return "<footer>\n    <div class=\"contact\">\n        <div>&copy; 2017 | Allegan Internet Wizard</div>\n        <div>123 Bayron Lane | Allegan, MI 12345 | 123.456.7890</div>\n        <div>the_wiz@aiw.com</div>\n    </div>\n</footer>";
};

},{}],18:[function(require,module,exports){
"use strict";

module.exports = function () {
    return "<nav>\n    <div class=\"contact\">\n        <div>phone: 123.456.7890 | email: the_wiz@aiw.com</div>\n    </div>\n    <ul data-js=\"nav\">\n        <li data-name=\"home\">Home</li>\n        <li data-name=\"services\">Services</li>\n        <li data-name=\"internet\">Local Internet!</li>\n    </ul>\n</nav>";
};

},{}],19:[function(require,module,exports){
"use strict";

module.exports = function () {
    return "<div>\n    <div>\n        <img src=\"/static/img/logo.svg\">\n    </div>\n    <div>\n        <h2>Make Your Tech Problems Magically Disappear!</h2>\n        <p>Computers. Can't live with 'em, can't live without 'em. They're a huge part of our lives these days, but unfortunately\n        they haven't gotten any less complicated. Things can and do go wrong all the time, and then you end up spending hours\n        and hours of your valuable time trying to figure out what the heck happened and fix it. Life's too short for all that frustration.\n        Why not hire a professional to take care of it quickly and painlessly? Give The Wizard a call!</p>\n        <p>Allegan Internet Wizard is here to assist the citizens of Allegan with all of their tech needs. Whether you are a\n        normal home user or a small business, we will use our 15+ years of experience in the tech industry to solve your problems\n        with speed, courtesy, and professionalism. Want to find out more? Click <span class=\"link\" data-js=\"services\">here</span>\n        for a list of our services.</p>\n        <p><span class=\"notice\">Special notice</span>: we are considering expanding our business to provide internet service to Allegan.\n        Click <span class=\"link\" data-js=\"internet\">here</span> to find out more.</p>\n    </div>        \n</div>";
};

},{}],20:[function(require,module,exports){
"use strict";

module.exports = function () {
    return "<div>\n    <div>\n        <h2>Local Internet Service for Allegan</h2>\n        <p>Not happy with your internet options in Allegan? Tired of paying too much for lousy speeds and constant service interruptions?\n        Well, you're in luck, because Allegan Internet Wizard is currently considering launching our own internet service for\n        the fine citizens of Allegan. We believe there's not nearly enough freedom and choice when it comes to internet providers, and\n        we'd like to use our tech skills to change that and offer Allegan fast, reliable service at a reasonable price.\n        Let's give those fat cat telecoms some real competition!</p>\n        <p>If this sounds good to you, please leave your name and contact info, and we'll let you know how things are developing.\n        Thank you for your interest!</p>\n    </div>\n    <div class=\"border\"></div>\n    <form>\n        <input data-js=\"name\" type=\"text\" placeholder=\"Name\">\n        <input data-js=\"contact\" type=\"text\" placeholder=\"Email or Phone Number\">\n        <input data-js=\"address\" type=\"text\" placeholder=\"Address\">\n        <button data-js=\"submitBtn\" type=\"button\">Submit</button>\n    </form>\n</div>";
};

},{}],21:[function(require,module,exports){
"use strict";

module.exports = function () {
    return "<div>\n    <h1>Our Services</h1>\n    <div class=\"intro\">\n        <p>Want to improve your home network? Protect your kids from inappropriate content on the web? Need help exploring\n        your internet service options? Can't figure out why a web page isn't working? Maybe you're a business and want to build\n        a new website or improve your current one. From general tech support to web development, we've got you covered!</p>\n    </div>\n    <div class=\"border\"></div>\n    <div class=\"categories\">\n        <div>\n            <h3>General Tech Support</h3>\n            <ul>\n                <li>Mac and PC. Laptop, desktop, mobile, and tablet. Tell us your problem and we'll fix it!</li>\n            </ul>\n        </div>\n        <div>\n            <h3>Internet Service Advice</h3>\n            <ul>\n                <li>We'll take a look at where you live and let you know what your best options are for connecting\n                to the internet</li>\n            </ul>\n        </div>\n        <div>\n            <h3>Data Recovery and Backups</h3>\n            <ul>\n                <li>Hard drive crash? We'll help you get your valuable data back</li>\n                <li>And we'll help you back your data up so that it's safe for the future</li>\n            </ul>\n        </div>\n        <div>\n            <h3>Networks</h3>\n            <ul>\n                <li>Installation of wired and wireless networks</li>\n                <li>Troubleshooting for internet connection issues</li>\n                <li>Configuration of modems and routers</li>\n            </ul>\n        </div>\n        <div>\n            <h3>Computer Security</h3>\n            <ul>\n                <li>Keep your kids safe from inappropriate content</li>\n                <li>Find and eliminate viruses, malware, and spyware</li>\n                <li>Set up antivirus software and firewalls for further protection</li>\n            </ul>\n       </div>\n        <div>\n            <h3>Help for Businesses</h3>\n            <ul>\n                <li>Fully customizable websites that will improve your brand and optimize your workflow</li>\n                <li>Setting up company email</li>\n                <li>Server installation</li>\n            </ul>\n        </div>\n    </div>\n</div>";
};

},{}],22:[function(require,module,exports){
"use strict";

module.exports = {
    constructor: function constructor(data) {
        var _this = this;

        var opts = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

        Object.assign(this, { store: {}, data: data }, opts);

        if (this.storeBy) {
            this.storeBy.forEach(function (key) {
                return _this.store[key] = {};
            });
            this._store();
        }

        return this;
    },
    _store: function _store() {
        var _this2 = this;

        this.data.forEach(function (datum) {
            return _this2.storeBy.forEach(function (attr) {
                return _this2._storeAttr(datum, attr);
            });
        });
    },
    _storeAttr: function _storeAttr(datum, attr) {
        this.store[attr][datum[attr]] = this.store[attr][datum[attr]] ? Array.isArray(this.store[attr][datum[attr]]) ? this.store[attr][datum[attr]].concat(datum) : [this.store[attr][datum[attr]], datum] : datum;
    }
};

},{}],23:[function(require,module,exports){
"use strict";

module.exports = function (err) {
  console.log(err.stack || err);
};

},{}],24:[function(require,module,exports){
'use strict';

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

module.exports = {
    getIntRange: function getIntRange(int) {
        return Array.from(Array(int).keys());
    },
    getRandomInclusiveInteger: function getRandomInclusiveInteger(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    },
    omit: function omit(obj, keys) {
        return Object.keys(obj).filter(function (key) {
            return !keys.includes(key);
        }).reduce(function (memo, key) {
            return Object.assign(memo, _defineProperty({}, key, obj[key]));
        }, {});
    },
    pick: function pick(obj, keys) {
        return keys.reduce(function (memo, key) {
            return Object.assign(memo, _defineProperty({}, key, obj[key]));
        }, {});
    },


    Error: require('./MyError'),

    P: function P(fun) {
        var args = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
        var thisArg = arguments[2];
        return new Promise(function (resolve, reject) {
            return Reflect.apply(fun, thisArg || undefined, args.concat(function (e) {
                for (var _len = arguments.length, callback = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
                    callback[_key - 1] = arguments[_key];
                }

                return e ? reject(e) : resolve(callback);
            }));
        });
    },

    constructor: function constructor() {
        return this;
    }
};

},{"./MyError":23}],25:[function(require,module,exports){
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

function EventEmitter() {
  this._events = this._events || {};
  this._maxListeners = this._maxListeners || undefined;
}
module.exports = EventEmitter;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
EventEmitter.defaultMaxListeners = 10;

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function(n) {
  if (!isNumber(n) || n < 0 || isNaN(n))
    throw TypeError('n must be a positive number');
  this._maxListeners = n;
  return this;
};

EventEmitter.prototype.emit = function(type) {
  var er, handler, len, args, i, listeners;

  if (!this._events)
    this._events = {};

  // If there is no 'error' event listener then throw.
  if (type === 'error') {
    if (!this._events.error ||
        (isObject(this._events.error) && !this._events.error.length)) {
      er = arguments[1];
      if (er instanceof Error) {
        throw er; // Unhandled 'error' event
      } else {
        // At least give some kind of context to the user
        var err = new Error('Uncaught, unspecified "error" event. (' + er + ')');
        err.context = er;
        throw err;
      }
    }
  }

  handler = this._events[type];

  if (isUndefined(handler))
    return false;

  if (isFunction(handler)) {
    switch (arguments.length) {
      // fast cases
      case 1:
        handler.call(this);
        break;
      case 2:
        handler.call(this, arguments[1]);
        break;
      case 3:
        handler.call(this, arguments[1], arguments[2]);
        break;
      // slower
      default:
        args = Array.prototype.slice.call(arguments, 1);
        handler.apply(this, args);
    }
  } else if (isObject(handler)) {
    args = Array.prototype.slice.call(arguments, 1);
    listeners = handler.slice();
    len = listeners.length;
    for (i = 0; i < len; i++)
      listeners[i].apply(this, args);
  }

  return true;
};

EventEmitter.prototype.addListener = function(type, listener) {
  var m;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events)
    this._events = {};

  // To avoid recursion in the case that type === "newListener"! Before
  // adding it to the listeners, first emit "newListener".
  if (this._events.newListener)
    this.emit('newListener', type,
              isFunction(listener.listener) ?
              listener.listener : listener);

  if (!this._events[type])
    // Optimize the case of one listener. Don't need the extra array object.
    this._events[type] = listener;
  else if (isObject(this._events[type]))
    // If we've already got an array, just append.
    this._events[type].push(listener);
  else
    // Adding the second element, need to change to array.
    this._events[type] = [this._events[type], listener];

  // Check for listener leak
  if (isObject(this._events[type]) && !this._events[type].warned) {
    if (!isUndefined(this._maxListeners)) {
      m = this._maxListeners;
    } else {
      m = EventEmitter.defaultMaxListeners;
    }

    if (m && m > 0 && this._events[type].length > m) {
      this._events[type].warned = true;
      console.error('(node) warning: possible EventEmitter memory ' +
                    'leak detected. %d listeners added. ' +
                    'Use emitter.setMaxListeners() to increase limit.',
                    this._events[type].length);
      if (typeof console.trace === 'function') {
        // not supported in IE 10
        console.trace();
      }
    }
  }

  return this;
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.once = function(type, listener) {
  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  var fired = false;

  function g() {
    this.removeListener(type, g);

    if (!fired) {
      fired = true;
      listener.apply(this, arguments);
    }
  }

  g.listener = listener;
  this.on(type, g);

  return this;
};

// emits a 'removeListener' event iff the listener was removed
EventEmitter.prototype.removeListener = function(type, listener) {
  var list, position, length, i;

  if (!isFunction(listener))
    throw TypeError('listener must be a function');

  if (!this._events || !this._events[type])
    return this;

  list = this._events[type];
  length = list.length;
  position = -1;

  if (list === listener ||
      (isFunction(list.listener) && list.listener === listener)) {
    delete this._events[type];
    if (this._events.removeListener)
      this.emit('removeListener', type, listener);

  } else if (isObject(list)) {
    for (i = length; i-- > 0;) {
      if (list[i] === listener ||
          (list[i].listener && list[i].listener === listener)) {
        position = i;
        break;
      }
    }

    if (position < 0)
      return this;

    if (list.length === 1) {
      list.length = 0;
      delete this._events[type];
    } else {
      list.splice(position, 1);
    }

    if (this._events.removeListener)
      this.emit('removeListener', type, listener);
  }

  return this;
};

EventEmitter.prototype.removeAllListeners = function(type) {
  var key, listeners;

  if (!this._events)
    return this;

  // not listening for removeListener, no need to emit
  if (!this._events.removeListener) {
    if (arguments.length === 0)
      this._events = {};
    else if (this._events[type])
      delete this._events[type];
    return this;
  }

  // emit removeListener for all listeners on all events
  if (arguments.length === 0) {
    for (key in this._events) {
      if (key === 'removeListener') continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners('removeListener');
    this._events = {};
    return this;
  }

  listeners = this._events[type];

  if (isFunction(listeners)) {
    this.removeListener(type, listeners);
  } else if (listeners) {
    // LIFO order
    while (listeners.length)
      this.removeListener(type, listeners[listeners.length - 1]);
  }
  delete this._events[type];

  return this;
};

EventEmitter.prototype.listeners = function(type) {
  var ret;
  if (!this._events || !this._events[type])
    ret = [];
  else if (isFunction(this._events[type]))
    ret = [this._events[type]];
  else
    ret = this._events[type].slice();
  return ret;
};

EventEmitter.prototype.listenerCount = function(type) {
  if (this._events) {
    var evlistener = this._events[type];

    if (isFunction(evlistener))
      return 1;
    else if (evlistener)
      return evlistener.length;
  }
  return 0;
};

EventEmitter.listenerCount = function(emitter, type) {
  return emitter.listenerCount(type);
};

function isFunction(arg) {
  return typeof arg === 'function';
}

function isNumber(arg) {
  return typeof arg === 'number';
}

function isObject(arg) {
  return typeof arg === 'object' && arg !== null;
}

function isUndefined(arg) {
  return arg === void 0;
}

},{}],26:[function(require,module,exports){
/*
 * smoothscroll polyfill - v0.3.5
 * https://iamdustan.github.io/smoothscroll
 * 2016 (c) Dustan Kasten, Jeremias Menichelli - MIT License
 */

(function(w, d, undefined) {
  'use strict';

  /*
   * aliases
   * w: window global object
   * d: document
   * undefined: undefined
   */

  // polyfill
  function polyfill() {
    // return when scrollBehavior interface is supported
    if ('scrollBehavior' in d.documentElement.style) {
      return;
    }

    /*
     * globals
     */
    var Element = w.HTMLElement || w.Element;
    var SCROLL_TIME = 468;

    /*
     * object gathering original scroll methods
     */
    var original = {
      scroll: w.scroll || w.scrollTo,
      scrollBy: w.scrollBy,
      elScroll: Element.prototype.scroll || scrollElement,
      scrollIntoView: Element.prototype.scrollIntoView
    };

    /*
     * define timing method
     */
    var now = w.performance && w.performance.now
      ? w.performance.now.bind(w.performance) : Date.now;

    /**
     * changes scroll position inside an element
     * @method scrollElement
     * @param {Number} x
     * @param {Number} y
     */
    function scrollElement(x, y) {
      this.scrollLeft = x;
      this.scrollTop = y;
    }

    /**
     * returns result of applying ease math function to a number
     * @method ease
     * @param {Number} k
     * @returns {Number}
     */
    function ease(k) {
      return 0.5 * (1 - Math.cos(Math.PI * k));
    }

    /**
     * indicates if a smooth behavior should be applied
     * @method shouldBailOut
     * @param {Number|Object} x
     * @returns {Boolean}
     */
    function shouldBailOut(x) {
      if (typeof x !== 'object'
            || x === null
            || x.behavior === undefined
            || x.behavior === 'auto'
            || x.behavior === 'instant') {
        // first arg not an object/null
        // or behavior is auto, instant or undefined
        return true;
      }

      if (typeof x === 'object'
            && x.behavior === 'smooth') {
        // first argument is an object and behavior is smooth
        return false;
      }

      // throw error when behavior is not supported
      throw new TypeError('behavior not valid');
    }

    /**
     * finds scrollable parent of an element
     * @method findScrollableParent
     * @param {Node} el
     * @returns {Node} el
     */
    function findScrollableParent(el) {
      var isBody;
      var hasScrollableSpace;
      var hasVisibleOverflow;

      do {
        el = el.parentNode;

        // set condition variables
        isBody = el === d.body;
        hasScrollableSpace =
          el.clientHeight < el.scrollHeight ||
          el.clientWidth < el.scrollWidth;
        hasVisibleOverflow =
          w.getComputedStyle(el, null).overflow === 'visible';
      } while (!isBody && !(hasScrollableSpace && !hasVisibleOverflow));

      isBody = hasScrollableSpace = hasVisibleOverflow = null;

      return el;
    }

    /**
     * self invoked function that, given a context, steps through scrolling
     * @method step
     * @param {Object} context
     */
    function step(context) {
      var time = now();
      var value;
      var currentX;
      var currentY;
      var elapsed = (time - context.startTime) / SCROLL_TIME;

      // avoid elapsed times higher than one
      elapsed = elapsed > 1 ? 1 : elapsed;

      // apply easing to elapsed time
      value = ease(elapsed);

      currentX = context.startX + (context.x - context.startX) * value;
      currentY = context.startY + (context.y - context.startY) * value;

      context.method.call(context.scrollable, currentX, currentY);

      // scroll more if we have not reached our destination
      if (currentX !== context.x || currentY !== context.y) {
        w.requestAnimationFrame(step.bind(w, context));
      }
    }

    /**
     * scrolls window with a smooth behavior
     * @method smoothScroll
     * @param {Object|Node} el
     * @param {Number} x
     * @param {Number} y
     */
    function smoothScroll(el, x, y) {
      var scrollable;
      var startX;
      var startY;
      var method;
      var startTime = now();

      // define scroll context
      if (el === d.body) {
        scrollable = w;
        startX = w.scrollX || w.pageXOffset;
        startY = w.scrollY || w.pageYOffset;
        method = original.scroll;
      } else {
        scrollable = el;
        startX = el.scrollLeft;
        startY = el.scrollTop;
        method = scrollElement;
      }

      // scroll looping over a frame
      step({
        scrollable: scrollable,
        method: method,
        startTime: startTime,
        startX: startX,
        startY: startY,
        x: x,
        y: y
      });
    }

    /*
     * ORIGINAL METHODS OVERRIDES
     */

    // w.scroll and w.scrollTo
    w.scroll = w.scrollTo = function() {
      // avoid smooth behavior if not required
      if (shouldBailOut(arguments[0])) {
        original.scroll.call(
          w,
          arguments[0].left || arguments[0],
          arguments[0].top || arguments[1]
        );
        return;
      }

      // LET THE SMOOTHNESS BEGIN!
      smoothScroll.call(
        w,
        d.body,
        ~~arguments[0].left,
        ~~arguments[0].top
      );
    };

    // w.scrollBy
    w.scrollBy = function() {
      // avoid smooth behavior if not required
      if (shouldBailOut(arguments[0])) {
        original.scrollBy.call(
          w,
          arguments[0].left || arguments[0],
          arguments[0].top || arguments[1]
        );
        return;
      }

      // LET THE SMOOTHNESS BEGIN!
      smoothScroll.call(
        w,
        d.body,
        ~~arguments[0].left + (w.scrollX || w.pageXOffset),
        ~~arguments[0].top + (w.scrollY || w.pageYOffset)
      );
    };

    // Element.prototype.scroll and Element.prototype.scrollTo
    Element.prototype.scroll = Element.prototype.scrollTo = function() {
      // avoid smooth behavior if not required
      if (shouldBailOut(arguments[0])) {
        original.elScroll.call(
            this,
            arguments[0].left || arguments[0],
            arguments[0].top || arguments[1]
        );
        return;
      }

      // LET THE SMOOTHNESS BEGIN!
      smoothScroll.call(
          this,
          this,
          arguments[0].left,
          arguments[0].top
      );
    };

    // Element.prototype.scrollBy
    Element.prototype.scrollBy = function() {
      var arg0 = arguments[0];

      if (typeof arg0 === 'object') {
        this.scroll({
          left: arg0.left + this.scrollLeft,
          top: arg0.top + this.scrollTop,
          behavior: arg0.behavior
        });
      } else {
        this.scroll(
          this.scrollLeft + arg0,
          this.scrollTop + arguments[1]
        );
      }
    };

    // Element.prototype.scrollIntoView
    Element.prototype.scrollIntoView = function() {
      // avoid smooth behavior if not required
      if (shouldBailOut(arguments[0])) {
        original.scrollIntoView.call(this, arguments[0] || true);
        return;
      }

      // LET THE SMOOTHNESS BEGIN!
      var scrollableParent = findScrollableParent(this);
      var parentRects = scrollableParent.getBoundingClientRect();
      var clientRects = this.getBoundingClientRect();

      if (scrollableParent !== d.body) {
        // reveal element inside parent
        smoothScroll.call(
          this,
          scrollableParent,
          scrollableParent.scrollLeft + clientRects.left - parentRects.left,
          scrollableParent.scrollTop + clientRects.top - parentRects.top
        );
        // reveal parent in viewport
        w.scrollBy({
          left: parentRects.left,
          top: parentRects.top,
          behavior: 'smooth'
        });
      } else {
        // reveal element in viewport
        w.scrollBy({
          left: clientRects.left,
          top: clientRects.top,
          behavior: 'smooth'
        });
      }
    };
  }

  if (typeof exports === 'object') {
    // commonjs
    module.exports = { polyfill: polyfill };
  } else {
    // global
    polyfill();
  }
})(window, document);

},{}],27:[function(require,module,exports){
module.exports = () => `<div></div>`

},{}],28:[function(require,module,exports){
module.exports = () => 
`<div class="hidden">
    <div data-js="icon"></div>
    <div>
        <div data-js="title"></div>
        <div data-js="message"></div>
    </div>
</div>`
},{}],29:[function(require,module,exports){
module.exports = (p={}) => `<svg version="1.1" data-js="${p.name || 'checkmark'}" class="checkmark" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="97.619px" height="97.618px" viewBox="0 0 97.619 97.618" style="enable-background:new 0 0 97.619 97.618;"
	 xml:space="preserve">
<g>
	<path d="M96.939,17.358L83.968,5.959c-0.398-0.352-0.927-0.531-1.449-0.494C81.99,5.5,81.496,5.743,81.146,6.142L34.1,59.688
		L17.372,37.547c-0.319-0.422-0.794-0.701-1.319-0.773c-0.524-0.078-1.059,0.064-1.481,0.385L0.794,47.567
		c-0.881,0.666-1.056,1.92-0.39,2.801l30.974,40.996c0.362,0.479,0.922,0.771,1.522,0.793c0.024,0,0.049,0,0.073,0
		c0.574,0,1.122-0.246,1.503-0.68l62.644-71.297C97.85,19.351,97.769,18.086,96.939,17.358z"/>
</g></svg>`

},{}],30:[function(require,module,exports){
module.exports = (p={}) => `<svg version="1.1" data-js="${p.name || 'error'}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 18.978 18.978" style="enable-background:new 0 0 18.978 18.978;" xml:space="preserve">
<g>
    <path d="M16.088,1.675c-0.133-0.104-0.306-0.144-0.47-0.105c-0.013,0.002-1.261,0.29-2.594,0.29
        c-1.788,0-2.789-0.476-2.975-1.415C9.999,0.191,9.779,0.007,9.521,0c-0.257-0.007-0.487,0.167-0.55,0.418
        C8.727,1.386,7.71,1.877,5.95,1.877c-1.332,0-2.571-0.302-2.583-0.305c-0.166-0.04-0.34-0.004-0.474,0.102
        C2.76,1.777,2.681,1.938,2.681,2.108v4.869c0,0.04,0.004,0.078,0.013,0.115c0.057,1.647,0.65,8.714,6.528,11.822
        c0.08,0.043,0.169,0.064,0.258,0.064c0.092,0,0.183-0.021,0.266-0.066c5.74-3.137,6.445-10.115,6.532-11.791
        c0.012-0.046,0.019-0.094,0.019-0.144V2.108C16.297,1.939,16.219,1.78,16.088,1.675z M15.19,6.857
        c-0.007,0.031-0.012,0.064-0.013,0.097c-0.053,1.298-0.574,7.832-5.701,10.838c-5.215-2.965-5.646-9.526-5.68-10.83
        c0-0.029-0.004-0.058-0.009-0.085V2.784C4.322,2.877,5.112,2.982,5.95,2.982c1.911,0,2.965-0.54,3.537-1.208
        c0.553,0.661,1.599,1.191,3.536,1.191c0.839,0,1.631-0.101,2.166-0.188L15.19,6.857L15.19,6.857z"/>
    <polygon points="10.241,11.237 10.529,5.311 8.449,5.311 8.75,11.237 		"/>
    <path d="M9.496,11.891c-0.694,0-1.178,0.498-1.178,1.189c0,0.682,0.471,1.191,1.178,1.191
        c0.706,0,1.164-0.51,1.164-1.191C10.647,12.389,10.189,11.891,9.496,11.891z"/>
</g></svg>`

},{}],31:[function(require,module,exports){
'use strict';

module.exports = Object.create(Object.assign({}, require('../../../client/js/views/__proto__'), {

    ToastMessage: require('./ToastMessage'),

    name: 'Toast',

    postRender: function postRender() {
        this.messages = {};

        return this;
    },


    requiresLogin: false,

    createMessage: function createMessage(type, message) {
        if (!this.messages[message]) this.messages[message] = Object.create(this.ToastMessage, {
            insertion: { value: { el: this.els.container } }
        }).constructor();

        return this.messages[message].showMessage(type, message);
    },


    template: require('../templates/Toast')

}), {});

},{"../../../client/js/views/__proto__":15,"../templates/Toast":27,"./ToastMessage":32}],32:[function(require,module,exports){
'use strict';

module.exports = Object.assign({}, require('../../../client/js/views/__proto__'), {

    name: 'ToastMessage',

    Icons: {
        error: require('../templates/lib/error')(),
        success: require('../templates/lib/checkmark')()
    },

    postRender: function postRender() {
        var _this = this;

        this.on('shown', function () {
            return _this.status = 'shown';
        });
        this.on('hidden', function () {
            return _this.status = 'hidden';
        });

        return this;
    },


    requiresLogin: false,

    showMessage: function showMessage(type, message) {
        var _this2 = this;

        return new Promise(function (resolve, reject) {
            if (/show/.test(_this2.status)) _this2.teardown();

            _this2.resolution = resolve;

            if (type !== 'error') _this2.els.container.classList.add('success');

            _this2.els.message.textContent = message;
            _this2.els.title.textContent = type === 'error' ? 'Error' : 'Success';
            _this2.slurpTemplate({ insertion: { el: _this2.els.icon }, template: type === 'error' ? _this2.Icons.error : _this2.Icons.success });

            _this2.status = 'showing';

            _this2.show(true).then(function () {
                return _this2.hide(true);
            }).then(function () {
                return _this2.teardown();
            }).catch(reject);
        });
    },
    teardown: function teardown() {
        if (this.els.container.classList.contains('success')) this.els.container.classList.remove('success');
        this.els.message.textContent = '';
        this.els.message.title = '';
        if (this.els.icon.firstChild) this.els.icon.removeChild(this.els.icon.firstChild);
        this.resolution();
    },


    template: require('../templates/ToastMessage')

});

},{"../../../client/js/views/__proto__":15,"../templates/ToastMessage":28,"../templates/lib/checkmark":29,"../templates/lib/error":30}]},{},[5])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJjbGllbnQvanMvLlRlbXBsYXRlTWFwLmpzIiwiY2xpZW50L2pzLy5WaWV3TWFwLmpzIiwiY2xpZW50L2pzL1hoci5qcyIsImNsaWVudC9qcy9mYWN0b3J5L1ZpZXcuanMiLCJjbGllbnQvanMvbWFpbi5qcyIsImNsaWVudC9qcy9tb2RlbHMvUGVyc29uLmpzIiwiY2xpZW50L2pzL21vZGVscy9fX3Byb3RvX18uanMiLCJjbGllbnQvanMvcG9seWZpbGwuanMiLCJjbGllbnQvanMvcm91dGVyLmpzIiwiY2xpZW50L2pzL3ZpZXdzL0Zvb3Rlci5qcyIsImNsaWVudC9qcy92aWV3cy9IZWFkZXIuanMiLCJjbGllbnQvanMvdmlld3MvSG9tZS5qcyIsImNsaWVudC9qcy92aWV3cy9JbnRlcm5ldC5qcyIsImNsaWVudC9qcy92aWV3cy9TZXJ2aWNlcy5qcyIsImNsaWVudC9qcy92aWV3cy9fX3Byb3RvX18uanMiLCJjbGllbnQvanMvdmlld3MvbGliL09wdGltaXplZFJlc2l6ZS5qcyIsImNsaWVudC9qcy92aWV3cy90ZW1wbGF0ZXMvRm9vdGVyLmpzIiwiY2xpZW50L2pzL3ZpZXdzL3RlbXBsYXRlcy9IZWFkZXIuanMiLCJjbGllbnQvanMvdmlld3MvdGVtcGxhdGVzL0hvbWUuanMiLCJjbGllbnQvanMvdmlld3MvdGVtcGxhdGVzL0ludGVybmV0LmpzIiwiY2xpZW50L2pzL3ZpZXdzL3RlbXBsYXRlcy9TZXJ2aWNlcy5qcyIsImxpYi9Nb2RlbC5qcyIsImxpYi9NeUVycm9yLmpzIiwibGliL015T2JqZWN0LmpzIiwibm9kZV9tb2R1bGVzL2V2ZW50cy9ldmVudHMuanMiLCJub2RlX21vZHVsZXMvc21vb3Roc2Nyb2xsLXBvbHlmaWxsL2Rpc3Qvc21vb3Roc2Nyb2xsLmpzIiwibm9kZV9tb2R1bGVzL3RvYXN0L3RlbXBsYXRlcy9Ub2FzdC5qcyIsIm5vZGVfbW9kdWxlcy90b2FzdC90ZW1wbGF0ZXMvVG9hc3RNZXNzYWdlLmpzIiwibm9kZV9tb2R1bGVzL3RvYXN0L3RlbXBsYXRlcy9saWIvY2hlY2ttYXJrLmpzIiwibm9kZV9tb2R1bGVzL3RvYXN0L3RlbXBsYXRlcy9saWIvZXJyb3IuanMiLCJub2RlX21vZHVsZXMvdG9hc3Qvdmlld3MvVG9hc3QuanMiLCJub2RlX21vZHVsZXMvdG9hc3Qvdmlld3MvVG9hc3RNZXNzYWdlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7QUNBQSxPQUFPLE9BQVAsR0FBZTtBQUNkLFNBQVEsUUFBUSwwQkFBUixDQURNO0FBRWQsU0FBUSxRQUFRLDBCQUFSLENBRk07QUFHZCxPQUFNLFFBQVEsd0JBQVIsQ0FIUTtBQUlkLFdBQVUsUUFBUSw0QkFBUixDQUpJO0FBS2QsV0FBVSxRQUFRLDRCQUFSLENBTEk7QUFNZCxRQUFPLFFBQVEseUJBQVIsQ0FOTztBQU9kLGVBQWMsUUFBUSxnQ0FBUjtBQVBBLENBQWY7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWU7QUFDZCxTQUFRLFFBQVEsZ0JBQVIsQ0FETTtBQUVkLFNBQVEsUUFBUSxnQkFBUixDQUZNO0FBR2QsT0FBTSxRQUFRLGNBQVIsQ0FIUTtBQUlkLFdBQVUsUUFBUSxrQkFBUixDQUpJO0FBS2QsV0FBVSxRQUFRLGtCQUFSLENBTEk7QUFNZCxRQUFPLFFBQVEsZUFBUixDQU5PO0FBT2QsZUFBYyxRQUFRLHNCQUFSO0FBUEEsQ0FBZjs7Ozs7QUNBQSxPQUFPLE9BQVAsR0FBaUIsT0FBTyxNQUFQLENBQWUsT0FBTyxNQUFQLENBQWUsRUFBZixFQUFtQixRQUFRLG9CQUFSLENBQW5CLEVBQWtEOztBQUU5RSxhQUFTO0FBRUwsbUJBRkssdUJBRVEsSUFGUixFQUVlO0FBQUE7O0FBQ2hCLGdCQUFJLE1BQU0sSUFBSSxjQUFKLEVBQVY7O0FBRUEsZ0JBQUksS0FBSyxVQUFULEVBQXNCLElBQUksZ0JBQUosQ0FBc0IsVUFBdEIsRUFBa0M7QUFBQSx1QkFDcEQsS0FBSyxVQUFMLENBQWlCLEVBQUUsZ0JBQUYsR0FBcUIsS0FBSyxLQUFMLENBQWMsRUFBRSxNQUFGLEdBQVcsRUFBRSxLQUFmLEdBQXlCLEdBQXJDLENBQXJCLEdBQWtFLENBQW5GLENBRG9EO0FBQUEsYUFBbEM7O0FBSXRCLG1CQUFPLElBQUksT0FBSixDQUFhLFVBQUUsT0FBRixFQUFXLE1BQVgsRUFBdUI7O0FBRXZDLG9CQUFJLE1BQUosR0FBYSxZQUFXO0FBQ3BCLHFCQUFFLEdBQUYsRUFBTyxHQUFQLEVBQVksR0FBWixFQUFrQixRQUFsQixDQUE0QixLQUFLLE1BQWpDLElBQ00sT0FBUSxLQUFLLEtBQUwsQ0FBWSxLQUFLLFFBQWpCLENBQVIsQ0FETixHQUVNLFFBQVMsS0FBSyxLQUFMLENBQVksS0FBSyxRQUFqQixDQUFULENBRk47QUFHSCxpQkFKRDs7QUFNQSxvQkFBSSxLQUFLLE1BQUwsS0FBZ0IsS0FBaEIsSUFBeUIsS0FBSyxNQUFMLEtBQWdCLFNBQTdDLEVBQXlEO0FBQ3JELHdCQUFJLEtBQUssS0FBSyxFQUFMLFNBQWMsS0FBSyxFQUFuQixHQUEwQixFQUFuQztBQUNBLHdCQUFJLElBQUosQ0FBVSxLQUFLLE1BQWYsUUFBMkIsS0FBSyxRQUFoQyxHQUEyQyxFQUEzQztBQUNBLDBCQUFLLFVBQUwsQ0FBaUIsR0FBakIsRUFBc0IsS0FBSyxPQUEzQjtBQUNBLHdCQUFJLElBQUosQ0FBUyxJQUFUO0FBQ0gsaUJBTEQsTUFLTztBQUNILHdCQUFNLE9BQU8sTUFBSSxLQUFLLFFBQVQsSUFBd0IsS0FBSyxFQUFMLFNBQWMsS0FBSyxFQUFuQixHQUEwQixFQUFsRCxDQUFiO0FBQ0Esd0JBQUksSUFBSixDQUFVLEtBQUssTUFBTCxDQUFZLFdBQVosRUFBVixFQUFxQyxJQUFyQyxFQUEyQyxJQUEzQztBQUNBLDBCQUFLLFVBQUwsQ0FBaUIsR0FBakIsRUFBc0IsS0FBSyxPQUEzQjtBQUNBLHdCQUFJLElBQUosQ0FBVSxLQUFLLElBQUwsSUFBYSxJQUF2QjtBQUNIOztBQUVELG9CQUFJLEtBQUssVUFBVCxFQUFzQixLQUFLLFVBQUwsQ0FBaUIsTUFBakI7QUFDekIsYUFyQk0sQ0FBUDtBQXNCSCxTQS9CSTtBQWlDTCxtQkFqQ0ssdUJBaUNRLEtBakNSLEVBaUNnQjtBQUNqQjtBQUNBO0FBQ0EsbUJBQU8sTUFBTSxPQUFOLENBQWMsV0FBZCxFQUEyQixNQUEzQixDQUFQO0FBQ0gsU0FyQ0k7QUF1Q0wsa0JBdkNLLHNCQXVDTyxHQXZDUCxFQXVDeUI7QUFBQSxnQkFBYixPQUFhLHVFQUFMLEVBQUs7O0FBQzFCLGdCQUFJLGdCQUFKLENBQXNCLFFBQXRCLEVBQWdDLFFBQVEsTUFBUixJQUFrQixrQkFBbEQ7QUFDQSxnQkFBSSxnQkFBSixDQUFzQixjQUF0QixFQUFzQyxRQUFRLFdBQVIsSUFBdUIsWUFBN0Q7QUFDSDtBQTFDSSxLQUZxRTs7QUErQzlFLFlBL0M4RSxvQkErQ3BFLElBL0NvRSxFQStDN0Q7QUFDYixlQUFPLE9BQU8sTUFBUCxDQUFlLEtBQUssT0FBcEIsRUFBNkIsRUFBN0IsRUFBbUMsV0FBbkMsQ0FBZ0QsSUFBaEQsQ0FBUDtBQUNILEtBakQ2RTtBQW1EOUUsZUFuRDhFLHlCQW1EaEU7O0FBRVYsWUFBSSxDQUFDLGVBQWUsU0FBZixDQUF5QixZQUE5QixFQUE2QztBQUMzQywyQkFBZSxTQUFmLENBQXlCLFlBQXpCLEdBQXdDLFVBQVMsS0FBVCxFQUFnQjtBQUN0RCxvQkFBSSxTQUFTLE1BQU0sTUFBbkI7QUFBQSxvQkFBMkIsVUFBVSxJQUFJLFVBQUosQ0FBZSxNQUFmLENBQXJDO0FBQ0EscUJBQUssSUFBSSxPQUFPLENBQWhCLEVBQW1CLE9BQU8sTUFBMUIsRUFBa0MsTUFBbEMsRUFBMEM7QUFDeEMsNEJBQVEsSUFBUixJQUFnQixNQUFNLFVBQU4sQ0FBaUIsSUFBakIsSUFBeUIsSUFBekM7QUFDRDtBQUNELHFCQUFLLElBQUwsQ0FBVSxPQUFWO0FBQ0QsYUFORDtBQU9EOztBQUVELGVBQU8sS0FBSyxRQUFMLENBQWMsSUFBZCxDQUFtQixJQUFuQixDQUFQO0FBQ0g7QUFoRTZFLENBQWxELENBQWYsRUFrRVosRUFsRVksRUFrRU4sV0FsRU0sRUFBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlO0FBRTVCLFVBRjRCLGtCQUVwQixJQUZvQixFQUVkLElBRmMsRUFFUDtBQUNqQixZQUFNLFFBQVEsSUFBZDtBQUNBLGVBQU8sS0FBSyxNQUFMLENBQVksQ0FBWixFQUFlLFdBQWYsS0FBK0IsS0FBSyxLQUFMLENBQVcsQ0FBWCxDQUF0QztBQUNBLGVBQU8sT0FBTyxNQUFQLENBQ0gsS0FBSyxLQUFMLENBQVksSUFBWixDQURHLEVBRUgsT0FBTyxNQUFQLENBQWU7QUFDWCxtQkFBTyxFQUFFLE9BQU8sS0FBSyxLQUFkLEVBREk7QUFFWCxrQkFBTSxFQUFFLE9BQU8sSUFBVCxFQUZLO0FBR1gscUJBQVMsRUFBRSxPQUFPLElBQVQsRUFIRTtBQUlYLHNCQUFVLEVBQUUsT0FBTyxLQUFLLFNBQUwsQ0FBZ0IsSUFBaEIsQ0FBVDtBQUpDLFNBQWYsRUFLRyxJQUxILENBRkcsRUFRTCxXQVJLLEVBQVA7QUFTSDtBQWQyQixDQUFmLEVBZ0JkO0FBQ0MsZUFBVyxFQUFFLE9BQU8sUUFBUSxpQkFBUixDQUFULEVBRFo7QUFFQyxXQUFPLEVBQUUsT0FBTyxRQUFRLGdCQUFSLENBQVQsRUFGUjtBQUdDLFdBQU8sRUFBRSxPQUFPLFFBQVEsYUFBUixDQUFUO0FBSFIsQ0FoQmMsQ0FBakI7Ozs7O0FDQ0EsSUFBTSxTQUFTLFFBQVEsVUFBUixDQUFmO0FBQUEsSUFDSSxTQUFTLElBQUksT0FBSixDQUFhO0FBQUEsV0FBVyxPQUFPLE1BQVAsR0FBZ0I7QUFBQSxlQUFNLFNBQU47QUFBQSxLQUEzQjtBQUFBLENBQWIsQ0FEYjs7QUFHQSxRQUFRLFlBQVI7O0FBRUEsT0FBTyxJQUFQLENBQWE7QUFBQSxXQUFNLE9BQU8sVUFBUCxFQUFOO0FBQUEsQ0FBYixFQUNDLEtBREQsQ0FDUTtBQUFBLFdBQUssUUFBUSxHQUFSLG9DQUE2QyxFQUFFLEtBQUYsSUFBVyxDQUF4RCxFQUFMO0FBQUEsQ0FEUjs7Ozs7QUNOQSxPQUFPLE9BQVAsR0FBaUIsT0FBTyxNQUFQLENBQWUsRUFBZixFQUFtQixRQUFRLGFBQVIsQ0FBbkIsRUFBMkM7O0FBRXhELFVBQU0sRUFGa0Q7O0FBSXhELFlBQVE7QUFDSixjQUFNO0FBQ0YsbUJBQU87QUFETCxTQURGO0FBSUosaUJBQVM7QUFDTCxtQkFBTztBQURGO0FBSkwsS0FKZ0Q7O0FBYXhELGNBQVUsUUFiOEM7O0FBZXhELFlBZndELG9CQWU5QyxLQWY4QyxFQWV2QyxLQWZ1QyxFQWUvQjtBQUNyQixZQUFNLE1BQU0sTUFBTSxJQUFOLEVBQVo7O0FBRUEsWUFBSSxVQUFVLE1BQVYsSUFBb0IsUUFBUSxFQUFoQyxFQUFxQyxPQUFPLEtBQVA7O0FBRXJDLFlBQUksVUFBVSxTQUFWLElBQXlCLENBQUMsS0FBSyxXQUFMLENBQWlCLElBQWpCLENBQXVCLEdBQXZCLENBQUQsSUFBaUMsQ0FBQyxLQUFLLFdBQUwsQ0FBaUIsSUFBakIsQ0FBdUIsR0FBdkIsQ0FBL0QsRUFBZ0csT0FBTyxLQUFQOztBQUVoRyxlQUFPLElBQVA7QUFDSCxLQXZCdUQ7OztBQXlCeEQsaUJBQWEsK0NBekIyQzs7QUEyQnhELGlCQUFhOztBQTNCMkMsQ0FBM0MsQ0FBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlLEVBQWYsRUFBb0IsUUFBUSx1QkFBUixDQUFwQixFQUFzRCxRQUFRLG9CQUFSLENBQXRELEVBQXFGLFFBQVEsUUFBUixFQUFrQixZQUFsQixDQUErQixTQUFwSCxFQUErSDs7QUFFNUksU0FBSyxRQUFRLFFBQVIsQ0FGdUk7O0FBSTVJLFVBSjRJLG1CQUlwSSxFQUpvSSxFQUkvSDtBQUFBOztBQUNULGVBQU8sS0FBSyxHQUFMLENBQVUsRUFBRSxRQUFRLFFBQVYsRUFBb0IsVUFBVSxLQUFLLFFBQW5DLEVBQTZDLE1BQTdDLEVBQVYsRUFDTixJQURNLENBQ0EsY0FBTTtBQUNULGdCQUFNLFFBQVEsTUFBSyxJQUFMLENBQVUsSUFBVixDQUFnQjtBQUFBLHVCQUFTLE1BQU0sRUFBTixJQUFZLEVBQXJCO0FBQUEsYUFBaEIsQ0FBZDs7QUFFQSxnQkFBSSxNQUFLLEtBQVQsRUFBaUI7QUFDYix1QkFBTyxJQUFQLENBQWEsTUFBSyxLQUFsQixFQUEwQixPQUExQixDQUFtQyxnQkFBUTtBQUN2QywwQkFBSyxLQUFMLENBQVksSUFBWixFQUFvQixNQUFPLElBQVAsQ0FBcEIsSUFBc0MsTUFBSyxLQUFMLENBQVksSUFBWixFQUFvQixNQUFPLElBQVAsQ0FBcEIsRUFBb0MsTUFBcEMsQ0FBNEM7QUFBQSwrQkFBUyxNQUFNLEVBQU4sSUFBWSxFQUFyQjtBQUFBLHFCQUE1QyxDQUF0QztBQUNBLHdCQUFJLE1BQUssS0FBTCxDQUFZLElBQVosRUFBb0IsTUFBTyxJQUFQLENBQXBCLEVBQW9DLE1BQXBDLEtBQStDLENBQW5ELEVBQXVEO0FBQUUsOEJBQUssS0FBTCxDQUFZLElBQVosRUFBb0IsTUFBTyxJQUFQLENBQXBCLElBQXNDLFNBQXRDO0FBQWlEO0FBQzdHLGlCQUhEO0FBSUg7O0FBRUQsa0JBQUssSUFBTCxHQUFZLE1BQUssSUFBTCxDQUFVLE1BQVYsQ0FBa0I7QUFBQSx1QkFBUyxNQUFNLEVBQU4sSUFBWSxFQUFyQjtBQUFBLGFBQWxCLENBQVo7QUFDQSxnQkFBSSxNQUFLLEdBQVQsRUFBZSxPQUFPLE1BQUssR0FBTCxDQUFTLEVBQVQsQ0FBUDs7QUFFZixtQkFBTyxRQUFRLE9BQVIsQ0FBZ0IsRUFBaEIsQ0FBUDtBQUNILFNBZk0sQ0FBUDtBQWdCSCxLQXJCMkk7QUF1QjVJLE9BdkI0SSxpQkF1Qm5IO0FBQUE7O0FBQUEsWUFBcEIsSUFBb0IsdUVBQWYsRUFBRSxPQUFNLEVBQVIsRUFBZTs7QUFDckIsWUFBSSxLQUFLLEtBQUwsSUFBYyxLQUFLLFVBQXZCLEVBQW9DLE9BQU8sTUFBUCxDQUFlLEtBQUssS0FBcEIsRUFBMkIsS0FBSyxVQUFoQzs7QUFFcEMsZUFBTyxLQUFLLEdBQUwsQ0FBVSxFQUFFLFFBQVEsS0FBSyxNQUFMLElBQWUsS0FBekIsRUFBZ0MsVUFBVSxLQUFLLFFBQS9DLEVBQXlELFNBQVMsS0FBSyxPQUFMLElBQWdCLEVBQWxGLEVBQXNGLElBQUksS0FBSyxLQUFMLEdBQWEsS0FBSyxTQUFMLENBQWdCLEtBQUssS0FBckIsQ0FBYixHQUE0QyxTQUF0SSxFQUFWLEVBQ04sSUFETSxDQUNBLG9CQUFZOztBQUVmLGdCQUFJLEtBQUssT0FBVCxFQUFtQjtBQUNmLHVCQUFLLEtBQUwsR0FBYSxFQUFiO0FBQ0EscUJBQUssT0FBTCxDQUFhLE9BQWIsQ0FBc0I7QUFBQSwyQkFBUSxPQUFLLEtBQUwsQ0FBWSxJQUFaLElBQXFCLEVBQTdCO0FBQUEsaUJBQXRCO0FBQ0g7O0FBRUQsbUJBQUssSUFBTCxHQUFZLE9BQUssS0FBTCxHQUNOLE9BQUssS0FBTCxDQUFZLFFBQVosRUFBc0IsS0FBSyxPQUEzQixDQURNLEdBRU4sS0FBSyxPQUFMLEdBQ0ksT0FBSyxPQUFMLENBQWMsUUFBZCxDQURKLEdBRUksUUFKVjs7QUFNQSxtQkFBSyxJQUFMLENBQVUsS0FBVjs7QUFFQSxtQkFBTyxRQUFRLE9BQVIsQ0FBZ0IsT0FBSyxJQUFyQixDQUFQO0FBQ0gsU0FqQk0sQ0FBUDtBQWtCSCxLQTVDMkk7QUE4QzVJLFNBOUM0SSxpQkE4Q3JJLEVBOUNxSSxFQThDakksSUE5Q2lJLEVBOENqSDtBQUFBOztBQUFBLFlBQVYsSUFBVSx1RUFBTCxFQUFLOztBQUN2QixlQUFPLEtBQUssR0FBTCxDQUFVLEVBQUUsUUFBUSxPQUFWLEVBQW1CLE1BQW5CLEVBQXVCLFVBQVUsS0FBSyxRQUF0QyxFQUFnRCxTQUFTLEtBQUssT0FBTCxJQUFnQixFQUF6RSxFQUE2RSxNQUFNLEtBQUssU0FBTCxDQUFnQixRQUFRLEtBQUssSUFBN0IsQ0FBbkYsRUFBVixFQUNOLElBRE0sQ0FDQSxvQkFBWTtBQUNmLGdCQUFJLE1BQU0sT0FBTixDQUFlLE9BQUssSUFBcEIsQ0FBSixFQUFpQztBQUM3Qix1QkFBSyxJQUFMLEdBQVksT0FBSyxJQUFMLEdBQVksT0FBSyxJQUFMLENBQVUsTUFBVixDQUFrQixRQUFsQixDQUFaLEdBQTJDLENBQUUsUUFBRixDQUF2RDtBQUNBLG9CQUFJLE9BQUssS0FBVCxFQUFpQixPQUFPLElBQVAsQ0FBYSxPQUFLLEtBQWxCLEVBQTBCLE9BQTFCLENBQW1DO0FBQUEsMkJBQVEsT0FBSyxNQUFMLENBQWEsUUFBYixFQUF1QixJQUF2QixDQUFSO0FBQUEsaUJBQW5DO0FBQ3BCOztBQUVELG1CQUFPLFFBQVEsT0FBUixDQUFpQixRQUFqQixDQUFQO0FBQ0gsU0FSTSxDQUFQO0FBU0gsS0F4RDJJO0FBMEQ1SSxRQTFENEksZ0JBMER0SSxLQTFEc0ksRUEwRHJIO0FBQUE7O0FBQUEsWUFBVixJQUFVLHVFQUFMLEVBQUs7O0FBQ25CLGVBQU8sS0FBSyxHQUFMLENBQVUsRUFBRSxRQUFRLE1BQVYsRUFBa0IsVUFBVSxLQUFLLFFBQWpDLEVBQTJDLFNBQVMsS0FBSyxPQUFMLElBQWdCLEVBQXBFLEVBQXdFLE1BQU0sS0FBSyxTQUFMLENBQWdCLFNBQVMsS0FBSyxJQUE5QixDQUE5RSxFQUFWLEVBQ04sSUFETSxDQUNBLG9CQUFZO0FBQ2YsZ0JBQUksTUFBTSxPQUFOLENBQWUsT0FBSyxJQUFwQixDQUFKLEVBQWlDO0FBQzdCLHVCQUFLLElBQUwsR0FBWSxPQUFLLElBQUwsR0FBWSxPQUFLLElBQUwsQ0FBVSxNQUFWLENBQWtCLFFBQWxCLENBQVosR0FBMkMsQ0FBRSxRQUFGLENBQXZEO0FBQ0Esb0JBQUksT0FBSyxLQUFULEVBQWlCLE9BQU8sSUFBUCxDQUFhLE9BQUssS0FBbEIsRUFBMEIsT0FBMUIsQ0FBbUM7QUFBQSwyQkFBUSxPQUFLLE1BQUwsQ0FBYSxRQUFiLEVBQXVCLElBQXZCLENBQVI7QUFBQSxpQkFBbkM7QUFDcEI7O0FBRUQsbUJBQU8sUUFBUSxPQUFSLENBQWlCLFFBQWpCLENBQVA7QUFDSCxTQVJNLENBQVA7QUFTSCxLQXBFMkk7QUFzRTVJLFdBdEU0SSxtQkFzRW5JLElBdEVtSSxFQXNFNUg7QUFBQTs7QUFFWixhQUFLLE9BQUwsQ0FBYztBQUFBLG1CQUFTLE9BQU8sSUFBUCxDQUFhLE9BQUssS0FBbEIsRUFBMEIsT0FBMUIsQ0FBbUM7QUFBQSx1QkFBUSxPQUFLLE1BQUwsQ0FBYSxLQUFiLEVBQW9CLElBQXBCLENBQVI7QUFBQSxhQUFuQyxDQUFUO0FBQUEsU0FBZDs7QUFFQSxlQUFPLElBQVA7QUFDSCxLQTNFMkk7QUE2RTVJLFVBN0U0SSxrQkE2RXBJLEtBN0VvSSxFQTZFN0gsSUE3RTZILEVBNkV0SDtBQUNsQixZQUFJLENBQUMsS0FBSyxLQUFMLENBQVksSUFBWixFQUFvQixNQUFPLElBQVAsQ0FBcEIsQ0FBTCxFQUEyQyxLQUFLLEtBQUwsQ0FBWSxJQUFaLEVBQW9CLE1BQU8sSUFBUCxDQUFwQixJQUFzQyxFQUF0QztBQUMzQyxhQUFLLEtBQUwsQ0FBWSxJQUFaLEVBQW9CLE1BQU8sSUFBUCxDQUFwQixFQUFvQyxJQUFwQyxDQUEwQyxLQUExQztBQUNIO0FBaEYySSxDQUEvSCxDQUFqQjs7Ozs7QUNBQTtBQUNBLElBQUksT0FBTyxPQUFQLElBQWtCLENBQUMsUUFBUSxTQUFSLENBQWtCLE9BQXpDLEVBQWtEO0FBQzlDLFlBQVEsU0FBUixDQUFrQixPQUFsQixHQUNBLFVBQVMsQ0FBVCxFQUFZO0FBQ1IsWUFBSSxVQUFVLENBQUMsS0FBSyxRQUFMLElBQWlCLEtBQUssYUFBdkIsRUFBc0MsZ0JBQXRDLENBQXVELENBQXZELENBQWQ7QUFBQSxZQUNJLENBREo7QUFBQSxZQUVJLEtBQUssSUFGVDtBQUdBLFdBQUc7QUFDQyxnQkFBSSxRQUFRLE1BQVo7QUFDQSxtQkFBTyxFQUFFLENBQUYsSUFBTyxDQUFQLElBQVksUUFBUSxJQUFSLENBQWEsQ0FBYixNQUFvQixFQUF2QyxFQUEyQyxDQUFFO0FBQ2hELFNBSEQsUUFHVSxJQUFJLENBQUwsS0FBWSxLQUFLLEdBQUcsYUFBcEIsQ0FIVDtBQUlBLGVBQU8sRUFBUDtBQUNILEtBVkQ7QUFXSDs7QUFFRDtBQUNBLElBQU0sZ0NBQWlDLFlBQU07QUFDekMsUUFBSSxRQUFRLEtBQUssR0FBTCxFQUFaOztBQUVBLFdBQU8sVUFBQyxRQUFELEVBQWM7O0FBRWpCLFlBQU0sY0FBYyxLQUFLLEdBQUwsRUFBcEI7O0FBRUEsWUFBSSxjQUFjLEtBQWQsR0FBc0IsRUFBMUIsRUFBOEI7QUFDMUIsb0JBQVEsV0FBUjtBQUNBLHFCQUFTLFdBQVQ7QUFDSCxTQUhELE1BR087QUFDSCx1QkFBVyxZQUFNO0FBQ2IseUJBQVMsUUFBVDtBQUNILGFBRkQsRUFFRyxDQUZIO0FBR0g7QUFDSixLQVpEO0FBYUgsQ0FoQnFDLEVBQXRDOztBQWtCQSxPQUFPLHFCQUFQLEdBQStCLE9BQU8scUJBQVAsSUFDQSxPQUFPLDJCQURQLElBRUEsT0FBTyx3QkFGUCxJQUdBLDZCQUgvQjs7QUFLQSxRQUFRLHVCQUFSLEVBQWlDLFFBQWpDOztBQUVBLE9BQU8sT0FBUCxHQUFpQixJQUFqQjs7Ozs7QUN6Q0EsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlOztBQUU1QixXQUFPLFFBQVEsbUJBQVIsQ0FGcUI7O0FBSTVCLGlCQUFhLFFBQVEsZ0JBQVIsQ0FKZTs7QUFNNUIsV0FBTyxRQUFRLFlBQVIsQ0FOcUI7O0FBUTVCLFdBQU8sUUFBUSxlQUFSLENBUnFCOztBQVU1QiwyQkFBdUI7QUFBQSxlQUFVLE9BQU8sTUFBUCxDQUFjLENBQWQsRUFBaUIsV0FBakIsS0FBaUMsT0FBTyxLQUFQLENBQWEsQ0FBYixDQUEzQztBQUFBLEtBVks7O0FBWTVCLGNBWjRCLHdCQVlmO0FBQUE7O0FBRVQsYUFBSyxnQkFBTCxHQUF3QixTQUFTLGFBQVQsQ0FBdUIsVUFBdkIsQ0FBeEI7O0FBRUEsYUFBSyxLQUFMLENBQVcsV0FBWDs7QUFFQSxlQUFPLFVBQVAsR0FBb0IsS0FBSyxNQUFMLENBQVksSUFBWixDQUFpQixJQUFqQixDQUFwQjs7QUFFQSxhQUFLLE1BQUwsR0FDSSxLQUFLLFdBQUwsQ0FBaUIsTUFBakIsQ0FDSSxRQURKLEVBRUksRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLElBQUksS0FBSyxnQkFBWCxFQUE2QixRQUFRLGNBQXJDLEVBQVQsRUFBYixFQUZKLEVBSUMsRUFKRCxDQUlLLFVBSkwsRUFJaUI7QUFBQSxtQkFBUyxNQUFLLFFBQUwsQ0FBZSxLQUFmLENBQVQ7QUFBQSxTQUpqQixDQURKOztBQU9BLGFBQUssTUFBTCxHQUNJLEtBQUssV0FBTCxDQUFpQixNQUFqQixDQUNJLFFBREosRUFFSSxFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxLQUFLLGdCQUFYLEVBQTZCLFFBQVEsT0FBckMsRUFBVCxFQUFiLEVBRkosQ0FESjs7QUFNQSxhQUFLLE1BQUw7QUFDSCxLQWxDMkI7QUFvQzVCLFVBcEM0QixvQkFvQ25CO0FBQ0wsYUFBSyxPQUFMLENBQWMsT0FBTyxRQUFQLENBQWdCLFFBQWhCLENBQXlCLEtBQXpCLENBQStCLEdBQS9CLEVBQW9DLEtBQXBDLENBQTBDLENBQTFDLENBQWQ7QUFDSCxLQXRDMkI7QUF3QzVCLFdBeEM0QixtQkF3Q25CLElBeENtQixFQXdDWjtBQUFBOztBQUNaLFlBQU0sT0FBTyxLQUFLLEtBQUwsQ0FBWSxLQUFLLHFCQUFMLENBQTRCLEtBQUssQ0FBTCxDQUE1QixDQUFaLElBQXNELEtBQUssQ0FBTCxDQUF0RCxHQUFnRSxNQUE3RTs7QUFFQSxZQUFJLFNBQVMsS0FBSyxXQUFsQixFQUFnQyxPQUFPLEtBQUssS0FBTCxDQUFZLElBQVosRUFBbUIsWUFBbkIsQ0FBaUMsSUFBakMsQ0FBUDs7QUFFaEMsYUFBSyxXQUFMOztBQUVBLGdCQUFRLEdBQVIsQ0FBYSxPQUFPLElBQVAsQ0FBYSxLQUFLLEtBQWxCLEVBQTBCLEdBQTFCLENBQStCO0FBQUEsbUJBQVEsT0FBSyxLQUFMLENBQVksSUFBWixFQUFtQixJQUFuQixFQUFSO0FBQUEsU0FBL0IsQ0FBYixFQUNDLElBREQsQ0FDTyxZQUFNOztBQUVULG1CQUFLLFdBQUwsR0FBbUIsSUFBbkI7O0FBRUEsZ0JBQUksT0FBSyxLQUFMLENBQVksSUFBWixDQUFKLEVBQXlCLE9BQU8sT0FBSyxLQUFMLENBQVksSUFBWixFQUFtQixZQUFuQixDQUFpQyxJQUFqQyxDQUFQOztBQUV6QixtQkFBTyxRQUFRLE9BQVIsQ0FDSCxPQUFLLEtBQUwsQ0FBWSxJQUFaLElBQ0ksT0FBSyxXQUFMLENBQWlCLE1BQWpCLENBQXlCLElBQXpCLEVBQStCO0FBQzNCLDJCQUFXLEVBQUUsT0FBTyxFQUFFLElBQUksT0FBSyxnQkFBWCxFQUFULEVBRGdCO0FBRTNCLHNCQUFNLEVBQUUsT0FBTyxJQUFULEVBQWUsVUFBVSxJQUF6QjtBQUZxQixhQUEvQixFQUlDLEVBSkQsQ0FJSyxVQUpMLEVBSWlCO0FBQUEsdUJBQVMsT0FBSyxRQUFMLENBQWUsS0FBZixDQUFUO0FBQUEsYUFKakIsRUFLQyxFQUxELENBS0ssU0FMTCxFQUtnQjtBQUFBLHVCQUFNLE9BQU8sT0FBSyxLQUFMLENBQVksSUFBWixDQUFiO0FBQUEsYUFMaEIsQ0FGRCxDQUFQO0FBU0gsU0FoQkQsRUFpQkMsS0FqQkQsQ0FpQlEsS0FBSyxLQWpCYjtBQWtCSCxLQWpFMkI7QUFtRTVCLFlBbkU0QixvQkFtRWxCLFFBbkVrQixFQW1FUDtBQUNqQixZQUFJLGFBQWEsT0FBTyxRQUFQLENBQWdCLFFBQWpDLEVBQTRDLFFBQVEsU0FBUixDQUFtQixFQUFuQixFQUF1QixFQUF2QixFQUEyQixRQUEzQjtBQUM1QyxhQUFLLE1BQUw7QUFDSCxLQXRFMkI7QUF3RTVCLGVBeEU0Qix5QkF3RWQ7QUFDVixlQUFPLE1BQVAsQ0FBZSxFQUFFLEtBQUssQ0FBUCxFQUFVLE1BQU0sQ0FBaEIsRUFBbUIsVUFBVSxRQUE3QixFQUFmO0FBQ0g7QUExRTJCLENBQWYsRUE0RWQsRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFULEVBQWEsVUFBVSxJQUF2QixFQUFmLEVBQThDLE9BQU8sRUFBRSxPQUFPLEVBQVQsRUFBckQsRUE1RWMsQ0FBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlLEVBQWYsRUFBbUIsUUFBUSxhQUFSLENBQW5CLEVBQTJDLEVBQTNDLENBQWpCOzs7OztBQ0FBLE9BQU8sT0FBUCxHQUFpQixPQUFPLE1BQVAsQ0FBZSxFQUFmLEVBQW1CLFFBQVEsYUFBUixDQUFuQixFQUEyQzs7QUFFeEQsWUFBUTtBQUNKLGFBQUs7QUFERCxLQUZnRDs7QUFNeEQsY0FOd0Qsc0JBTTVDLENBTjRDLEVBTXhDO0FBQ1osWUFBTSxTQUFTLEVBQUUsTUFBRixDQUFTLE9BQVQsS0FBcUIsSUFBckIsR0FBNEIsRUFBRSxNQUE5QixHQUF1QyxFQUFFLE1BQUYsQ0FBUyxPQUFULENBQWlCLElBQWpCLENBQXREO0FBQUEsWUFDTSxPQUFPLE9BQU8sWUFBUCxDQUFvQixXQUFwQixDQURiOztBQUdBLGFBQUssSUFBTCxDQUFXLFVBQVgsRUFBdUIsSUFBdkI7QUFDSDtBQVh1RCxDQUEzQyxDQUFqQjs7Ozs7QUNBQSxPQUFPLE9BQVAsR0FBaUIsT0FBTyxNQUFQLENBQWUsRUFBZixFQUFtQixRQUFRLGFBQVIsQ0FBbkIsRUFBMkM7O0FBRXhELFlBQVE7QUFDSixrQkFBVSxPQUROO0FBRUosa0JBQVU7QUFGTixLQUZnRDs7QUFPeEQsbUJBUHdELDZCQU90QztBQUFFLGFBQUssSUFBTCxDQUFXLFVBQVgsRUFBdUIsVUFBdkI7QUFBcUMsS0FQRDtBQVN4RCxtQkFUd0QsNkJBU3RDO0FBQUUsYUFBSyxJQUFMLENBQVcsVUFBWCxFQUF1QixVQUF2QjtBQUFxQztBQVRELENBQTNDLENBQWpCOzs7OztBQ0FBLE9BQU8sT0FBUCxHQUFpQixPQUFPLE1BQVAsQ0FBZSxFQUFmLEVBQW1CLFFBQVEsYUFBUixDQUFuQixFQUEyQzs7QUFFeEQsWUFBUTtBQUNKLHFCQUFhO0FBRFQsS0FGZ0Q7O0FBTXhELFdBQU8sT0FBTyxNQUFQLENBQWUsUUFBUSxrQkFBUixDQUFmLENBTmlEOztBQVF4RCxhQVJ3RCx1QkFRNUM7QUFDUixhQUFLLEdBQUwsQ0FBUyxJQUFULENBQWMsS0FBZCxHQUFzQixFQUF0QjtBQUNBLGFBQUssR0FBTCxDQUFTLE9BQVQsQ0FBaUIsS0FBakIsR0FBeUIsRUFBekI7QUFDQSxhQUFLLEdBQUwsQ0FBUyxPQUFULENBQWlCLEtBQWpCLEdBQXlCLEVBQXpCO0FBQ0gsS0FadUQ7QUFjeEQsb0JBZHdELDhCQWNyQztBQUFBOztBQUNmLFlBQUksS0FBSyxVQUFULEVBQXNCOztBQUV0QixhQUFLLGFBQUw7O0FBRUEsYUFBSyxRQUFMLEdBQ0MsSUFERCxDQUNPLGtCQUFVO0FBQ2IsZ0JBQUksQ0FBQyxNQUFMLEVBQWMsT0FBTyxRQUFRLE9BQVIsQ0FBaUIsTUFBSyxXQUFMLEVBQWpCLENBQVA7O0FBRWQsbUJBQU8sTUFBSyxLQUFMLENBQVcsSUFBWCxHQUNOLElBRE0sQ0FDQSxvQkFBWTtBQUNmLHVCQUFPLE1BQUssS0FBTCxDQUFXLGFBQVgsQ0FBMEIsU0FBMUIsRUFBcUMsbUNBQXJDLEVBQ04sSUFETSxDQUNBLFlBQU07QUFDVCwwQkFBSyxJQUFMLENBQVcsVUFBWCxFQUF1QixHQUF2QjtBQUNBLDBCQUFLLFdBQUw7QUFDQSwwQkFBSyxTQUFMO0FBQ0gsaUJBTE0sQ0FBUDtBQU1ILGFBUk0sRUFTTixLQVRNLENBU0MsYUFBSztBQUNULHNCQUFLLEtBQUwsQ0FBVyxhQUFYLENBQTBCLE9BQTFCLEVBQW1DLEtBQUssRUFBRSxPQUFQLEdBQWlCLEVBQUUsT0FBbkIseURBQW5DO0FBQ0Esc0JBQUssV0FBTDtBQUNILGFBWk0sQ0FBUDtBQWFILFNBakJELEVBa0JDLEtBbEJELENBa0JRLGFBQUs7QUFBRSxrQkFBSyxLQUFMLENBQVcsQ0FBWCxFQUFlLE1BQUssVUFBTCxHQUFrQixLQUFsQjtBQUF5QixTQWxCdkQ7QUFtQkgsS0F0Q3VEO0FBd0N4RCxlQXhDd0QseUJBd0MxQztBQUNWLGFBQUssVUFBTCxHQUFrQixLQUFsQjtBQUNBLGFBQUssR0FBTCxDQUFTLFNBQVQsQ0FBbUIsU0FBbkIsQ0FBNkIsTUFBN0IsQ0FBb0MsWUFBcEM7QUFDSCxLQTNDdUQ7QUE2Q3hELGlCQTdDd0QsMkJBNkN4QztBQUNaLGFBQUssVUFBTCxHQUFrQixJQUFsQjtBQUNBLGFBQUssR0FBTCxDQUFTLFNBQVQsQ0FBbUIsU0FBbkIsQ0FBNkIsR0FBN0IsQ0FBaUMsWUFBakM7QUFDSCxLQWhEdUQ7QUFrRHhELGNBbER3RCx3QkFrRDNDO0FBQUE7O0FBQ1QsZUFBTyxJQUFQLENBQWEsS0FBSyxHQUFsQixFQUF3QixPQUF4QixDQUFpQyxnQkFBUTtBQUNyQyxnQkFBTSxLQUFLLE9BQUssR0FBTCxDQUFVLElBQVYsQ0FBWDs7QUFFQSxnQkFBSSxTQUFTLE1BQVQsSUFBbUIsU0FBUyxTQUFoQyxFQUE0QyxHQUFHLGdCQUFILENBQXFCLE9BQXJCLEVBQThCO0FBQUEsdUJBQU0sR0FBRyxTQUFILENBQWEsTUFBYixDQUFvQixPQUFwQixDQUFOO0FBQUEsYUFBOUI7QUFDL0MsU0FKRDs7QUFNQSxlQUFPLElBQVA7QUFDSCxLQTFEdUQ7QUE0RHhELFlBNUR3RCxzQkE0RDdDO0FBQUE7O0FBQ1AsWUFBSSxLQUFLLElBQVQ7O0FBRUEsZUFBTyxJQUFQLENBQWEsS0FBSyxHQUFsQixFQUF3QixPQUF4QixDQUFpQyxnQkFBUTtBQUNyQyxnQkFBTSxLQUFLLE9BQUssR0FBTCxDQUFVLElBQVYsQ0FBWDs7QUFFQSxnQkFBSSxTQUFTLE1BQVQsSUFBbUIsU0FBUyxTQUFoQyxFQUE0Qzs7QUFFNUMsZ0JBQUksT0FBTyxJQUFQLElBQWUsQ0FBQyxPQUFLLEtBQUwsQ0FBVyxRQUFYLENBQXFCLElBQXJCLEVBQTJCLEdBQUcsS0FBOUIsQ0FBcEIsRUFBNEQ7QUFDeEQsdUJBQUssS0FBTCxDQUFXLGFBQVgsQ0FBMEIsT0FBMUIsRUFBbUMsT0FBSyxLQUFMLENBQVcsTUFBWCxDQUFtQixJQUFuQixFQUEwQixLQUE3RDtBQUNBLG1CQUFHLGNBQUgsQ0FBbUIsRUFBRSxVQUFVLFFBQVosRUFBbkI7QUFDQSxtQkFBRyxTQUFILENBQWEsR0FBYixDQUFrQixPQUFsQjtBQUNBLHFCQUFLLEtBQUw7QUFDSCxhQUxELE1BS08sSUFBSSxPQUFLLEtBQUwsQ0FBVyxRQUFYLENBQXFCLElBQXJCLEVBQTJCLEdBQUcsS0FBOUIsQ0FBSixFQUE0QztBQUMvQyx1QkFBSyxLQUFMLENBQVcsSUFBWCxDQUFpQixJQUFqQixJQUEwQixHQUFHLEtBQUgsQ0FBUyxJQUFULEVBQTFCO0FBQ0g7QUFDSixTQWJEOztBQWVBLGVBQU8sUUFBUSxPQUFSLENBQWlCLEVBQWpCLENBQVA7QUFDSDtBQS9FdUQsQ0FBM0MsQ0FBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlLEVBQWYsRUFBbUIsUUFBUSxhQUFSLENBQW5CLEVBQTJDLEVBQTNDLENBQWpCOzs7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlLEVBQWYsRUFBb0IsUUFBUSx1QkFBUixDQUFwQixFQUFzRCxRQUFRLFFBQVIsRUFBa0IsWUFBbEIsQ0FBK0IsU0FBckYsRUFBZ0c7O0FBRTdHLFdBQU8sUUFBUSxxQkFBUixDQUZzRzs7QUFJN0cscUJBQWlCLFFBQVEsdUJBQVIsQ0FKNEY7O0FBTTdHLGFBTjZHLHFCQU1sRyxHQU5rRyxFQU03RixLQU42RixFQU10RixFQU5zRixFQU1qRjtBQUFBOztBQUN4QixZQUFJLE1BQU0sS0FBSyxDQUFFLEVBQUYsQ0FBTCxHQUFjLE1BQU0sT0FBTixDQUFlLEtBQUssR0FBTCxDQUFVLEdBQVYsQ0FBZixJQUFtQyxLQUFLLEdBQUwsQ0FBVSxHQUFWLENBQW5DLEdBQXFELENBQUUsS0FBSyxHQUFMLENBQVUsR0FBVixDQUFGLENBQTdFO0FBQ0EsWUFBSSxPQUFKLENBQWE7QUFBQSxtQkFBTSxHQUFHLGdCQUFILENBQXFCLFNBQVMsT0FBOUIsRUFBdUM7QUFBQSx1QkFBSyxhQUFXLE1BQUsscUJBQUwsQ0FBMkIsR0FBM0IsQ0FBWCxHQUE2QyxNQUFLLHFCQUFMLENBQTJCLEtBQTNCLENBQTdDLEVBQW9GLENBQXBGLENBQUw7QUFBQSxhQUF2QyxDQUFOO0FBQUEsU0FBYjtBQUNILEtBVDRHOzs7QUFXN0csMkJBQXVCO0FBQUEsZUFBVSxPQUFPLE1BQVAsQ0FBYyxDQUFkLEVBQWlCLFdBQWpCLEtBQWlDLE9BQU8sS0FBUCxDQUFhLENBQWIsQ0FBM0M7QUFBQSxLQVhzRjs7QUFhN0csZUFiNkcseUJBYS9GO0FBQ1YsYUFBSyxlQUFMLEdBQXVCLEVBQXZCOztBQUVBLFlBQUksS0FBSyxhQUFMLElBQXdCLENBQUMsS0FBSyxJQUFMLENBQVUsVUFBVixFQUE3QixFQUF3RCxPQUFPLEtBQUssV0FBTCxFQUFQO0FBQ3hELFlBQUksS0FBSyxJQUFMLElBQWEsQ0FBQyxLQUFLLFNBQUwsQ0FBZ0IsS0FBSyxJQUFyQixDQUFsQixFQUFnRCxPQUFPLEtBQUssU0FBTCxFQUFQOztBQUVoRCxlQUFPLEtBQUssVUFBTCxHQUFrQixNQUFsQixFQUFQO0FBQ0gsS0FwQjRHO0FBc0I3RyxrQkF0QjZHLDBCQXNCN0YsR0F0QjZGLEVBc0J4RixFQXRCd0YsRUFzQm5GO0FBQUE7O0FBQ3RCLFlBQUksZUFBYyxLQUFLLE1BQUwsQ0FBWSxHQUFaLENBQWQsQ0FBSjs7QUFFQSxZQUFJLFNBQVMsUUFBYixFQUF3QjtBQUFFLGlCQUFLLFNBQUwsQ0FBZ0IsR0FBaEIsRUFBcUIsS0FBSyxNQUFMLENBQVksR0FBWixDQUFyQixFQUF1QyxFQUF2QztBQUE2QyxTQUF2RSxNQUNLLElBQUksTUFBTSxPQUFOLENBQWUsS0FBSyxNQUFMLENBQVksR0FBWixDQUFmLENBQUosRUFBd0M7QUFDekMsaUJBQUssTUFBTCxDQUFhLEdBQWIsRUFBbUIsT0FBbkIsQ0FBNEI7QUFBQSx1QkFBWSxPQUFLLFNBQUwsQ0FBZ0IsR0FBaEIsRUFBcUIsUUFBckIsQ0FBWjtBQUFBLGFBQTVCO0FBQ0gsU0FGSSxNQUVFO0FBQ0gsaUJBQUssU0FBTCxDQUFnQixHQUFoQixFQUFxQixLQUFLLE1BQUwsQ0FBWSxHQUFaLEVBQWlCLEtBQXRDO0FBQ0g7QUFDSixLQS9CNEc7QUFpQzdHLFVBakM2RyxtQkFpQ3JHLE1BakNxRyxFQWlDOUU7QUFBQTs7QUFBQSxZQUFmLE9BQWUsdUVBQVAsSUFBTzs7QUFDM0IsZUFBTyxLQUFLLElBQUwsQ0FBVyxNQUFYLEVBQW1CLE9BQW5CLEVBQ04sSUFETSxDQUNBLFlBQU07QUFDVCxtQkFBSyxHQUFMLENBQVMsU0FBVCxDQUFtQixVQUFuQixDQUE4QixXQUE5QixDQUEyQyxPQUFLLEdBQUwsQ0FBUyxTQUFwRDtBQUNBLG1CQUFPLFFBQVEsT0FBUixDQUFpQixPQUFLLElBQUwsQ0FBVSxTQUFWLENBQWpCLENBQVA7QUFDSCxTQUpNLENBQVA7QUFLSCxLQXZDNEc7OztBQXlDN0csWUFBUSxFQXpDcUc7O0FBMkM3RyxzQkEzQzZHLGdDQTJDeEY7QUFDakIsWUFBTSxLQUFLLE9BQU8sTUFBUCxDQUFlLEtBQUssSUFBTCxHQUFZLEVBQUUsTUFBTSxLQUFLLElBQUwsQ0FBVSxJQUFsQixFQUFaLEdBQXVDLEVBQXRELENBQVg7O0FBRUEsWUFBSSxLQUFLLEtBQVQsRUFBaUI7QUFDYixlQUFHLEtBQUgsR0FBVyxLQUFLLEtBQUwsQ0FBVyxJQUF0Qjs7QUFFQSxnQkFBSSxLQUFLLEtBQUwsQ0FBVyxJQUFmLEVBQXNCLEdBQUcsSUFBSCxHQUFVLEtBQUssS0FBTCxDQUFXLElBQXJCO0FBQ3pCOztBQUVELFlBQUksS0FBSyxlQUFULEVBQTJCLEdBQUcsSUFBSCxHQUFVLE9BQU8sS0FBSyxlQUFaLEtBQWdDLFVBQWhDLEdBQTZDLEtBQUssZUFBTCxFQUE3QyxHQUFzRSxLQUFLLGVBQXJGOztBQUUzQixlQUFPLEVBQVA7QUFDSCxLQXZENEc7QUF5RDdHLGVBekQ2Ryx5QkF5RC9GO0FBQUE7O0FBQ1YsYUFBSyxPQUFMLENBQWEsTUFBYixDQUFxQixPQUFyQixFQUE4QixFQUFFLFdBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxTQUFTLGFBQVQsQ0FBdUIsVUFBdkIsQ0FBTixFQUFULEVBQWIsRUFBOUIsRUFDSyxJQURMLENBQ1csVUFEWCxFQUN1QjtBQUFBLG1CQUFNLE9BQUssT0FBTCxFQUFOO0FBQUEsU0FEdkI7O0FBR0EsZUFBTyxJQUFQO0FBQ0gsS0E5RDRHO0FBZ0U3RyxRQWhFNkcsZ0JBZ0V2RyxNQWhFdUcsRUFnRWhGO0FBQUE7O0FBQUEsWUFBZixPQUFlLHVFQUFQLElBQU87QUFBRSxlQUFPLEtBQUssTUFBTCxDQUFhLEtBQUssR0FBTCxDQUFTLFNBQXRCLEVBQWlDLE1BQWpDLEVBQXlDLE9BQXpDLEVBQW1ELElBQW5ELENBQXlEO0FBQUEsbUJBQU0sT0FBSyxJQUFMLENBQVUsUUFBVixDQUFOO0FBQUEsU0FBekQsQ0FBUDtBQUE2RixLQWhFZjtBQWtFN0csV0FsRTZHLG1CQWtFcEcsRUFsRW9HLEVBa0VoRyxLQWxFZ0csRUFrRXpGLE9BbEV5RixFQWtFaEYsSUFsRWdGLEVBa0V6RTtBQUNoQyxXQUFHLG1CQUFILENBQXdCLGNBQXhCLEVBQXdDLEtBQU0sSUFBTixDQUF4QztBQUNBLFdBQUcsU0FBSCxDQUFhLEdBQWIsQ0FBaUIsUUFBakI7QUFDQSxXQUFHLFNBQUgsQ0FBYSxNQUFiLENBQXFCLEtBQXJCO0FBQ0EsZUFBTyxLQUFLLElBQUwsQ0FBUDtBQUNBO0FBQ0gsS0F4RTRHO0FBMEU3RyxVQTFFNkcsa0JBMEVyRyxFQTFFcUcsRUEwRWpHLE1BMUVpRyxFQTBFMUU7QUFBQTs7QUFBQSxZQUFmLE9BQWUsdUVBQVAsSUFBTzs7QUFDL0IsWUFBSSxLQUFLLFFBQUwsQ0FBZSxFQUFmLENBQUosRUFBMEIsT0FBTyxRQUFRLE9BQVIsRUFBUDs7QUFFMUIsWUFBTSxPQUFPLElBQUksSUFBSixHQUFXLE9BQVgsRUFBYjtBQUFBLFlBQ0ksT0FBVSxJQUFWLFNBREo7O0FBR0EsZUFBTyxJQUFJLE9BQUosQ0FBYSxtQkFBVztBQUMzQixnQkFBSSxDQUFDLE9BQUwsRUFBZSxPQUFPLFFBQVMsR0FBRyxTQUFILENBQWEsR0FBYixDQUFpQixRQUFqQixDQUFULENBQVA7O0FBRWYsZ0JBQU0seUJBQXVCLFNBQVMsT0FBVCxHQUFtQixFQUExQyxDQUFOO0FBQ0EsbUJBQU0sSUFBTixJQUFlO0FBQUEsdUJBQUssT0FBSyxPQUFMLENBQWMsRUFBZCxFQUFrQixLQUFsQixFQUF5QixPQUF6QixFQUFrQyxJQUFsQyxDQUFMO0FBQUEsYUFBZjtBQUNBLGVBQUcsZ0JBQUgsQ0FBcUIsY0FBckIsRUFBcUMsT0FBTSxJQUFOLENBQXJDO0FBQ0EsZUFBRyxTQUFILENBQWEsR0FBYixDQUFrQixLQUFsQjtBQUNILFNBUE0sQ0FBUDtBQVFILEtBeEY0RztBQTBGN0csa0JBMUY2RywwQkEwRjdGLEdBMUY2RixFQTBGdkY7QUFDbEIsWUFBSSxRQUFRLFNBQVMsV0FBVCxFQUFaO0FBQ0E7QUFDQSxjQUFNLFVBQU4sQ0FBaUIsU0FBUyxvQkFBVCxDQUE4QixLQUE5QixFQUFxQyxJQUFyQyxDQUEwQyxDQUExQyxDQUFqQjtBQUNBLGVBQU8sTUFBTSx3QkFBTixDQUFnQyxHQUFoQyxDQUFQO0FBQ0gsS0EvRjRHO0FBaUc3RyxjQWpHNkcsd0JBaUdoRztBQUNULGVBQU8sT0FBTyxNQUFQLENBQWUsSUFBZixFQUFxQixFQUFFLEtBQUssRUFBUCxFQUFZLE9BQU8sRUFBRSxNQUFNLFNBQVIsRUFBbUIsTUFBTSxXQUF6QixFQUFzQyxNQUFNLFdBQTVDLEVBQW5CLEVBQThFLE9BQU8sRUFBckYsRUFBckIsQ0FBUDtBQUNILEtBbkc0RztBQXFHN0csYUFyRzZHLHFCQXFHbEcsSUFyR2tHLEVBcUczRjtBQUNkLFlBQUksQ0FBQyxLQUFLLFlBQVYsRUFBeUIsT0FBTyxJQUFQO0FBQ3pCLGVBQU8sS0FBSyxZQUFMLElBQXFCLEtBQUssSUFBTCxDQUFVLEtBQVYsQ0FBZ0IsUUFBaEIsQ0FBMEIsS0FBSyxZQUEvQixDQUE1QjtBQUNILEtBeEc0RztBQTBHN0csWUExRzZHLG9CQTBHbkcsRUExR21HLEVBMEc5RjtBQUNYLFlBQU0sVUFBVSxNQUFNLEtBQUssR0FBTCxDQUFTLFNBQS9CO0FBQ0EsZUFBTyxRQUFRLFNBQVIsQ0FBa0IsUUFBbEIsQ0FBMkIsUUFBM0IsQ0FBUDtBQUNILEtBN0c0RztBQStHN0csV0EvRzZHLHFCQStHbkc7O0FBRU4sWUFBSSxDQUFDLEtBQUssU0FBTCxDQUFnQixLQUFLLElBQXJCLENBQUwsRUFBbUMsT0FBTyxLQUFLLFNBQUwsRUFBUDs7QUFFbkMsYUFBSyxVQUFMLEdBQWtCLE1BQWxCO0FBQ0gsS0FwSDRHO0FBc0g3RyxnQkF0SDZHLDBCQXNIOUY7QUFDWCxlQUFPLEtBQUssSUFBTCxFQUFQO0FBQ0gsS0F4SDRHO0FBMEg3RyxnQkExSDZHLDBCQTBIOUY7QUFDWCxjQUFNLG9CQUFOO0FBQ0EsZUFBTyxJQUFQO0FBQ0gsS0E3SDRHO0FBK0g3RyxjQS9INkcsd0JBK0hoRztBQUFFLGVBQU8sSUFBUDtBQUFhLEtBL0hpRjtBQWlJN0csVUFqSTZHLG9CQWlJcEc7QUFDTCxZQUFJLEtBQUssSUFBVCxFQUFnQixLQUFLLEtBQUwsR0FBYSxPQUFPLE1BQVAsQ0FBZSxLQUFLLEtBQXBCLEVBQTJCLEVBQTNCLEVBQWlDLFdBQWpDLENBQThDLEtBQUssSUFBbkQsQ0FBYjs7QUFFaEIsYUFBSyxhQUFMLENBQW9CLEVBQUUsVUFBVSxLQUFLLFFBQUwsQ0FBZSxLQUFLLGtCQUFMLEVBQWYsQ0FBWixFQUF3RCxXQUFXLEtBQUssU0FBTCxJQUFrQixFQUFFLElBQUksU0FBUyxJQUFmLEVBQXJGLEVBQTRHLFFBQVEsSUFBcEgsRUFBcEI7O0FBRUEsYUFBSyxjQUFMOztBQUVBLFlBQUksS0FBSyxJQUFULEVBQWdCO0FBQUUsaUJBQUssSUFBTCxHQUFhLEtBQUssZUFBTCxDQUFxQixHQUFyQixDQUEwQixLQUFLLElBQUwsQ0FBVSxJQUFWLENBQWUsSUFBZixDQUExQjtBQUFrRDs7QUFFakYsZUFBTyxLQUFLLFVBQUwsRUFBUDtBQUNILEtBM0k0RztBQTZJN0csa0JBN0k2Ryw0QkE2STVGO0FBQUE7O0FBQ2IsYUFBSyxlQUFMLENBQXFCLE9BQXJCLENBQThCLGVBQU87QUFDakMsZ0JBQU0sT0FBTyxJQUFJLElBQWpCOztBQUVBLGdCQUFJLE9BQU8sRUFBWDs7QUFFQSxnQkFBSSxPQUFLLEtBQUwsSUFBYyxPQUFLLEtBQUwsQ0FBWSxJQUFaLENBQWxCLEVBQXVDLE9BQU8sUUFBTyxPQUFLLEtBQUwsQ0FBWSxJQUFaLENBQVAsTUFBOEIsUUFBOUIsR0FBeUMsT0FBSyxLQUFMLENBQVksSUFBWixDQUF6QyxHQUE4RCxRQUFRLEtBQVIsQ0FBZSxPQUFLLEtBQUwsQ0FBWSxJQUFaLENBQWYsVUFBeUMsRUFBekMsQ0FBckU7O0FBRXZDLG1CQUFLLEtBQUwsQ0FBWSxJQUFaLElBQXFCLE9BQUssT0FBTCxDQUFhLE1BQWIsQ0FBcUIsR0FBckIsRUFBMEIsT0FBTyxNQUFQLENBQWUsRUFBRSxXQUFXLEVBQUUsT0FBTyxFQUFFLElBQUksSUFBSSxFQUFWLEVBQWMsUUFBUSxjQUF0QixFQUFULEVBQWIsRUFBZixFQUFpRixFQUFFLE1BQU0sRUFBRSxPQUFPLElBQVQsRUFBUixFQUFqRixDQUExQixDQUFyQjtBQUNBLGdCQUFJLEVBQUosQ0FBTyxNQUFQO0FBQ0gsU0FURDs7QUFXQSxlQUFPLEtBQUssZUFBWjs7QUFFQSxlQUFPLElBQVA7QUFDSCxLQTVKNEc7QUE4SjdHLGFBOUo2Ryx1QkE4SmpHO0FBQUE7O0FBQ1IsYUFBSyxLQUFMLENBQVcsSUFBWCxDQUFpQixPQUFqQixFQUEwQixtQ0FBMUIsRUFDQyxLQURELENBQ1EsYUFBSztBQUFFLG1CQUFLLEtBQUwsQ0FBWSxDQUFaLEVBQWlCLE9BQUssSUFBTCxDQUFXLFVBQVg7QUFBOEIsU0FEOUQsRUFFQyxJQUZELENBRU87QUFBQSxtQkFBTSxPQUFLLElBQUwsQ0FBVyxVQUFYLE1BQU47QUFBQSxTQUZQOztBQUlBLGVBQU8sSUFBUDtBQUNILEtBcEs0RztBQXNLN0csUUF0SzZHLGdCQXNLdkcsTUF0S3VHLEVBc0toRjtBQUFBOztBQUFBLFlBQWYsT0FBZSx1RUFBUCxJQUFPO0FBQUUsZUFBTyxLQUFLLE1BQUwsQ0FBYSxLQUFLLEdBQUwsQ0FBUyxTQUF0QixFQUFpQyxNQUFqQyxFQUF5QyxPQUF6QyxFQUFtRCxJQUFuRCxDQUF5RDtBQUFBLG1CQUFNLE9BQUssSUFBTCxDQUFVLE9BQVYsQ0FBTjtBQUFBLFNBQXpELENBQVA7QUFBNEYsS0F0S2Q7QUF3SzdHLFdBeEs2RyxtQkF3S3BHLEVBeEtvRyxFQXdLaEcsS0F4S2dHLEVBd0t6RixPQXhLeUYsRUF3S2hGLElBeEtnRixFQXdLekU7QUFDaEMsV0FBRyxtQkFBSCxDQUF3QixjQUF4QixFQUF3QyxLQUFLLElBQUwsQ0FBeEM7QUFDQSxXQUFHLFNBQUgsQ0FBYSxNQUFiLENBQXFCLEtBQXJCO0FBQ0EsZUFBTyxLQUFNLElBQU4sQ0FBUDtBQUNBO0FBQ0gsS0E3SzRHO0FBK0s3RyxVQS9LNkcsa0JBK0tyRyxFQS9LcUcsRUErS2pHLE1BL0tpRyxFQStLMUU7QUFBQTs7QUFBQSxZQUFmLE9BQWUsdUVBQVAsSUFBTzs7QUFDL0IsWUFBSSxDQUFDLEtBQUssUUFBTCxDQUFlLEVBQWYsQ0FBTCxFQUEyQixPQUFPLFFBQVEsT0FBUixFQUFQOztBQUUzQixZQUFNLE9BQU8sSUFBSSxJQUFKLEdBQVcsT0FBWCxFQUFiO0FBQUEsWUFDSSxPQUFVLElBQVYsU0FESjs7QUFHQSxlQUFPLElBQUksT0FBSixDQUFhLG1CQUFXO0FBQzNCLGVBQUcsU0FBSCxDQUFhLE1BQWIsQ0FBb0IsUUFBcEI7O0FBRUEsZ0JBQUksQ0FBQyxPQUFMLEVBQWUsT0FBTyxTQUFQOztBQUVmLGdCQUFNLHdCQUFzQixTQUFTLE9BQVQsR0FBbUIsRUFBekMsQ0FBTjtBQUNBLG9CQUFNLElBQU4sSUFBZTtBQUFBLHVCQUFLLFFBQUssT0FBTCxDQUFjLEVBQWQsRUFBa0IsS0FBbEIsRUFBeUIsT0FBekIsRUFBa0MsSUFBbEMsQ0FBTDtBQUFBLGFBQWY7QUFDQSxlQUFHLGdCQUFILENBQXFCLGNBQXJCLEVBQXFDLFFBQU0sSUFBTixDQUFyQztBQUNBLGVBQUcsU0FBSCxDQUFhLEdBQWIsQ0FBa0IsS0FBbEI7QUFDSCxTQVRNLENBQVA7QUFVSCxLQS9MNEc7QUFpTTdHLFdBak02RyxtQkFpTXBHLEVBak1vRyxFQWlNL0Y7QUFDVixZQUFJLE1BQU0sR0FBRyxZQUFILENBQWlCLEtBQUssS0FBTCxDQUFXLElBQTVCLEtBQXNDLFdBQWhEOztBQUVBLFlBQUksUUFBUSxXQUFaLEVBQTBCLEdBQUcsU0FBSCxDQUFhLEdBQWIsQ0FBa0IsS0FBSyxJQUF2Qjs7QUFFMUIsYUFBSyxHQUFMLENBQVUsR0FBVixJQUFrQixNQUFNLE9BQU4sQ0FBZSxLQUFLLEdBQUwsQ0FBVSxHQUFWLENBQWYsSUFDWixLQUFLLEdBQUwsQ0FBVSxHQUFWLEVBQWdCLE1BQWhCLENBQXdCLEVBQXhCLENBRFksR0FFVixLQUFLLEdBQUwsQ0FBVSxHQUFWLE1BQW9CLFNBQXRCLEdBQ0ksQ0FBRSxLQUFLLEdBQUwsQ0FBVSxHQUFWLENBQUYsRUFBbUIsRUFBbkIsQ0FESixHQUVJLEVBSlY7O0FBTUEsV0FBRyxlQUFILENBQW1CLEtBQUssS0FBTCxDQUFXLElBQTlCOztBQUVBLFlBQUksS0FBSyxNQUFMLENBQWEsR0FBYixDQUFKLEVBQXlCLEtBQUssY0FBTCxDQUFxQixHQUFyQixFQUEwQixFQUExQjtBQUM1QixLQS9NNEc7QUFpTjdHLGlCQWpONkcseUJBaU45RixPQWpOOEYsRUFpTnBGO0FBQUE7O0FBQ3JCLFlBQUksV0FBVyxLQUFLLGNBQUwsQ0FBcUIsUUFBUSxRQUE3QixDQUFmO0FBQUEsWUFDSSxpQkFBZSxLQUFLLEtBQUwsQ0FBVyxJQUExQixNQURKO0FBQUEsWUFFSSxxQkFBbUIsS0FBSyxLQUFMLENBQVcsSUFBOUIsTUFGSjtBQUFBLFlBR0ksVUFBVSxTQUFTLGFBQVQsQ0FBdUIsR0FBdkIsQ0FIZDs7QUFLQSxZQUFJLFFBQVEsTUFBUixJQUFrQixRQUFRLFlBQVIsQ0FBc0IsS0FBSyxLQUFMLENBQVcsSUFBakMsQ0FBdEIsRUFBZ0UsS0FBSyxPQUFMLENBQWMsT0FBZDtBQUNoRSxpQkFBUyxnQkFBVCxDQUE4QixRQUE5QixVQUEyQyxZQUEzQyxFQUE0RCxPQUE1RCxDQUFxRSxjQUFNO0FBQ3ZFLGdCQUFJLEdBQUcsWUFBSCxDQUFpQixRQUFLLEtBQUwsQ0FBVyxJQUE1QixDQUFKLEVBQXlDO0FBQUUsd0JBQUssT0FBTCxDQUFjLEVBQWQ7QUFBb0IsYUFBL0QsTUFDSyxJQUFJLEdBQUcsWUFBSCxDQUFpQixRQUFLLEtBQUwsQ0FBVyxJQUE1QixDQUFKLEVBQXlDO0FBQzFDLHdCQUFLLGVBQUwsQ0FBcUIsSUFBckIsQ0FBMkIsRUFBRSxNQUFGLEVBQU0sTUFBTSxHQUFHLFlBQUgsQ0FBZ0IsUUFBSyxLQUFMLENBQVcsSUFBM0IsQ0FBWixFQUE4QyxNQUFNLEdBQUcsWUFBSCxDQUFnQixRQUFLLEtBQUwsQ0FBVyxJQUEzQixDQUFwRCxFQUEzQjtBQUNIO0FBQ0osU0FMRDs7QUFPQSxnQkFBUSxTQUFSLENBQWtCLE1BQWxCLEtBQTZCLGNBQTdCLEdBQ00sUUFBUSxTQUFSLENBQWtCLEVBQWxCLENBQXFCLFVBQXJCLENBQWdDLFlBQWhDLENBQThDLFFBQTlDLEVBQXdELFFBQVEsU0FBUixDQUFrQixFQUExRSxDQUROLEdBRU0sUUFBUSxTQUFSLENBQWtCLEVBQWxCLENBQXNCLFFBQVEsU0FBUixDQUFrQixNQUFsQixJQUE0QixhQUFsRCxFQUFtRSxRQUFuRSxDQUZOOztBQUlBLGVBQU8sSUFBUDtBQUNIO0FBcE80RyxDQUFoRyxDQUFqQjs7Ozs7QUNBQSxPQUFPLE9BQVAsR0FBaUIsT0FBTyxNQUFQLENBQWU7QUFFNUIsT0FGNEIsZUFFeEIsUUFGd0IsRUFFZDtBQUNWLFlBQUksQ0FBQyxLQUFLLFNBQUwsQ0FBZSxNQUFwQixFQUE2QixPQUFPLGdCQUFQLENBQXdCLFFBQXhCLEVBQWtDLEtBQUssUUFBTCxDQUFjLElBQWQsQ0FBbUIsSUFBbkIsQ0FBbEM7QUFDN0IsYUFBSyxTQUFMLENBQWUsSUFBZixDQUFvQixRQUFwQjtBQUNILEtBTDJCO0FBTzVCLFlBUDRCLHNCQU9qQjtBQUNSLFlBQUksS0FBSyxPQUFULEVBQW1COztBQUVsQixhQUFLLE9BQUwsR0FBZSxJQUFmOztBQUVBLGVBQU8scUJBQVAsR0FDTSxPQUFPLHFCQUFQLENBQThCLEtBQUssWUFBTCxDQUFrQixJQUFsQixDQUF1QixJQUF2QixDQUE5QixDQUROLEdBRU0sV0FBWSxLQUFLLFlBQWpCLEVBQStCLEVBQS9CLENBRk47QUFHSCxLQWYyQjtBQWlCNUIsZ0JBakI0QiwwQkFpQmI7QUFDWCxhQUFLLFNBQUwsR0FBaUIsS0FBSyxTQUFMLENBQWUsTUFBZixDQUF1QjtBQUFBLG1CQUFZLFVBQVo7QUFBQSxTQUF2QixDQUFqQjtBQUNBLGFBQUssT0FBTCxHQUFlLEtBQWY7QUFDSDtBQXBCMkIsQ0FBZixFQXNCZCxFQUFFLFdBQVcsRUFBRSxVQUFVLElBQVosRUFBa0IsT0FBTyxFQUF6QixFQUFiLEVBQTRDLFNBQVMsRUFBRSxVQUFVLElBQVosRUFBa0IsT0FBTyxLQUF6QixFQUFyRCxFQXRCYyxDQUFqQjs7Ozs7QUNBQSxPQUFPLE9BQVAsR0FBaUI7QUFBQTtBQUFBLENBQWpCOzs7OztBQ0FBLE9BQU8sT0FBUCxHQUFpQjtBQUFBO0FBQUEsQ0FBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCO0FBQUE7QUFBQSxDQUFqQjs7Ozs7QUNBQSxPQUFPLE9BQVAsR0FBaUI7QUFBQTtBQUFBLENBQWpCOzs7OztBQ0FBLE9BQU8sT0FBUCxHQUFpQjtBQUFBO0FBQUEsQ0FBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCO0FBRWIsZUFGYSx1QkFFQSxJQUZBLEVBRWdCO0FBQUE7O0FBQUEsWUFBVixJQUFVLHVFQUFMLEVBQUs7O0FBQ3pCLGVBQU8sTUFBUCxDQUFlLElBQWYsRUFBcUIsRUFBRSxPQUFPLEVBQVQsRUFBYyxVQUFkLEVBQXJCLEVBQTJDLElBQTNDOztBQUVBLFlBQUksS0FBSyxPQUFULEVBQW1CO0FBQ2YsaUJBQUssT0FBTCxDQUFhLE9BQWIsQ0FBc0I7QUFBQSx1QkFBTyxNQUFLLEtBQUwsQ0FBWSxHQUFaLElBQW9CLEVBQTNCO0FBQUEsYUFBdEI7QUFDQSxpQkFBSyxNQUFMO0FBQ0g7O0FBRUQsZUFBTyxJQUFQO0FBQ0gsS0FYWTtBQWFiLFVBYmEsb0JBYUo7QUFBQTs7QUFDTCxhQUFLLElBQUwsQ0FBVSxPQUFWLENBQW1CO0FBQUEsbUJBQVMsT0FBSyxPQUFMLENBQWEsT0FBYixDQUFzQjtBQUFBLHVCQUFRLE9BQUssVUFBTCxDQUFpQixLQUFqQixFQUF3QixJQUF4QixDQUFSO0FBQUEsYUFBdEIsQ0FBVDtBQUFBLFNBQW5CO0FBQ0gsS0FmWTtBQWlCYixjQWpCYSxzQkFpQkQsS0FqQkMsRUFpQk0sSUFqQk4sRUFpQmE7QUFDdEIsYUFBSyxLQUFMLENBQVksSUFBWixFQUFvQixNQUFPLElBQVAsQ0FBcEIsSUFDSSxLQUFLLEtBQUwsQ0FBWSxJQUFaLEVBQW9CLE1BQU8sSUFBUCxDQUFwQixJQUNNLE1BQU0sT0FBTixDQUFlLEtBQUssS0FBTCxDQUFZLElBQVosRUFBb0IsTUFBTyxJQUFQLENBQXBCLENBQWYsSUFDSSxLQUFLLEtBQUwsQ0FBWSxJQUFaLEVBQW9CLE1BQU8sSUFBUCxDQUFwQixFQUFvQyxNQUFwQyxDQUE0QyxLQUE1QyxDQURKLEdBRUcsQ0FBRSxLQUFLLEtBQUwsQ0FBWSxJQUFaLEVBQW9CLE1BQU8sSUFBUCxDQUFwQixDQUFGLEVBQXVDLEtBQXZDLENBSFQsR0FJTSxLQUxWO0FBTUg7QUF4QlksQ0FBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCLGVBQU87QUFBRSxVQUFRLEdBQVIsQ0FBYSxJQUFJLEtBQUosSUFBYSxHQUExQjtBQUFpQyxDQUEzRDs7Ozs7OztBQ0FBLE9BQU8sT0FBUCxHQUFpQjtBQUViLGVBRmEsdUJBRUEsR0FGQSxFQUVNO0FBQ2YsZUFBTyxNQUFNLElBQU4sQ0FBWSxNQUFPLEdBQVAsRUFBYSxJQUFiLEVBQVosQ0FBUDtBQUNILEtBSlk7QUFNYiw2QkFOYSxxQ0FNYyxHQU5kLEVBTW1CLEdBTm5CLEVBTXlCO0FBQ2xDLGNBQU0sS0FBSyxJQUFMLENBQVUsR0FBVixDQUFOO0FBQ0EsY0FBTSxLQUFLLEtBQUwsQ0FBVyxHQUFYLENBQU47QUFDQSxlQUFPLEtBQUssS0FBTCxDQUFXLEtBQUssTUFBTCxNQUFpQixNQUFNLEdBQU4sR0FBWSxDQUE3QixDQUFYLElBQThDLEdBQXJEO0FBQ0gsS0FWWTtBQVliLFFBWmEsZ0JBWVAsR0FaTyxFQVlGLElBWkUsRUFZSztBQUNkLGVBQU8sT0FBTyxJQUFQLENBQWEsR0FBYixFQUFtQixNQUFuQixDQUEyQjtBQUFBLG1CQUFPLENBQUMsS0FBSyxRQUFMLENBQWUsR0FBZixDQUFSO0FBQUEsU0FBM0IsRUFBMEQsTUFBMUQsQ0FBa0UsVUFBRSxJQUFGLEVBQVEsR0FBUjtBQUFBLG1CQUFpQixPQUFPLE1BQVAsQ0FBZSxJQUFmLHNCQUF3QixHQUF4QixFQUE4QixJQUFJLEdBQUosQ0FBOUIsRUFBakI7QUFBQSxTQUFsRSxFQUErSCxFQUEvSCxDQUFQO0FBQ0gsS0FkWTtBQWdCYixRQWhCYSxnQkFnQlAsR0FoQk8sRUFnQkYsSUFoQkUsRUFnQks7QUFDZCxlQUFPLEtBQUssTUFBTCxDQUFhLFVBQUUsSUFBRixFQUFRLEdBQVI7QUFBQSxtQkFBaUIsT0FBTyxNQUFQLENBQWUsSUFBZixzQkFBd0IsR0FBeEIsRUFBOEIsSUFBSSxHQUFKLENBQTlCLEVBQWpCO0FBQUEsU0FBYixFQUEwRSxFQUExRSxDQUFQO0FBQ0gsS0FsQlk7OztBQW9CYixXQUFPLFFBQVEsV0FBUixDQXBCTTs7QUFzQmIsT0FBRyxXQUFFLEdBQUY7QUFBQSxZQUFPLElBQVAsdUVBQVksRUFBWjtBQUFBLFlBQWlCLE9BQWpCO0FBQUEsZUFDQyxJQUFJLE9BQUosQ0FBYSxVQUFFLE9BQUYsRUFBVyxNQUFYO0FBQUEsbUJBQXVCLFFBQVEsS0FBUixDQUFlLEdBQWYsRUFBb0Isb0JBQXBCLEVBQXFDLEtBQUssTUFBTCxDQUFhLFVBQUUsQ0FBRjtBQUFBLGtEQUFRLFFBQVI7QUFBUSw0QkFBUjtBQUFBOztBQUFBLHVCQUFzQixJQUFJLE9BQU8sQ0FBUCxDQUFKLEdBQWdCLFFBQVEsUUFBUixDQUF0QztBQUFBLGFBQWIsQ0FBckMsQ0FBdkI7QUFBQSxTQUFiLENBREQ7QUFBQSxLQXRCVTs7QUF5QmIsZUF6QmEseUJBeUJDO0FBQUUsZUFBTyxJQUFQO0FBQWE7QUF6QmhCLENBQWpCOzs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDOVNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNoVUE7QUFDQTs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1BBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FDZkEsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlLE9BQU8sTUFBUCxDQUFlLEVBQWYsRUFBbUIsUUFBUSxvQ0FBUixDQUFuQixFQUFrRTs7QUFFOUYsa0JBQWMsUUFBUSxnQkFBUixDQUZnRjs7QUFJOUYsVUFBTSxPQUp3Rjs7QUFNOUYsY0FOOEYsd0JBTWpGO0FBQ1QsYUFBSyxRQUFMLEdBQWdCLEVBQWhCOztBQUVBLGVBQU8sSUFBUDtBQUNILEtBVjZGOzs7QUFZOUYsbUJBQWUsS0FaK0U7O0FBYzlGLGlCQWQ4Rix5QkFjL0UsSUFkK0UsRUFjekUsT0FkeUUsRUFjL0Q7QUFDM0IsWUFBSSxDQUFDLEtBQUssUUFBTCxDQUFlLE9BQWYsQ0FBTCxFQUFnQyxLQUFLLFFBQUwsQ0FBZSxPQUFmLElBQTJCLE9BQU8sTUFBUCxDQUFlLEtBQUssWUFBcEIsRUFBa0M7QUFDekYsdUJBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxLQUFLLEdBQUwsQ0FBUyxTQUFmLEVBQVQ7QUFEOEUsU0FBbEMsRUFFdkQsV0FGdUQsRUFBM0I7O0FBSWhDLGVBQU8sS0FBSyxRQUFMLENBQWUsT0FBZixFQUF5QixXQUF6QixDQUFzQyxJQUF0QyxFQUE0QyxPQUE1QyxDQUFQO0FBRUgsS0FyQjZGOzs7QUF1QjlGLGNBQVUsUUFBUSxvQkFBUjs7QUF2Qm9GLENBQWxFLENBQWYsRUF5QlosRUF6QlksQ0FBakI7Ozs7O0FDQUEsT0FBTyxPQUFQLEdBQWlCLE9BQU8sTUFBUCxDQUFlLEVBQWYsRUFBbUIsUUFBUSxvQ0FBUixDQUFuQixFQUFrRTs7QUFFL0UsVUFBTSxjQUZ5RTs7QUFJL0UsV0FBTztBQUNILGVBQU8sUUFBUSx3QkFBUixHQURKO0FBRUgsaUJBQVMsUUFBUSw0QkFBUjtBQUZOLEtBSndFOztBQVMvRSxjQVQrRSx3QkFTbEU7QUFBQTs7QUFFVCxhQUFLLEVBQUwsQ0FBUyxPQUFULEVBQWtCO0FBQUEsbUJBQU0sTUFBSyxNQUFMLEdBQWMsT0FBcEI7QUFBQSxTQUFsQjtBQUNBLGFBQUssRUFBTCxDQUFTLFFBQVQsRUFBbUI7QUFBQSxtQkFBTSxNQUFLLE1BQUwsR0FBYyxRQUFwQjtBQUFBLFNBQW5COztBQUVBLGVBQU8sSUFBUDtBQUNILEtBZjhFOzs7QUFpQi9FLG1CQUFlLEtBakJnRTs7QUFtQi9FLGVBbkIrRSx1QkFtQmxFLElBbkJrRSxFQW1CNUQsT0FuQjRELEVBbUJsRDtBQUFBOztBQUN6QixlQUFPLElBQUksT0FBSixDQUFhLFVBQUUsT0FBRixFQUFXLE1BQVgsRUFBd0I7QUFDeEMsZ0JBQUksT0FBTyxJQUFQLENBQWEsT0FBSyxNQUFsQixDQUFKLEVBQWlDLE9BQUssUUFBTDs7QUFFakMsbUJBQUssVUFBTCxHQUFrQixPQUFsQjs7QUFFQSxnQkFBSSxTQUFTLE9BQWIsRUFBdUIsT0FBSyxHQUFMLENBQVMsU0FBVCxDQUFtQixTQUFuQixDQUE2QixHQUE3QixDQUFpQyxTQUFqQzs7QUFFdkIsbUJBQUssR0FBTCxDQUFTLE9BQVQsQ0FBaUIsV0FBakIsR0FBK0IsT0FBL0I7QUFDQSxtQkFBSyxHQUFMLENBQVMsS0FBVCxDQUFlLFdBQWYsR0FBNkIsU0FBUyxPQUFULEdBQW1CLE9BQW5CLEdBQTZCLFNBQTFEO0FBQ0EsbUJBQUssYUFBTCxDQUFvQixFQUFFLFdBQVcsRUFBRSxJQUFJLE9BQUssR0FBTCxDQUFTLElBQWYsRUFBYixFQUFvQyxVQUFVLFNBQVMsT0FBVCxHQUFtQixPQUFLLEtBQUwsQ0FBVyxLQUE5QixHQUFzQyxPQUFLLEtBQUwsQ0FBVyxPQUEvRixFQUFwQjs7QUFFQSxtQkFBSyxNQUFMLEdBQWMsU0FBZDs7QUFFQSxtQkFBSyxJQUFMLENBQVcsSUFBWCxFQUNDLElBREQsQ0FDTztBQUFBLHVCQUFNLE9BQUssSUFBTCxDQUFXLElBQVgsQ0FBTjtBQUFBLGFBRFAsRUFFQyxJQUZELENBRU87QUFBQSx1QkFBTSxPQUFLLFFBQUwsRUFBTjtBQUFBLGFBRlAsRUFHQyxLQUhELENBR1EsTUFIUjtBQUlILFNBakJNLENBQVA7QUFrQkgsS0F0QzhFO0FBd0MvRSxZQXhDK0Usc0JBd0NwRTtBQUNQLFlBQUksS0FBSyxHQUFMLENBQVMsU0FBVCxDQUFtQixTQUFuQixDQUE2QixRQUE3QixDQUFzQyxTQUF0QyxDQUFKLEVBQXVELEtBQUssR0FBTCxDQUFTLFNBQVQsQ0FBbUIsU0FBbkIsQ0FBNkIsTUFBN0IsQ0FBb0MsU0FBcEM7QUFDdkQsYUFBSyxHQUFMLENBQVMsT0FBVCxDQUFpQixXQUFqQixHQUErQixFQUEvQjtBQUNBLGFBQUssR0FBTCxDQUFTLE9BQVQsQ0FBaUIsS0FBakIsR0FBeUIsRUFBekI7QUFDQSxZQUFJLEtBQUssR0FBTCxDQUFTLElBQVQsQ0FBYyxVQUFsQixFQUErQixLQUFLLEdBQUwsQ0FBUyxJQUFULENBQWMsV0FBZCxDQUEyQixLQUFLLEdBQUwsQ0FBUyxJQUFULENBQWMsVUFBekM7QUFDL0IsYUFBSyxVQUFMO0FBQ0gsS0E5QzhFOzs7QUFnRC9FLGNBQVUsUUFBUSwyQkFBUjs7QUFoRHFFLENBQWxFLENBQWpCIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIm1vZHVsZS5leHBvcnRzPXtcblx0Rm9vdGVyOiByZXF1aXJlKCcuL3ZpZXdzL3RlbXBsYXRlcy9Gb290ZXInKSxcblx0SGVhZGVyOiByZXF1aXJlKCcuL3ZpZXdzL3RlbXBsYXRlcy9IZWFkZXInKSxcblx0SG9tZTogcmVxdWlyZSgnLi92aWV3cy90ZW1wbGF0ZXMvSG9tZScpLFxuXHRJbnRlcm5ldDogcmVxdWlyZSgnLi92aWV3cy90ZW1wbGF0ZXMvSW50ZXJuZXQnKSxcblx0U2VydmljZXM6IHJlcXVpcmUoJy4vdmlld3MvdGVtcGxhdGVzL1NlcnZpY2VzJyksXG5cdFRvYXN0OiByZXF1aXJlKCcuL3ZpZXdzL3RlbXBsYXRlcy9Ub2FzdCcpLFxuXHRUb2FzdE1lc3NhZ2U6IHJlcXVpcmUoJy4vdmlld3MvdGVtcGxhdGVzL1RvYXN0TWVzc2FnZScpXG59IiwibW9kdWxlLmV4cG9ydHM9e1xuXHRGb290ZXI6IHJlcXVpcmUoJy4vdmlld3MvRm9vdGVyJyksXG5cdEhlYWRlcjogcmVxdWlyZSgnLi92aWV3cy9IZWFkZXInKSxcblx0SG9tZTogcmVxdWlyZSgnLi92aWV3cy9Ib21lJyksXG5cdEludGVybmV0OiByZXF1aXJlKCcuL3ZpZXdzL0ludGVybmV0JyksXG5cdFNlcnZpY2VzOiByZXF1aXJlKCcuL3ZpZXdzL1NlcnZpY2VzJyksXG5cdFRvYXN0OiByZXF1aXJlKCcuL3ZpZXdzL1RvYXN0JyksXG5cdFRvYXN0TWVzc2FnZTogcmVxdWlyZSgnLi92aWV3cy9Ub2FzdE1lc3NhZ2UnKVxufSIsIm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmNyZWF0ZSggT2JqZWN0LmFzc2lnbigge30sIHJlcXVpcmUoJy4uLy4uL2xpYi9NeU9iamVjdCcpLCB7XG5cbiAgICBSZXF1ZXN0OiB7XG5cbiAgICAgICAgY29uc3RydWN0b3IoIGRhdGEgKSB7XG4gICAgICAgICAgICBsZXQgcmVxID0gbmV3IFhNTEh0dHBSZXF1ZXN0KClcblxuICAgICAgICAgICAgaWYoIGRhdGEub25Qcm9ncmVzcyApIHJlcS5hZGRFdmVudExpc3RlbmVyKCBcInByb2dyZXNzXCIsIGUgPT5cbiAgICAgICAgICAgICAgICBkYXRhLm9uUHJvZ3Jlc3MoIGUubGVuZ3RoQ29tcHV0YWJsZSA/IE1hdGguZmxvb3IoICggZS5sb2FkZWQgLyBlLnRvdGFsICkgKiAxMDAgKSA6IDAgKSBcbiAgICAgICAgICAgIClcblxuICAgICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKCAoIHJlc29sdmUsIHJlamVjdCApID0+IHtcblxuICAgICAgICAgICAgICAgIHJlcS5vbmxvYWQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgWyA1MDAsIDQwNCwgNDAxIF0uaW5jbHVkZXMoIHRoaXMuc3RhdHVzIClcbiAgICAgICAgICAgICAgICAgICAgICAgID8gcmVqZWN0KCBKU09OLnBhcnNlKCB0aGlzLnJlc3BvbnNlICkgKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiByZXNvbHZlKCBKU09OLnBhcnNlKCB0aGlzLnJlc3BvbnNlICkgKVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmKCBkYXRhLm1ldGhvZCA9PT0gXCJnZXRcIiB8fCBkYXRhLm1ldGhvZCA9PT0gXCJvcHRpb25zXCIgKSB7XG4gICAgICAgICAgICAgICAgICAgIGxldCBxcyA9IGRhdGEucXMgPyBgPyR7ZGF0YS5xc31gIDogJycgXG4gICAgICAgICAgICAgICAgICAgIHJlcS5vcGVuKCBkYXRhLm1ldGhvZCwgYC8ke2RhdGEucmVzb3VyY2V9JHtxc31gIClcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5zZXRIZWFkZXJzKCByZXEsIGRhdGEuaGVhZGVycyApXG4gICAgICAgICAgICAgICAgICAgIHJlcS5zZW5kKG51bGwpXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGF0aCA9IGAvJHtkYXRhLnJlc291cmNlfWAgKyAoIGRhdGEuaWQgPyBgLyR7ZGF0YS5pZH1gIDogJycgKTtcbiAgICAgICAgICAgICAgICAgICAgcmVxLm9wZW4oIGRhdGEubWV0aG9kLnRvVXBwZXJDYXNlKCksIHBhdGgsIHRydWUpXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0SGVhZGVycyggcmVxLCBkYXRhLmhlYWRlcnMgKVxuICAgICAgICAgICAgICAgICAgICByZXEuc2VuZCggZGF0YS5kYXRhIHx8IG51bGwgKVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmKCBkYXRhLm9uUHJvZ3Jlc3MgKSBkYXRhLm9uUHJvZ3Jlc3MoICdzZW50JyApXG4gICAgICAgICAgICB9IClcbiAgICAgICAgfSxcblxuICAgICAgICBwbGFpbkVzY2FwZSggc1RleHQgKSB7XG4gICAgICAgICAgICAvKiBob3cgc2hvdWxkIEkgdHJlYXQgYSB0ZXh0L3BsYWluIGZvcm0gZW5jb2Rpbmc/IHdoYXQgY2hhcmFjdGVycyBhcmUgbm90IGFsbG93ZWQ/IHRoaXMgaXMgd2hhdCBJIHN1cHBvc2UuLi46ICovXG4gICAgICAgICAgICAvKiBcIjRcXDNcXDcgLSBFaW5zdGVpbiBzYWlkIEU9bWMyXCIgLS0tLT4gXCI0XFxcXDNcXFxcN1xcIC1cXCBFaW5zdGVpblxcIHNhaWRcXCBFXFw9bWMyXCIgKi9cbiAgICAgICAgICAgIHJldHVybiBzVGV4dC5yZXBsYWNlKC9bXFxzXFw9XFxcXF0vZywgXCJcXFxcJCZcIik7XG4gICAgICAgIH0sXG5cbiAgICAgICAgc2V0SGVhZGVycyggcmVxLCBoZWFkZXJzPXt9ICkge1xuICAgICAgICAgICAgcmVxLnNldFJlcXVlc3RIZWFkZXIoIFwiQWNjZXB0XCIsIGhlYWRlcnMuYWNjZXB0IHx8ICdhcHBsaWNhdGlvbi9qc29uJyApXG4gICAgICAgICAgICByZXEuc2V0UmVxdWVzdEhlYWRlciggXCJDb250ZW50LVR5cGVcIiwgaGVhZGVycy5jb250ZW50VHlwZSB8fCAndGV4dC9wbGFpbicgKVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIF9mYWN0b3J5KCBkYXRhICkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmNyZWF0ZSggdGhpcy5SZXF1ZXN0LCB7IH0gKS5jb25zdHJ1Y3RvciggZGF0YSApXG4gICAgfSxcblxuICAgIGNvbnN0cnVjdG9yKCkge1xuXG4gICAgICAgIGlmKCAhWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLnNlbmRBc0JpbmFyeSApIHtcbiAgICAgICAgICBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2VuZEFzQmluYXJ5ID0gZnVuY3Rpb24oc0RhdGEpIHtcbiAgICAgICAgICAgIHZhciBuQnl0ZXMgPSBzRGF0YS5sZW5ndGgsIHVpOERhdGEgPSBuZXcgVWludDhBcnJheShuQnl0ZXMpO1xuICAgICAgICAgICAgZm9yICh2YXIgbklkeCA9IDA7IG5JZHggPCBuQnl0ZXM7IG5JZHgrKykge1xuICAgICAgICAgICAgICB1aThEYXRhW25JZHhdID0gc0RhdGEuY2hhckNvZGVBdChuSWR4KSAmIDB4ZmY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLnNlbmQodWk4RGF0YSk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLl9mYWN0b3J5LmJpbmQodGhpcylcbiAgICB9XG5cbn0gKSwgeyB9ICkuY29uc3RydWN0b3IoKVxuIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuY3JlYXRlKCB7XG5cbiAgICBjcmVhdGUoIG5hbWUsIG9wdHMgKSB7XG4gICAgICAgIGNvbnN0IGxvd2VyID0gbmFtZVxuICAgICAgICBuYW1lID0gbmFtZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIG5hbWUuc2xpY2UoMSlcbiAgICAgICAgcmV0dXJuIE9iamVjdC5jcmVhdGUoXG4gICAgICAgICAgICB0aGlzLlZpZXdzWyBuYW1lIF0sXG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKCB7XG4gICAgICAgICAgICAgICAgVG9hc3Q6IHsgdmFsdWU6IHRoaXMuVG9hc3QgfSxcbiAgICAgICAgICAgICAgICBuYW1lOiB7IHZhbHVlOiBuYW1lIH0sXG4gICAgICAgICAgICAgICAgZmFjdG9yeTogeyB2YWx1ZTogdGhpcyB9LFxuICAgICAgICAgICAgICAgIHRlbXBsYXRlOiB7IHZhbHVlOiB0aGlzLlRlbXBsYXRlc1sgbmFtZSBdIH0sXG4gICAgICAgICAgICB9LCBvcHRzIClcbiAgICAgICAgKS5jb25zdHJ1Y3RvcigpXG4gICAgfSxcblxufSwge1xuICAgIFRlbXBsYXRlczogeyB2YWx1ZTogcmVxdWlyZSgnLi4vLlRlbXBsYXRlTWFwJykgfSxcbiAgICBUb2FzdDogeyB2YWx1ZTogcmVxdWlyZSgnLi4vdmlld3MvVG9hc3QnKSB9LFxuICAgIFZpZXdzOiB7IHZhbHVlOiByZXF1aXJlKCcuLi8uVmlld01hcCcpIH1cbn0gKVxuIiwiXG5jb25zdCByb3V0ZXIgPSByZXF1aXJlKCcuL3JvdXRlcicpLFxuICAgIG9uTG9hZCA9IG5ldyBQcm9taXNlKCByZXNvbHZlID0+IHdpbmRvdy5vbmxvYWQgPSAoKSA9PiByZXNvbHZlKCkgKVxuXG5yZXF1aXJlKCcuL3BvbHlmaWxsJylcblxub25Mb2FkLnRoZW4oICgpID0+IHJvdXRlci5pbml0aWFsaXplKCkgKVxuLmNhdGNoKCBlID0+IGNvbnNvbGUubG9nKCBgRXJyb3IgaW5pdGlhbGl6aW5nIGNsaWVudCAtPiAke2Uuc3RhY2sgfHwgZX1gICkgKVxuIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuYXNzaWduKCB7fSwgcmVxdWlyZSgnLi9fX3Byb3RvX18nKSwge1xuXG4gICAgZGF0YTogeyB9LFxuICAgIFxuICAgIGZpZWxkczoge1xuICAgICAgICBuYW1lOiB7XG4gICAgICAgICAgICBlcnJvcjogJ1BsZWFzZSBlbnRlciB5b3VyIG5hbWUnXG4gICAgICAgIH0sXG4gICAgICAgIGNvbnRhY3Q6IHtcbiAgICAgICAgICAgIGVycm9yOiAnUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgYWRkcmVzcyBvciBwaG9uZSBudW1iZXInXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgcmVzb3VyY2U6ICdwZXJzb24nLFxuXG4gICAgdmFsaWRhdGUoIGZpZWxkLCB2YWx1ZSApIHtcbiAgICAgICAgY29uc3QgdmFsID0gdmFsdWUudHJpbSgpXG5cbiAgICAgICAgaWYoIGZpZWxkID09PSAnbmFtZScgJiYgdmFsID09PSBcIlwiICkgcmV0dXJuIGZhbHNlXG5cbiAgICAgICAgaWYoIGZpZWxkID09PSAnY29udGFjdCcgJiYgKCAhdGhpcy5fZW1haWxSZWdleC50ZXN0KCB2YWwgKSAmJiAhdGhpcy5fcGhvbmVSZWdleC50ZXN0KCB2YWwgKSApICkgcmV0dXJuIGZhbHNlXG5cbiAgICAgICAgcmV0dXJuIHRydWVcbiAgICB9LFxuXG4gICAgX2VtYWlsUmVnZXg6IC9eXFx3KyhbXFwuLV0/XFx3KykqQFxcdysoW1xcLi1dP1xcdyspKihcXC5cXHd7MiwzfSkrJC8sXG5cbiAgICBfcGhvbmVSZWdleDogL15cXCg/KFxcZHszfSlcXCk/Wy0uIF0/KFxcZHszfSlbLS4gXT8oXFxkezR9KSQvXG5cbn0gKSIsIm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmFzc2lnbiggeyB9LCByZXF1aXJlKCcuLi8uLi8uLi9saWIvTXlPYmplY3QnKSwgcmVxdWlyZSgnLi4vLi4vLi4vbGliL01vZGVsJyksIHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlci5wcm90b3R5cGUsIHtcblxuICAgIFhocjogcmVxdWlyZSgnLi4vWGhyJyksXG5cbiAgICBkZWxldGUoIGlkICkge1xuICAgICAgICByZXR1cm4gdGhpcy5YaHIoIHsgbWV0aG9kOiAnREVMRVRFJywgcmVzb3VyY2U6IHRoaXMucmVzb3VyY2UsIGlkIH0gKVxuICAgICAgICAudGhlbiggaWQgPT4ge1xuICAgICAgICAgICAgY29uc3QgZGF0dW0gPSB0aGlzLmRhdGEuZmluZCggZGF0dW0gPT4gZGF0dW0uaWQgPT0gaWQgKVxuXG4gICAgICAgICAgICBpZiggdGhpcy5zdG9yZSApIHtcbiAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyggdGhpcy5zdG9yZSApLmZvckVhY2goIGF0dHIgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnN0b3JlWyBhdHRyIF1bIGRhdHVtWyBhdHRyIF0gXSA9IHRoaXMuc3RvcmVbIGF0dHIgXVsgZGF0dW1bIGF0dHIgXSBdLmZpbHRlciggZGF0dW0gPT4gZGF0dW0uaWQgIT0gaWQgKVxuICAgICAgICAgICAgICAgICAgICBpZiggdGhpcy5zdG9yZVsgYXR0ciBdWyBkYXR1bVsgYXR0ciBdIF0ubGVuZ3RoID09PSAwICkgeyB0aGlzLnN0b3JlWyBhdHRyIF1bIGRhdHVtWyBhdHRyIF0gXSA9IHVuZGVmaW5lZCB9XG4gICAgICAgICAgICAgICAgfSApXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRoaXMuZGF0YSA9IHRoaXMuZGF0YS5maWx0ZXIoIGRhdHVtID0+IGRhdHVtLmlkICE9IGlkIClcbiAgICAgICAgICAgIGlmKCB0aGlzLmlkcyApIGRlbGV0ZSB0aGlzLmlkc1tpZF1cblxuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShpZClcbiAgICAgICAgfSApXG4gICAgfSxcblxuICAgIGdldCggb3B0cz17IHF1ZXJ5Ont9IH0gKSB7XG4gICAgICAgIGlmKCBvcHRzLnF1ZXJ5IHx8IHRoaXMucGFnaW5hdGlvbiApIE9iamVjdC5hc3NpZ24oIG9wdHMucXVlcnksIHRoaXMucGFnaW5hdGlvbiApXG5cbiAgICAgICAgcmV0dXJuIHRoaXMuWGhyKCB7IG1ldGhvZDogb3B0cy5tZXRob2QgfHwgJ2dldCcsIHJlc291cmNlOiB0aGlzLnJlc291cmNlLCBoZWFkZXJzOiB0aGlzLmhlYWRlcnMgfHwge30sIHFzOiBvcHRzLnF1ZXJ5ID8gSlNPTi5zdHJpbmdpZnkoIG9wdHMucXVlcnkgKSA6IHVuZGVmaW5lZCB9IClcbiAgICAgICAgLnRoZW4oIHJlc3BvbnNlID0+IHtcblxuICAgICAgICAgICAgaWYoIG9wdHMuc3RvcmVCeSApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnN0b3JlID0geyB9XG4gICAgICAgICAgICAgICAgb3B0cy5zdG9yZUJ5LmZvckVhY2goIGF0dHIgPT4gdGhpcy5zdG9yZVsgYXR0ciBdID0geyB9IClcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhpcy5kYXRhID0gdGhpcy5wYXJzZVxuICAgICAgICAgICAgICAgID8gdGhpcy5wYXJzZSggcmVzcG9uc2UsIG9wdHMuc3RvcmVCeSApXG4gICAgICAgICAgICAgICAgOiBvcHRzLnN0b3JlQnlcbiAgICAgICAgICAgICAgICAgICAgPyB0aGlzLnN0b3JlQnkoIHJlc3BvbnNlIClcbiAgICAgICAgICAgICAgICAgICAgOiByZXNwb25zZVxuXG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2dvdCcpXG5cbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpcy5kYXRhKVxuICAgICAgICB9IClcbiAgICB9LFxuXG4gICAgcGF0Y2goIGlkLCBkYXRhLCBvcHRzPXt9ICkge1xuICAgICAgICByZXR1cm4gdGhpcy5YaHIoIHsgbWV0aG9kOiAncGF0Y2gnLCBpZCwgcmVzb3VyY2U6IHRoaXMucmVzb3VyY2UsIGhlYWRlcnM6IHRoaXMuaGVhZGVycyB8fCB7fSwgZGF0YTogSlNPTi5zdHJpbmdpZnkoIGRhdGEgfHwgdGhpcy5kYXRhICkgfSApXG4gICAgICAgIC50aGVuKCByZXNwb25zZSA9PiB7XG4gICAgICAgICAgICBpZiggQXJyYXkuaXNBcnJheSggdGhpcy5kYXRhICkgKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5kYXRhID0gdGhpcy5kYXRhID8gdGhpcy5kYXRhLmNvbmNhdCggcmVzcG9uc2UgKSA6IFsgcmVzcG9uc2UgXVxuICAgICAgICAgICAgICAgIGlmKCB0aGlzLnN0b3JlICkgT2JqZWN0LmtleXMoIHRoaXMuc3RvcmUgKS5mb3JFYWNoKCBhdHRyID0+IHRoaXMuX3N0b3JlKCByZXNwb25zZSwgYXR0ciApIClcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSggcmVzcG9uc2UgKVxuICAgICAgICB9IClcbiAgICB9LFxuXG4gICAgcG9zdCggbW9kZWwsIG9wdHM9e30gKSB7XG4gICAgICAgIHJldHVybiB0aGlzLlhociggeyBtZXRob2Q6ICdwb3N0JywgcmVzb3VyY2U6IHRoaXMucmVzb3VyY2UsIGhlYWRlcnM6IHRoaXMuaGVhZGVycyB8fCB7fSwgZGF0YTogSlNPTi5zdHJpbmdpZnkoIG1vZGVsIHx8IHRoaXMuZGF0YSApIH0gKVxuICAgICAgICAudGhlbiggcmVzcG9uc2UgPT4ge1xuICAgICAgICAgICAgaWYoIEFycmF5LmlzQXJyYXkoIHRoaXMuZGF0YSApICkge1xuICAgICAgICAgICAgICAgIHRoaXMuZGF0YSA9IHRoaXMuZGF0YSA/IHRoaXMuZGF0YS5jb25jYXQoIHJlc3BvbnNlICkgOiBbIHJlc3BvbnNlIF1cbiAgICAgICAgICAgICAgICBpZiggdGhpcy5zdG9yZSApIE9iamVjdC5rZXlzKCB0aGlzLnN0b3JlICkuZm9yRWFjaCggYXR0ciA9PiB0aGlzLl9zdG9yZSggcmVzcG9uc2UsIGF0dHIgKSApXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoIHJlc3BvbnNlIClcbiAgICAgICAgfSApXG4gICAgfSxcblxuICAgIHN0b3JlQnkoIGRhdGEgKSB7XG5cbiAgICAgICAgZGF0YS5mb3JFYWNoKCBkYXR1bSA9PiBPYmplY3Qua2V5cyggdGhpcy5zdG9yZSApLmZvckVhY2goIGF0dHIgPT4gdGhpcy5fc3RvcmUoIGRhdHVtLCBhdHRyICkgKSApXG5cbiAgICAgICAgcmV0dXJuIGRhdGFcbiAgICB9LFxuXG4gICAgX3N0b3JlKCBkYXR1bSwgYXR0ciApIHtcbiAgICAgICAgaWYoICF0aGlzLnN0b3JlWyBhdHRyIF1bIGRhdHVtWyBhdHRyIF0gXSApIHRoaXMuc3RvcmVbIGF0dHIgXVsgZGF0dW1bIGF0dHIgXSBdID0gWyBdXG4gICAgICAgIHRoaXMuc3RvcmVbIGF0dHIgXVsgZGF0dW1bIGF0dHIgXSBdLnB1c2goIGRhdHVtIClcbiAgICB9XG5cbn0gKVxuIiwiLy9odHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvRWxlbWVudC9jbG9zZXN0XG5pZiAod2luZG93LkVsZW1lbnQgJiYgIUVsZW1lbnQucHJvdG90eXBlLmNsb3Nlc3QpIHtcbiAgICBFbGVtZW50LnByb3RvdHlwZS5jbG9zZXN0ID0gXG4gICAgZnVuY3Rpb24ocykge1xuICAgICAgICB2YXIgbWF0Y2hlcyA9ICh0aGlzLmRvY3VtZW50IHx8IHRoaXMub3duZXJEb2N1bWVudCkucXVlcnlTZWxlY3RvckFsbChzKSxcbiAgICAgICAgICAgIGksXG4gICAgICAgICAgICBlbCA9IHRoaXM7XG4gICAgICAgIGRvIHtcbiAgICAgICAgICAgIGkgPSBtYXRjaGVzLmxlbmd0aDtcbiAgICAgICAgICAgIHdoaWxlICgtLWkgPj0gMCAmJiBtYXRjaGVzLml0ZW0oaSkgIT09IGVsKSB7fTtcbiAgICAgICAgfSB3aGlsZSAoKGkgPCAwKSAmJiAoZWwgPSBlbC5wYXJlbnRFbGVtZW50KSk7IFxuICAgICAgICByZXR1cm4gZWw7XG4gICAgfTtcbn1cblxuLy9odHRwczovL2dpc3QuZ2l0aHViLmNvbS9wYXVsaXJpc2gvMTU3OTY3MVxuY29uc3QgcmVxdWVzdEFuaW1hdGlvbkZyYW1lUG9seWZpbGwgPSAoKCkgPT4ge1xuICAgIGxldCBjbG9jayA9IERhdGUubm93KCk7XG5cbiAgICByZXR1cm4gKGNhbGxiYWNrKSA9PiB7XG5cbiAgICAgICAgY29uc3QgY3VycmVudFRpbWUgPSBEYXRlLm5vdygpO1xuXG4gICAgICAgIGlmIChjdXJyZW50VGltZSAtIGNsb2NrID4gMTYpIHtcbiAgICAgICAgICAgIGNsb2NrID0gY3VycmVudFRpbWU7XG4gICAgICAgICAgICBjYWxsYmFjayhjdXJyZW50VGltZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBwb2x5ZmlsbChjYWxsYmFjayk7XG4gICAgICAgICAgICB9LCAwKTtcbiAgICAgICAgfVxuICAgIH07XG59KSgpO1xuXG53aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lID0gd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSAgICAgICB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy53ZWJraXRSZXF1ZXN0QW5pbWF0aW9uRnJhbWUgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cubW96UmVxdWVzdEFuaW1hdGlvbkZyYW1lICAgIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lUG9seWZpbGxcblxucmVxdWlyZSgnc21vb3Roc2Nyb2xsLXBvbHlmaWxsJykucG9seWZpbGwoKVxuXG5tb2R1bGUuZXhwb3J0cyA9IHRydWVcbiIsIm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmNyZWF0ZSgge1xuXG4gICAgRXJyb3I6IHJlcXVpcmUoJy4uLy4uL2xpYi9NeUVycm9yJyksXG4gICAgXG4gICAgVmlld0ZhY3Rvcnk6IHJlcXVpcmUoJy4vZmFjdG9yeS9WaWV3JyksXG4gICAgXG4gICAgVmlld3M6IHJlcXVpcmUoJy4vLlZpZXdNYXAnKSxcblxuICAgIFRvYXN0OiByZXF1aXJlKCcuL3ZpZXdzL1RvYXN0JyksXG5cbiAgICBjYXBpdGFsaXplRmlyc3RMZXR0ZXI6IHN0cmluZyA9PiBzdHJpbmcuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBzdHJpbmcuc2xpY2UoMSksXG5cbiAgICBpbml0aWFsaXplKCkge1xuXG4gICAgICAgIHRoaXMuY29udGVudENvbnRhaW5lciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNjb250ZW50JylcblxuICAgICAgICB0aGlzLlRvYXN0LmNvbnN0cnVjdG9yKClcblxuICAgICAgICB3aW5kb3cub25wb3BzdGF0ZSA9IHRoaXMuaGFuZGxlLmJpbmQodGhpcylcblxuICAgICAgICB0aGlzLmhlYWRlciA9XG4gICAgICAgICAgICB0aGlzLlZpZXdGYWN0b3J5LmNyZWF0ZShcbiAgICAgICAgICAgICAgICAnaGVhZGVyJyxcbiAgICAgICAgICAgICAgICB7IGluc2VydGlvbjogeyB2YWx1ZTogeyBlbDogdGhpcy5jb250ZW50Q29udGFpbmVyLCBtZXRob2Q6ICdpbnNlcnRCZWZvcmUnIH0gfSB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgICAub24oICduYXZpZ2F0ZScsIHJvdXRlID0+IHRoaXMubmF2aWdhdGUoIHJvdXRlICkgKVxuXG4gICAgICAgIHRoaXMuZm9vdGVyID1cbiAgICAgICAgICAgIHRoaXMuVmlld0ZhY3RvcnkuY3JlYXRlKFxuICAgICAgICAgICAgICAgICdmb290ZXInLFxuICAgICAgICAgICAgICAgIHsgaW5zZXJ0aW9uOiB7IHZhbHVlOiB7IGVsOiB0aGlzLmNvbnRlbnRDb250YWluZXIsIG1ldGhvZDogJ2FmdGVyJyB9IH0gfVxuICAgICAgICAgICAgKVxuXG4gICAgICAgIHRoaXMuaGFuZGxlKClcbiAgICB9LFxuXG4gICAgaGFuZGxlKCkge1xuICAgICAgICB0aGlzLmhhbmRsZXIoIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZS5zcGxpdCgnLycpLnNsaWNlKDEpIClcbiAgICB9LFxuXG4gICAgaGFuZGxlciggcGF0aCApIHtcbiAgICAgICAgY29uc3QgdmlldyA9IHRoaXMuVmlld3NbIHRoaXMuY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKCBwYXRoWzBdICkgXSA/IHBhdGhbMF0gOiAnaG9tZSdcblxuICAgICAgICBpZiggdmlldyA9PT0gdGhpcy5jdXJyZW50VmlldyApIHJldHVybiB0aGlzLnZpZXdzWyB2aWV3IF0ub25OYXZpZ2F0aW9uKCBwYXRoIClcblxuICAgICAgICB0aGlzLnNjcm9sbFRvVG9wKClcblxuICAgICAgICBQcm9taXNlLmFsbCggT2JqZWN0LmtleXMoIHRoaXMudmlld3MgKS5tYXAoIHZpZXcgPT4gdGhpcy52aWV3c1sgdmlldyBdLmhpZGUoKSApIClcbiAgICAgICAgLnRoZW4oICgpID0+IHtcblxuICAgICAgICAgICAgdGhpcy5jdXJyZW50VmlldyA9IHZpZXdcblxuICAgICAgICAgICAgaWYoIHRoaXMudmlld3NbIHZpZXcgXSApIHJldHVybiB0aGlzLnZpZXdzWyB2aWV3IF0ub25OYXZpZ2F0aW9uKCBwYXRoIClcblxuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShcbiAgICAgICAgICAgICAgICB0aGlzLnZpZXdzWyB2aWV3IF0gPVxuICAgICAgICAgICAgICAgICAgICB0aGlzLlZpZXdGYWN0b3J5LmNyZWF0ZSggdmlldywge1xuICAgICAgICAgICAgICAgICAgICAgICAgaW5zZXJ0aW9uOiB7IHZhbHVlOiB7IGVsOiB0aGlzLmNvbnRlbnRDb250YWluZXIgfSB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogeyB2YWx1ZTogcGF0aCwgd3JpdGFibGU6IHRydWUgfVxuICAgICAgICAgICAgICAgICAgICB9IClcbiAgICAgICAgICAgICAgICAgICAgLm9uKCAnbmF2aWdhdGUnLCByb3V0ZSA9PiB0aGlzLm5hdmlnYXRlKCByb3V0ZSApIClcbiAgICAgICAgICAgICAgICAgICAgLm9uKCAnZGVsZXRlZCcsICgpID0+IGRlbGV0ZSB0aGlzLnZpZXdzWyB2aWV3IF0gKVxuICAgICAgICAgICAgKVxuICAgICAgICB9IClcbiAgICAgICAgLmNhdGNoKCB0aGlzLkVycm9yIClcbiAgICB9LFxuXG4gICAgbmF2aWdhdGUoIGxvY2F0aW9uICkge1xuICAgICAgICBpZiggbG9jYXRpb24gIT09IHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSApIGhpc3RvcnkucHVzaFN0YXRlKCB7fSwgJycsIGxvY2F0aW9uIClcbiAgICAgICAgdGhpcy5oYW5kbGUoKVxuICAgIH0sXG5cbiAgICBzY3JvbGxUb1RvcCgpIHtcbiAgICAgICAgd2luZG93LnNjcm9sbCggeyB0b3A6IDAsIGxlZnQ6IDAsIGJlaGF2aW9yOiAnc21vb3RoJyB9IClcbiAgICB9LFxuXG59LCB7IGN1cnJlbnRWaWV3OiB7IHZhbHVlOiAnJywgd3JpdGFibGU6IHRydWUgfSwgdmlld3M6IHsgdmFsdWU6IHsgfSB9IH0gKVxuIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuYXNzaWduKCB7fSwgcmVxdWlyZSgnLi9fX3Byb3RvX18nKSwge1xuICAgIFxufSApXG4iLCJtb2R1bGUuZXhwb3J0cyA9IE9iamVjdC5hc3NpZ24oIHt9LCByZXF1aXJlKCcuL19fcHJvdG9fXycpLCB7XG5cbiAgICBldmVudHM6IHtcbiAgICAgICAgbmF2OiAnY2xpY2snXG4gICAgfSxcblxuICAgIG9uTmF2Q2xpY2soIGUgKSB7XG4gICAgICAgIGNvbnN0IGl0ZW1FbCA9IGUudGFyZ2V0LnRhZ05hbWUgPT09IFwiTElcIiA/IGUudGFyZ2V0IDogZS50YXJnZXQuY2xvc2VzdCgnbGknKSxcbiAgICAgICAgICAgICAgbmFtZSA9IGl0ZW1FbC5nZXRBdHRyaWJ1dGUoJ2RhdGEtbmFtZScpXG5cbiAgICAgICAgdGhpcy5lbWl0KCAnbmF2aWdhdGUnLCBuYW1lIClcbiAgICB9XG5cbn0gKVxuIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuYXNzaWduKCB7fSwgcmVxdWlyZSgnLi9fX3Byb3RvX18nKSwge1xuXG4gICAgZXZlbnRzOiB7XG4gICAgICAgIHNlcnZpY2VzOiAnY2xpY2snLFxuICAgICAgICBpbnRlcm5ldDogJ2NsaWNrJ1xuICAgIH0sXG5cbiAgICBvbkludGVybmV0Q2xpY2soKSB7IHRoaXMuZW1pdCggJ25hdmlnYXRlJywgJ2ludGVybmV0JyApIH0sXG5cbiAgICBvblNlcnZpY2VzQ2xpY2soKSB7IHRoaXMuZW1pdCggJ25hdmlnYXRlJywgJ3NlcnZpY2VzJyApIH1cbiAgICBcbn0gKVxuIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuYXNzaWduKCB7fSwgcmVxdWlyZSgnLi9fX3Byb3RvX18nKSwge1xuXG4gICAgZXZlbnRzOiB7XG4gICAgICAgICdzdWJtaXRCdG4nOiAnY2xpY2snXG4gICAgfSxcblxuICAgIG1vZGVsOiBPYmplY3QuY3JlYXRlKCByZXF1aXJlKCcuLi9tb2RlbHMvUGVyc29uJykgKSxcblxuICAgIGNsZWFyRm9ybSgpIHtcbiAgICAgICAgdGhpcy5lbHMubmFtZS52YWx1ZSA9ICcnXG4gICAgICAgIHRoaXMuZWxzLmNvbnRhY3QudmFsdWUgPSAnJ1xuICAgICAgICB0aGlzLmVscy5hZGRyZXNzLnZhbHVlID0gJydcbiAgICB9LFxuXG4gICAgb25TdWJtaXRCdG5DbGljaygpIHtcbiAgICAgICAgaWYoIHRoaXMuc3VibWl0dGluZyApIHJldHVyblxuXG4gICAgICAgIHRoaXMub25TdWJtaXRTdGFydCgpXG5cbiAgICAgICAgdGhpcy52YWxpZGF0ZSgpXG4gICAgICAgIC50aGVuKCByZXN1bHQgPT4ge1xuICAgICAgICAgICAgaWYoICFyZXN1bHQgKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCB0aGlzLm9uU3VibWl0RW5kKCkgKVxuXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5tb2RlbC5wb3N0KClcbiAgICAgICAgICAgIC50aGVuKCByZXNwb25zZSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuVG9hc3QuY3JlYXRlTWVzc2FnZSggJ3N1Y2Nlc3MnLCBcIkluZm8gc2VudCEgV2UnbGwga2VlcCB5b3UgcG9zdGVkIVwiIClcbiAgICAgICAgICAgICAgICAudGhlbiggKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoICduYXZpZ2F0ZScsICcvJyApXG4gICAgICAgICAgICAgICAgICAgIHRoaXMub25TdWJtaXRFbmQoKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNsZWFyRm9ybSgpXG4gICAgICAgICAgICAgICAgfSApXG4gICAgICAgICAgICB9IClcbiAgICAgICAgICAgIC5jYXRjaCggZSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5Ub2FzdC5jcmVhdGVNZXNzYWdlKCAnZXJyb3InLCBlICYmIGUubWVzc2FnZSA/IGUubWVzc2FnZSA6IGBUaGVyZSB3YXMgYSBwcm9ibGVtLiBQbGVhc2UgdHJ5IGFnYWluIG9yIGNvbnRhY3QgdXMuYCApO1xuICAgICAgICAgICAgICAgIHRoaXMub25TdWJtaXRFbmQoKVxuICAgICAgICAgICAgfSApXG4gICAgICAgIH0gKVxuICAgICAgICAuY2F0Y2goIGUgPT4geyB0aGlzLkVycm9yKGUpOyB0aGlzLnN1Ym1pdHRpbmcgPSBmYWxzZSB9IClcbiAgICB9LFxuXG4gICAgb25TdWJtaXRFbmQoKSB7XG4gICAgICAgIHRoaXMuc3VibWl0dGluZyA9IGZhbHNlXG4gICAgICAgIHRoaXMuZWxzLnN1Ym1pdEJ0bi5jbGFzc0xpc3QucmVtb3ZlKCdzdWJtaXR0aW5nJylcbiAgICB9LFxuICAgIFxuICAgIG9uU3VibWl0U3RhcnQoKSB7XG4gICAgICAgIHRoaXMuc3VibWl0dGluZyA9IHRydWVcbiAgICAgICAgdGhpcy5lbHMuc3VibWl0QnRuLmNsYXNzTGlzdC5hZGQoJ3N1Ym1pdHRpbmcnKVxuICAgIH0sXG5cbiAgICBwb3N0UmVuZGVyKCkge1xuICAgICAgICBPYmplY3Qua2V5cyggdGhpcy5lbHMgKS5mb3JFYWNoKCBhdHRyID0+IHsgICAgICAgIFxuICAgICAgICAgICAgY29uc3QgZWwgPSB0aGlzLmVsc1sgYXR0ciBdXG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmKCBhdHRyID09PSAnbmFtZScgfHwgYXR0ciA9PT0gJ2NvbnRhY3QnICkgZWwuYWRkRXZlbnRMaXN0ZW5lciggJ2ZvY3VzJywgKCkgPT4gZWwuY2xhc3NMaXN0LnJlbW92ZSgnZXJyb3InKSApICAgICAgIFxuICAgICAgICB9IClcblxuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH0sXG5cbiAgICB2YWxpZGF0ZSgpIHtcbiAgICAgICAgbGV0IHJ2ID0gdHJ1ZTtcblxuICAgICAgICBPYmplY3Qua2V5cyggdGhpcy5lbHMgKS5mb3JFYWNoKCBhdHRyID0+IHsgICAgICAgIFxuICAgICAgICAgICAgY29uc3QgZWwgPSB0aGlzLmVsc1sgYXR0ciBdXG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmKCBhdHRyICE9PSAnbmFtZScgJiYgYXR0ciAhPT0gJ2NvbnRhY3QnICkgcmV0dXJuXG5cbiAgICAgICAgICAgIGlmKCBydiA9PT0gdHJ1ZSAmJiAhdGhpcy5tb2RlbC52YWxpZGF0ZSggYXR0ciwgZWwudmFsdWUgKSApIHtcbiAgICAgICAgICAgICAgICB0aGlzLlRvYXN0LmNyZWF0ZU1lc3NhZ2UoICdlcnJvcicsIHRoaXMubW9kZWwuZmllbGRzWyBhdHRyIF0uZXJyb3IgKVxuICAgICAgICAgICAgICAgIGVsLnNjcm9sbEludG9WaWV3KCB7IGJlaGF2aW9yOiAnc21vb3RoJyB9IClcbiAgICAgICAgICAgICAgICBlbC5jbGFzc0xpc3QuYWRkKCAnZXJyb3InIClcbiAgICAgICAgICAgICAgICBydiA9IGZhbHNlXG4gICAgICAgICAgICB9IGVsc2UgaWYoIHRoaXMubW9kZWwudmFsaWRhdGUoIGF0dHIsIGVsLnZhbHVlICkgKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5tb2RlbC5kYXRhWyBhdHRyIF0gPSBlbC52YWx1ZS50cmltKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSApXG5cbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSggcnYgKVxuICAgIH1cblxufSApIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuYXNzaWduKCB7fSwgcmVxdWlyZSgnLi9fX3Byb3RvX18nKSwge1xuXG59ICkiLCJtb2R1bGUuZXhwb3J0cyA9IE9iamVjdC5hc3NpZ24oIHsgfSwgcmVxdWlyZSgnLi4vLi4vLi4vbGliL015T2JqZWN0JyksIHJlcXVpcmUoJ2V2ZW50cycpLkV2ZW50RW1pdHRlci5wcm90b3R5cGUsIHtcblxuICAgIE1vZGVsOiByZXF1aXJlKCcuLi9tb2RlbHMvX19wcm90b19fJyksXG5cbiAgICBPcHRpbWl6ZWRSZXNpemU6IHJlcXVpcmUoJy4vbGliL09wdGltaXplZFJlc2l6ZScpLFxuXG4gICAgYmluZEV2ZW50KCBrZXksIGV2ZW50LCBlbCApIHtcbiAgICAgICAgdmFyIGVscyA9IGVsID8gWyBlbCBdIDogQXJyYXkuaXNBcnJheSggdGhpcy5lbHNbIGtleSBdICkgPyB0aGlzLmVsc1sga2V5IF0gOiBbIHRoaXMuZWxzWyBrZXkgXSBdXG4gICAgICAgIGVscy5mb3JFYWNoKCBlbCA9PiBlbC5hZGRFdmVudExpc3RlbmVyKCBldmVudCB8fCAnY2xpY2snLCBlID0+IHRoaXNbIGBvbiR7dGhpcy5jYXBpdGFsaXplRmlyc3RMZXR0ZXIoa2V5KX0ke3RoaXMuY2FwaXRhbGl6ZUZpcnN0TGV0dGVyKGV2ZW50KX1gIF0oIGUgKSApIClcbiAgICB9LFxuXG4gICAgY2FwaXRhbGl6ZUZpcnN0TGV0dGVyOiBzdHJpbmcgPT4gc3RyaW5nLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgc3RyaW5nLnNsaWNlKDEpLFxuXG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMuc3Vidmlld0VsZW1lbnRzID0gWyBdXG5cbiAgICAgICAgaWYoIHRoaXMucmVxdWlyZXNMb2dpbiAmJiAoICF0aGlzLnVzZXIuaXNMb2dnZWRJbigpICkgKSByZXR1cm4gdGhpcy5oYW5kbGVMb2dpbigpXG4gICAgICAgIGlmKCB0aGlzLnVzZXIgJiYgIXRoaXMuaXNBbGxvd2VkKCB0aGlzLnVzZXIgKSApIHJldHVybiB0aGlzLnNjb290QXdheSgpXG5cbiAgICAgICAgcmV0dXJuIHRoaXMuaW5pdGlhbGl6ZSgpLnJlbmRlcigpXG4gICAgfSxcblxuICAgIGRlbGVnYXRlRXZlbnRzKCBrZXksIGVsICkge1xuICAgICAgICB2YXIgdHlwZSA9IHR5cGVvZiB0aGlzLmV2ZW50c1trZXldXG5cbiAgICAgICAgaWYoIHR5cGUgPT09IFwic3RyaW5nXCIgKSB7IHRoaXMuYmluZEV2ZW50KCBrZXksIHRoaXMuZXZlbnRzW2tleV0sIGVsICkgfVxuICAgICAgICBlbHNlIGlmKCBBcnJheS5pc0FycmF5KCB0aGlzLmV2ZW50c1trZXldICkgKSB7XG4gICAgICAgICAgICB0aGlzLmV2ZW50c1sga2V5IF0uZm9yRWFjaCggZXZlbnRPYmogPT4gdGhpcy5iaW5kRXZlbnQoIGtleSwgZXZlbnRPYmogKSApXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmJpbmRFdmVudCgga2V5LCB0aGlzLmV2ZW50c1trZXldLmV2ZW50IClcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBkZWxldGUoIGlzU2xvdywgYW5pbWF0ZT10cnVlICkge1xuICAgICAgICByZXR1cm4gdGhpcy5oaWRlKCBpc1Nsb3csIGFuaW1hdGUgKVxuICAgICAgICAudGhlbiggKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5lbHMuY29udGFpbmVyLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoIHRoaXMuZWxzLmNvbnRhaW5lciApXG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCB0aGlzLmVtaXQoJ2RlbGV0ZWQnKSApXG4gICAgICAgIH0gKVxuICAgIH0sXG5cbiAgICBldmVudHM6IHt9LFxuXG4gICAgZ2V0VGVtcGxhdGVPcHRpb25zKCkge1xuICAgICAgICBjb25zdCBydiA9IE9iamVjdC5hc3NpZ24oIHRoaXMudXNlciA/IHsgdXNlcjogdGhpcy51c2VyLmRhdGEgfSA6IHt9IClcblxuICAgICAgICBpZiggdGhpcy5tb2RlbCApIHtcbiAgICAgICAgICAgIHJ2Lm1vZGVsID0gdGhpcy5tb2RlbC5kYXRhXG5cbiAgICAgICAgICAgIGlmKCB0aGlzLm1vZGVsLm1ldGEgKSBydi5tZXRhID0gdGhpcy5tb2RlbC5tZXRhXG4gICAgICAgIH1cblxuICAgICAgICBpZiggdGhpcy50ZW1wbGF0ZU9wdGlvbnMgKSBydi5vcHRzID0gdHlwZW9mIHRoaXMudGVtcGxhdGVPcHRpb25zID09PSAnZnVuY3Rpb24nID8gdGhpcy50ZW1wbGF0ZU9wdGlvbnMoKSA6IHRoaXMudGVtcGxhdGVPcHRpb25zXG5cbiAgICAgICAgcmV0dXJuIHJ2XG4gICAgfSxcblxuICAgIGhhbmRsZUxvZ2luKCkge1xuICAgICAgICB0aGlzLmZhY3RvcnkuY3JlYXRlKCAnbG9naW4nLCB7IGluc2VydGlvbjogeyB2YWx1ZTogeyBlbDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2NvbnRlbnQnKSB9IH0gfSApXG4gICAgICAgICAgICAub25jZSggXCJsb2dnZWRJblwiLCAoKSA9PiB0aGlzLm9uTG9naW4oKSApXG5cbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICB9LFxuXG4gICAgaGlkZSggaXNTbG93LCBhbmltYXRlPXRydWUgKSB7IHJldHVybiB0aGlzLmhpZGVFbCggdGhpcy5lbHMuY29udGFpbmVyLCBpc1Nsb3csIGFuaW1hdGUgKS50aGVuKCAoKSA9PiB0aGlzLmVtaXQoJ2hpZGRlbicpICkgfSxcblxuICAgIF9oaWRlRWwoIGVsLCBrbGFzcywgcmVzb2x2ZSwgaGFzaCApIHtcbiAgICAgICAgZWwucmVtb3ZlRXZlbnRMaXN0ZW5lciggJ2FuaW1hdGlvbmVuZCcsIHRoaXNbIGhhc2ggXSApXG4gICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpXG4gICAgICAgIGVsLmNsYXNzTGlzdC5yZW1vdmUoIGtsYXNzIClcbiAgICAgICAgZGVsZXRlIHRoaXNbaGFzaF1cbiAgICAgICAgcmVzb2x2ZSgpXG4gICAgfSxcblxuICAgIGhpZGVFbCggZWwsIGlzU2xvdywgYW5pbWF0ZT10cnVlICkge1xuICAgICAgICBpZiggdGhpcy5pc0hpZGRlbiggZWwgKSApIHJldHVybiBQcm9taXNlLnJlc29sdmUoKVxuXG4gICAgICAgIGNvbnN0IHRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKSxcbiAgICAgICAgICAgIGhhc2ggPSBgJHt0aW1lfUhpZGVgXG4gICAgICAgIFxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoIHJlc29sdmUgPT4ge1xuICAgICAgICAgICAgaWYoICFhbmltYXRlICkgcmV0dXJuIHJlc29sdmUoIGVsLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpIClcblxuICAgICAgICAgICAgY29uc3Qga2xhc3MgPSBgYW5pbWF0ZS1vdXQkeyBpc1Nsb3cgPyAnLXNsb3cnIDogJyd9YFxuICAgICAgICAgICAgdGhpc1sgaGFzaCBdID0gZSA9PiB0aGlzLl9oaWRlRWwoIGVsLCBrbGFzcywgcmVzb2x2ZSwgaGFzaCApXG4gICAgICAgICAgICBlbC5hZGRFdmVudExpc3RlbmVyKCAnYW5pbWF0aW9uZW5kJywgdGhpc1sgaGFzaCBdIClcbiAgICAgICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoIGtsYXNzIClcbiAgICAgICAgfSApXG4gICAgfSxcblxuICAgIGh0bWxUb0ZyYWdtZW50KCBzdHIgKSB7XG4gICAgICAgIGxldCByYW5nZSA9IGRvY3VtZW50LmNyZWF0ZVJhbmdlKCk7XG4gICAgICAgIC8vIG1ha2UgdGhlIHBhcmVudCBvZiB0aGUgZmlyc3QgZGl2IGluIHRoZSBkb2N1bWVudCBiZWNvbWVzIHRoZSBjb250ZXh0IG5vZGVcbiAgICAgICAgcmFuZ2Uuc2VsZWN0Tm9kZShkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImRpdlwiKS5pdGVtKDApKVxuICAgICAgICByZXR1cm4gcmFuZ2UuY3JlYXRlQ29udGV4dHVhbEZyYWdtZW50KCBzdHIgKVxuICAgIH0sXG5cbiAgICBpbml0aWFsaXplKCkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbiggdGhpcywgeyBlbHM6IHsgfSwgc2x1cnA6IHsgYXR0cjogJ2RhdGEtanMnLCB2aWV3OiAnZGF0YS12aWV3JywgbmFtZTogJ2RhdGEtbmFtZScgfSwgdmlld3M6IHsgfSB9IClcbiAgICB9LFxuXG4gICAgaXNBbGxvd2VkKCB1c2VyICkge1xuICAgICAgICBpZiggIXRoaXMucmVxdWlyZXNSb2xlICkgcmV0dXJuIHRydWVcbiAgICAgICAgcmV0dXJuIHRoaXMucmVxdWlyZXNSb2xlICYmIHVzZXIuZGF0YS5yb2xlcy5pbmNsdWRlcyggdGhpcy5yZXF1aXJlc1JvbGUgKVxuICAgIH0sXG4gICAgXG4gICAgaXNIaWRkZW4oIGVsICkge1xuICAgICAgICBjb25zdCBlbGVtZW50ID0gZWwgfHwgdGhpcy5lbHMuY29udGFpbmVyXG4gICAgICAgIHJldHVybiBlbGVtZW50LmNsYXNzTGlzdC5jb250YWlucygnaGlkZGVuJylcbiAgICB9LFxuXG4gICAgb25Mb2dpbigpIHtcblxuICAgICAgICBpZiggIXRoaXMuaXNBbGxvd2VkKCB0aGlzLnVzZXIgKSApIHJldHVybiB0aGlzLnNjb290QXdheSgpXG5cbiAgICAgICAgdGhpcy5pbml0aWFsaXplKCkucmVuZGVyKClcbiAgICB9LFxuXG4gICAgb25OYXZpZ2F0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5zaG93KClcbiAgICB9LFxuXG4gICAgc2hvd05vQWNjZXNzKCkge1xuICAgICAgICBhbGVydChcIk5vIHByaXZpbGVnZXMsIHNvblwiKVxuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH0sXG5cbiAgICBwb3N0UmVuZGVyKCkgeyByZXR1cm4gdGhpcyB9LFxuXG4gICAgcmVuZGVyKCkge1xuICAgICAgICBpZiggdGhpcy5kYXRhICkgdGhpcy5tb2RlbCA9IE9iamVjdC5jcmVhdGUoIHRoaXMuTW9kZWwsIHsgfSApLmNvbnN0cnVjdG9yKCB0aGlzLmRhdGEgKVxuXG4gICAgICAgIHRoaXMuc2x1cnBUZW1wbGF0ZSggeyB0ZW1wbGF0ZTogdGhpcy50ZW1wbGF0ZSggdGhpcy5nZXRUZW1wbGF0ZU9wdGlvbnMoKSApLCBpbnNlcnRpb246IHRoaXMuaW5zZXJ0aW9uIHx8IHsgZWw6IGRvY3VtZW50LmJvZHkgfSwgaXNWaWV3OiB0cnVlIH0gKVxuXG4gICAgICAgIHRoaXMucmVuZGVyU3Vidmlld3MoKVxuXG4gICAgICAgIGlmKCB0aGlzLnNpemUgKSB7IHRoaXMuc2l6ZSgpOyB0aGlzLk9wdGltaXplZFJlc2l6ZS5hZGQoIHRoaXMuc2l6ZS5iaW5kKHRoaXMpICkgfVxuXG4gICAgICAgIHJldHVybiB0aGlzLnBvc3RSZW5kZXIoKVxuICAgIH0sXG5cbiAgICByZW5kZXJTdWJ2aWV3cygpIHtcbiAgICAgICAgdGhpcy5zdWJ2aWV3RWxlbWVudHMuZm9yRWFjaCggb2JqID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBvYmoubmFtZVxuXG4gICAgICAgICAgICBsZXQgb3B0cyA9IHsgfVxuXG4gICAgICAgICAgICBpZiggdGhpcy5WaWV3cyAmJiB0aGlzLlZpZXdzWyBuYW1lIF0gKSBvcHRzID0gdHlwZW9mIHRoaXMuVmlld3NbIG5hbWUgXSA9PT0gXCJvYmplY3RcIiA/IHRoaXMuVmlld3NbIG5hbWUgXSA6IFJlZmxlY3QuYXBwbHkoIHRoaXMuVmlld3NbIG5hbWUgXSwgdGhpcywgWyBdIClcblxuICAgICAgICAgICAgdGhpcy52aWV3c1sgbmFtZSBdID0gdGhpcy5mYWN0b3J5LmNyZWF0ZSgga2V5LCBPYmplY3QuYXNzaWduKCB7IGluc2VydGlvbjogeyB2YWx1ZTogeyBlbDogb2JqLmVsLCBtZXRob2Q6ICdpbnNlcnRCZWZvcmUnIH0gfSB9LCB7IG9wdHM6IHsgdmFsdWU6IG9wdHMgfSB9ICkgKVxuICAgICAgICAgICAgb2JqLmVsLnJlbW92ZSgpXG4gICAgICAgIH0gKVxuXG4gICAgICAgIGRlbGV0ZSB0aGlzLnN1YnZpZXdFbGVtZW50c1xuXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgfSxcblxuICAgIHNjb290QXdheSgpIHtcbiAgICAgICAgdGhpcy5Ub2FzdC5zaG93KCAnZXJyb3InLCAnWW91IGFyZSBub3QgYWxsb3dlZCBoZXJlLiAgU29ycnkuJylcbiAgICAgICAgLmNhdGNoKCBlID0+IHsgdGhpcy5FcnJvciggZSApOyB0aGlzLmVtaXQoICduYXZpZ2F0ZScsIGAvYCApIH0gKVxuICAgICAgICAudGhlbiggKCkgPT4gdGhpcy5lbWl0KCAnbmF2aWdhdGUnLCBgL2AgKSApXG5cbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICB9LFxuXG4gICAgc2hvdyggaXNTbG93LCBhbmltYXRlPXRydWUgKSB7IHJldHVybiB0aGlzLnNob3dFbCggdGhpcy5lbHMuY29udGFpbmVyLCBpc1Nsb3csIGFuaW1hdGUgKS50aGVuKCAoKSA9PiB0aGlzLmVtaXQoJ3Nob3duJykgKSB9LFxuXG4gICAgX3Nob3dFbCggZWwsIGtsYXNzLCByZXNvbHZlLCBoYXNoICkge1xuICAgICAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKCAnYW5pbWF0aW9uZW5kJywgdGhpc1toYXNoXSApXG4gICAgICAgIGVsLmNsYXNzTGlzdC5yZW1vdmUoIGtsYXNzIClcbiAgICAgICAgZGVsZXRlIHRoaXNbIGhhc2ggXVxuICAgICAgICByZXNvbHZlKClcbiAgICB9LFxuXG4gICAgc2hvd0VsKCBlbCwgaXNTbG93LCBhbmltYXRlPXRydWUgKSB7XG4gICAgICAgIGlmKCAhdGhpcy5pc0hpZGRlbiggZWwgKSApIHJldHVybiBQcm9taXNlLnJlc29sdmUoKVxuXG4gICAgICAgIGNvbnN0IHRpbWUgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKSxcbiAgICAgICAgICAgIGhhc2ggPSBgJHt0aW1lfVNob3dgXG5cbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKCByZXNvbHZlID0+IHtcbiAgICAgICAgICAgIGVsLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpXG5cbiAgICAgICAgICAgIGlmKCAhYW5pbWF0ZSApIHJldHVybiByZXNvbHZlKClcblxuICAgICAgICAgICAgY29uc3Qga2xhc3MgPSBgYW5pbWF0ZS1pbiR7IGlzU2xvdyA/ICctc2xvdycgOiAnJ31gXG4gICAgICAgICAgICB0aGlzWyBoYXNoIF0gPSBlID0+IHRoaXMuX3Nob3dFbCggZWwsIGtsYXNzLCByZXNvbHZlLCBoYXNoIClcbiAgICAgICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoICdhbmltYXRpb25lbmQnLCB0aGlzWyBoYXNoIF0gKSAgICAgICAgICAgIFxuICAgICAgICAgICAgZWwuY2xhc3NMaXN0LmFkZCgga2xhc3MgKVxuICAgICAgICB9ICkgICAgICAgIFxuICAgIH0sXG5cbiAgICBzbHVycEVsKCBlbCApIHtcbiAgICAgICAgdmFyIGtleSA9IGVsLmdldEF0dHJpYnV0ZSggdGhpcy5zbHVycC5hdHRyICkgfHwgJ2NvbnRhaW5lcidcblxuICAgICAgICBpZigga2V5ID09PSAnY29udGFpbmVyJyApIGVsLmNsYXNzTGlzdC5hZGQoIHRoaXMubmFtZSApXG5cbiAgICAgICAgdGhpcy5lbHNbIGtleSBdID0gQXJyYXkuaXNBcnJheSggdGhpcy5lbHNbIGtleSBdIClcbiAgICAgICAgICAgID8gdGhpcy5lbHNbIGtleSBdLmNvbmNhdCggZWwgKVxuICAgICAgICAgICAgOiAoIHRoaXMuZWxzWyBrZXkgXSAhPT0gdW5kZWZpbmVkIClcbiAgICAgICAgICAgICAgICA/IFsgdGhpcy5lbHNbIGtleSBdLCBlbCBdXG4gICAgICAgICAgICAgICAgOiBlbFxuXG4gICAgICAgIGVsLnJlbW92ZUF0dHJpYnV0ZSh0aGlzLnNsdXJwLmF0dHIpXG5cbiAgICAgICAgaWYoIHRoaXMuZXZlbnRzWyBrZXkgXSApIHRoaXMuZGVsZWdhdGVFdmVudHMoIGtleSwgZWwgKVxuICAgIH0sXG5cbiAgICBzbHVycFRlbXBsYXRlKCBvcHRpb25zICkge1xuICAgICAgICB2YXIgZnJhZ21lbnQgPSB0aGlzLmh0bWxUb0ZyYWdtZW50KCBvcHRpb25zLnRlbXBsYXRlICksXG4gICAgICAgICAgICBzZWxlY3RvciA9IGBbJHt0aGlzLnNsdXJwLmF0dHJ9XWAsXG4gICAgICAgICAgICB2aWV3U2VsZWN0b3IgPSBgWyR7dGhpcy5zbHVycC52aWV3fV1gLFxuICAgICAgICAgICAgZmlyc3RFbCA9IGZyYWdtZW50LnF1ZXJ5U2VsZWN0b3IoJyonKVxuXG4gICAgICAgIGlmKCBvcHRpb25zLmlzVmlldyB8fCBmaXJzdEVsLmdldEF0dHJpYnV0ZSggdGhpcy5zbHVycC5hdHRyICkgKSB0aGlzLnNsdXJwRWwoIGZpcnN0RWwgKVxuICAgICAgICBmcmFnbWVudC5xdWVyeVNlbGVjdG9yQWxsKCBgJHtzZWxlY3Rvcn0sICR7dmlld1NlbGVjdG9yfWAgKS5mb3JFYWNoKCBlbCA9PiB7XG4gICAgICAgICAgICBpZiggZWwuaGFzQXR0cmlidXRlKCB0aGlzLnNsdXJwLmF0dHIgKSApIHsgdGhpcy5zbHVycEVsKCBlbCApIH1cbiAgICAgICAgICAgIGVsc2UgaWYoIGVsLmhhc0F0dHJpYnV0ZSggdGhpcy5zbHVycC52aWV3ICkgKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5zdWJ2aWV3RWxlbWVudHMucHVzaCggeyBlbCwgdmlldzogZWwuZ2V0QXR0cmlidXRlKHRoaXMuc2x1cnAudmlldyksIG5hbWU6IGVsLmdldEF0dHJpYnV0ZSh0aGlzLnNsdXJwLm5hbWUpIH0gKVxuICAgICAgICAgICAgfVxuICAgICAgICB9IClcbiAgICAgICAgICBcbiAgICAgICAgb3B0aW9ucy5pbnNlcnRpb24ubWV0aG9kID09PSAnaW5zZXJ0QmVmb3JlJ1xuICAgICAgICAgICAgPyBvcHRpb25zLmluc2VydGlvbi5lbC5wYXJlbnROb2RlLmluc2VydEJlZm9yZSggZnJhZ21lbnQsIG9wdGlvbnMuaW5zZXJ0aW9uLmVsIClcbiAgICAgICAgICAgIDogb3B0aW9ucy5pbnNlcnRpb24uZWxbIG9wdGlvbnMuaW5zZXJ0aW9uLm1ldGhvZCB8fCAnYXBwZW5kQ2hpbGQnIF0oIGZyYWdtZW50IClcblxuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH1cbn0gKVxuIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuY3JlYXRlKCB7XG5cbiAgICBhZGQoY2FsbGJhY2spIHtcbiAgICAgICAgaWYoICF0aGlzLmNhbGxiYWNrcy5sZW5ndGggKSB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgdGhpcy5vblJlc2l6ZS5iaW5kKHRoaXMpIClcbiAgICAgICAgdGhpcy5jYWxsYmFja3MucHVzaChjYWxsYmFjaylcbiAgICB9LFxuXG4gICAgb25SZXNpemUoKSB7XG4gICAgICAgaWYoIHRoaXMucnVubmluZyApIHJldHVyblxuXG4gICAgICAgIHRoaXMucnVubmluZyA9IHRydWVcbiAgICAgICAgXG4gICAgICAgIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWVcbiAgICAgICAgICAgID8gd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSggdGhpcy5ydW5DYWxsYmFja3MuYmluZCh0aGlzKSApXG4gICAgICAgICAgICA6IHNldFRpbWVvdXQoIHRoaXMucnVuQ2FsbGJhY2tzLCA2NiApXG4gICAgfSxcblxuICAgIHJ1bkNhbGxiYWNrcygpIHtcbiAgICAgICAgdGhpcy5jYWxsYmFja3MgPSB0aGlzLmNhbGxiYWNrcy5maWx0ZXIoIGNhbGxiYWNrID0+IGNhbGxiYWNrKCkgKVxuICAgICAgICB0aGlzLnJ1bm5pbmcgPSBmYWxzZSBcbiAgICB9XG5cbn0sIHsgY2FsbGJhY2tzOiB7IHdyaXRhYmxlOiB0cnVlLCB2YWx1ZTogW10gfSwgcnVubmluZzogeyB3cml0YWJsZTogdHJ1ZSwgdmFsdWU6IGZhbHNlIH0gfSApXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHAgPT5cbmA8Zm9vdGVyPlxuICAgIDxkaXYgY2xhc3M9XCJjb250YWN0XCI+XG4gICAgICAgIDxkaXY+JmNvcHk7IDIwMTcgfCBBbGxlZ2FuIEludGVybmV0IFdpemFyZDwvZGl2PlxuICAgICAgICA8ZGl2PjEyMyBCYXlyb24gTGFuZSB8IEFsbGVnYW4sIE1JIDEyMzQ1IHwgMTIzLjQ1Ni43ODkwPC9kaXY+XG4gICAgICAgIDxkaXY+dGhlX3dpekBhaXcuY29tPC9kaXY+XG4gICAgPC9kaXY+XG48L2Zvb3Rlcj5gXG4iLCJtb2R1bGUuZXhwb3J0cyA9ICgpID0+XG5gPG5hdj5cbiAgICA8ZGl2IGNsYXNzPVwiY29udGFjdFwiPlxuICAgICAgICA8ZGl2PnBob25lOiAxMjMuNDU2Ljc4OTAgfCBlbWFpbDogdGhlX3dpekBhaXcuY29tPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPHVsIGRhdGEtanM9XCJuYXZcIj5cbiAgICAgICAgPGxpIGRhdGEtbmFtZT1cImhvbWVcIj5Ib21lPC9saT5cbiAgICAgICAgPGxpIGRhdGEtbmFtZT1cInNlcnZpY2VzXCI+U2VydmljZXM8L2xpPlxuICAgICAgICA8bGkgZGF0YS1uYW1lPVwiaW50ZXJuZXRcIj5Mb2NhbCBJbnRlcm5ldCE8L2xpPlxuICAgIDwvdWw+XG48L25hdj5gXG4iLCJtb2R1bGUuZXhwb3J0cyA9ICgpID0+XG5gPGRpdj5cbiAgICA8ZGl2PlxuICAgICAgICA8aW1nIHNyYz1cIi9zdGF0aWMvaW1nL2xvZ28uc3ZnXCI+XG4gICAgPC9kaXY+XG4gICAgPGRpdj5cbiAgICAgICAgPGgyPk1ha2UgWW91ciBUZWNoIFByb2JsZW1zIE1hZ2ljYWxseSBEaXNhcHBlYXIhPC9oMj5cbiAgICAgICAgPHA+Q29tcHV0ZXJzLiBDYW4ndCBsaXZlIHdpdGggJ2VtLCBjYW4ndCBsaXZlIHdpdGhvdXQgJ2VtLiBUaGV5J3JlIGEgaHVnZSBwYXJ0IG9mIG91ciBsaXZlcyB0aGVzZSBkYXlzLCBidXQgdW5mb3J0dW5hdGVseVxuICAgICAgICB0aGV5IGhhdmVuJ3QgZ290dGVuIGFueSBsZXNzIGNvbXBsaWNhdGVkLiBUaGluZ3MgY2FuIGFuZCBkbyBnbyB3cm9uZyBhbGwgdGhlIHRpbWUsIGFuZCB0aGVuIHlvdSBlbmQgdXAgc3BlbmRpbmcgaG91cnNcbiAgICAgICAgYW5kIGhvdXJzIG9mIHlvdXIgdmFsdWFibGUgdGltZSB0cnlpbmcgdG8gZmlndXJlIG91dCB3aGF0IHRoZSBoZWNrIGhhcHBlbmVkIGFuZCBmaXggaXQuIExpZmUncyB0b28gc2hvcnQgZm9yIGFsbCB0aGF0IGZydXN0cmF0aW9uLlxuICAgICAgICBXaHkgbm90IGhpcmUgYSBwcm9mZXNzaW9uYWwgdG8gdGFrZSBjYXJlIG9mIGl0IHF1aWNrbHkgYW5kIHBhaW5sZXNzbHk/IEdpdmUgVGhlIFdpemFyZCBhIGNhbGwhPC9wPlxuICAgICAgICA8cD5BbGxlZ2FuIEludGVybmV0IFdpemFyZCBpcyBoZXJlIHRvIGFzc2lzdCB0aGUgY2l0aXplbnMgb2YgQWxsZWdhbiB3aXRoIGFsbCBvZiB0aGVpciB0ZWNoIG5lZWRzLiBXaGV0aGVyIHlvdSBhcmUgYVxuICAgICAgICBub3JtYWwgaG9tZSB1c2VyIG9yIGEgc21hbGwgYnVzaW5lc3MsIHdlIHdpbGwgdXNlIG91ciAxNSsgeWVhcnMgb2YgZXhwZXJpZW5jZSBpbiB0aGUgdGVjaCBpbmR1c3RyeSB0byBzb2x2ZSB5b3VyIHByb2JsZW1zXG4gICAgICAgIHdpdGggc3BlZWQsIGNvdXJ0ZXN5LCBhbmQgcHJvZmVzc2lvbmFsaXNtLiBXYW50IHRvIGZpbmQgb3V0IG1vcmU/IENsaWNrIDxzcGFuIGNsYXNzPVwibGlua1wiIGRhdGEtanM9XCJzZXJ2aWNlc1wiPmhlcmU8L3NwYW4+XG4gICAgICAgIGZvciBhIGxpc3Qgb2Ygb3VyIHNlcnZpY2VzLjwvcD5cbiAgICAgICAgPHA+PHNwYW4gY2xhc3M9XCJub3RpY2VcIj5TcGVjaWFsIG5vdGljZTwvc3Bhbj46IHdlIGFyZSBjb25zaWRlcmluZyBleHBhbmRpbmcgb3VyIGJ1c2luZXNzIHRvIHByb3ZpZGUgaW50ZXJuZXQgc2VydmljZSB0byBBbGxlZ2FuLlxuICAgICAgICBDbGljayA8c3BhbiBjbGFzcz1cImxpbmtcIiBkYXRhLWpzPVwiaW50ZXJuZXRcIj5oZXJlPC9zcGFuPiB0byBmaW5kIG91dCBtb3JlLjwvcD5cbiAgICA8L2Rpdj4gICAgICAgIFxuPC9kaXY+YFxuIiwibW9kdWxlLmV4cG9ydHMgPSAoKSA9PlxuYDxkaXY+XG4gICAgPGRpdj5cbiAgICAgICAgPGgyPkxvY2FsIEludGVybmV0IFNlcnZpY2UgZm9yIEFsbGVnYW48L2gyPlxuICAgICAgICA8cD5Ob3QgaGFwcHkgd2l0aCB5b3VyIGludGVybmV0IG9wdGlvbnMgaW4gQWxsZWdhbj8gVGlyZWQgb2YgcGF5aW5nIHRvbyBtdWNoIGZvciBsb3VzeSBzcGVlZHMgYW5kIGNvbnN0YW50IHNlcnZpY2UgaW50ZXJydXB0aW9ucz9cbiAgICAgICAgV2VsbCwgeW91J3JlIGluIGx1Y2ssIGJlY2F1c2UgQWxsZWdhbiBJbnRlcm5ldCBXaXphcmQgaXMgY3VycmVudGx5IGNvbnNpZGVyaW5nIGxhdW5jaGluZyBvdXIgb3duIGludGVybmV0IHNlcnZpY2UgZm9yXG4gICAgICAgIHRoZSBmaW5lIGNpdGl6ZW5zIG9mIEFsbGVnYW4uIFdlIGJlbGlldmUgdGhlcmUncyBub3QgbmVhcmx5IGVub3VnaCBmcmVlZG9tIGFuZCBjaG9pY2Ugd2hlbiBpdCBjb21lcyB0byBpbnRlcm5ldCBwcm92aWRlcnMsIGFuZFxuICAgICAgICB3ZSdkIGxpa2UgdG8gdXNlIG91ciB0ZWNoIHNraWxscyB0byBjaGFuZ2UgdGhhdCBhbmQgb2ZmZXIgQWxsZWdhbiBmYXN0LCByZWxpYWJsZSBzZXJ2aWNlIGF0IGEgcmVhc29uYWJsZSBwcmljZS5cbiAgICAgICAgTGV0J3MgZ2l2ZSB0aG9zZSBmYXQgY2F0IHRlbGVjb21zIHNvbWUgcmVhbCBjb21wZXRpdGlvbiE8L3A+XG4gICAgICAgIDxwPklmIHRoaXMgc291bmRzIGdvb2QgdG8geW91LCBwbGVhc2UgbGVhdmUgeW91ciBuYW1lIGFuZCBjb250YWN0IGluZm8sIGFuZCB3ZSdsbCBsZXQgeW91IGtub3cgaG93IHRoaW5ncyBhcmUgZGV2ZWxvcGluZy5cbiAgICAgICAgVGhhbmsgeW91IGZvciB5b3VyIGludGVyZXN0ITwvcD5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiYm9yZGVyXCI+PC9kaXY+XG4gICAgPGZvcm0+XG4gICAgICAgIDxpbnB1dCBkYXRhLWpzPVwibmFtZVwiIHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJOYW1lXCI+XG4gICAgICAgIDxpbnB1dCBkYXRhLWpzPVwiY29udGFjdFwiIHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJFbWFpbCBvciBQaG9uZSBOdW1iZXJcIj5cbiAgICAgICAgPGlucHV0IGRhdGEtanM9XCJhZGRyZXNzXCIgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIkFkZHJlc3NcIj5cbiAgICAgICAgPGJ1dHRvbiBkYXRhLWpzPVwic3VibWl0QnRuXCIgdHlwZT1cImJ1dHRvblwiPlN1Ym1pdDwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbjwvZGl2PmAiLCJtb2R1bGUuZXhwb3J0cyA9ICgpID0+XG5gPGRpdj5cbiAgICA8aDE+T3VyIFNlcnZpY2VzPC9oMT5cbiAgICA8ZGl2IGNsYXNzPVwiaW50cm9cIj5cbiAgICAgICAgPHA+V2FudCB0byBpbXByb3ZlIHlvdXIgaG9tZSBuZXR3b3JrPyBQcm90ZWN0IHlvdXIga2lkcyBmcm9tIGluYXBwcm9wcmlhdGUgY29udGVudCBvbiB0aGUgd2ViPyBOZWVkIGhlbHAgZXhwbG9yaW5nXG4gICAgICAgIHlvdXIgaW50ZXJuZXQgc2VydmljZSBvcHRpb25zPyBDYW4ndCBmaWd1cmUgb3V0IHdoeSBhIHdlYiBwYWdlIGlzbid0IHdvcmtpbmc/IE1heWJlIHlvdSdyZSBhIGJ1c2luZXNzIGFuZCB3YW50IHRvIGJ1aWxkXG4gICAgICAgIGEgbmV3IHdlYnNpdGUgb3IgaW1wcm92ZSB5b3VyIGN1cnJlbnQgb25lLiBGcm9tIGdlbmVyYWwgdGVjaCBzdXBwb3J0IHRvIHdlYiBkZXZlbG9wbWVudCwgd2UndmUgZ290IHlvdSBjb3ZlcmVkITwvcD5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiYm9yZGVyXCI+PC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImNhdGVnb3JpZXNcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMz5HZW5lcmFsIFRlY2ggU3VwcG9ydDwvaDM+XG4gICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgPGxpPk1hYyBhbmQgUEMuIExhcHRvcCwgZGVza3RvcCwgbW9iaWxlLCBhbmQgdGFibGV0LiBUZWxsIHVzIHlvdXIgcHJvYmxlbSBhbmQgd2UnbGwgZml4IGl0ITwvbGk+XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMz5JbnRlcm5ldCBTZXJ2aWNlIEFkdmljZTwvaDM+XG4gICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgPGxpPldlJ2xsIHRha2UgYSBsb29rIGF0IHdoZXJlIHlvdSBsaXZlIGFuZCBsZXQgeW91IGtub3cgd2hhdCB5b3VyIGJlc3Qgb3B0aW9ucyBhcmUgZm9yIGNvbm5lY3RpbmdcbiAgICAgICAgICAgICAgICB0byB0aGUgaW50ZXJuZXQ8L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDM+RGF0YSBSZWNvdmVyeSBhbmQgQmFja3VwczwvaDM+XG4gICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgPGxpPkhhcmQgZHJpdmUgY3Jhc2g/IFdlJ2xsIGhlbHAgeW91IGdldCB5b3VyIHZhbHVhYmxlIGRhdGEgYmFjazwvbGk+XG4gICAgICAgICAgICAgICAgPGxpPkFuZCB3ZSdsbCBoZWxwIHlvdSBiYWNrIHlvdXIgZGF0YSB1cCBzbyB0aGF0IGl0J3Mgc2FmZSBmb3IgdGhlIGZ1dHVyZTwvbGk+XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMz5OZXR3b3JrczwvaDM+XG4gICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAgPGxpPkluc3RhbGxhdGlvbiBvZiB3aXJlZCBhbmQgd2lyZWxlc3MgbmV0d29ya3M8L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5Ucm91Ymxlc2hvb3RpbmcgZm9yIGludGVybmV0IGNvbm5lY3Rpb24gaXNzdWVzPC9saT5cbiAgICAgICAgICAgICAgICA8bGk+Q29uZmlndXJhdGlvbiBvZiBtb2RlbXMgYW5kIHJvdXRlcnM8L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDM+Q29tcHV0ZXIgU2VjdXJpdHk8L2gzPlxuICAgICAgICAgICAgPHVsPlxuICAgICAgICAgICAgICAgIDxsaT5LZWVwIHlvdXIga2lkcyBzYWZlIGZyb20gaW5hcHByb3ByaWF0ZSBjb250ZW50PC9saT5cbiAgICAgICAgICAgICAgICA8bGk+RmluZCBhbmQgZWxpbWluYXRlIHZpcnVzZXMsIG1hbHdhcmUsIGFuZCBzcHl3YXJlPC9saT5cbiAgICAgICAgICAgICAgICA8bGk+U2V0IHVwIGFudGl2aXJ1cyBzb2Z0d2FyZSBhbmQgZmlyZXdhbGxzIGZvciBmdXJ0aGVyIHByb3RlY3Rpb248L2xpPlxuICAgICAgICAgICAgPC91bD5cbiAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMz5IZWxwIGZvciBCdXNpbmVzc2VzPC9oMz5cbiAgICAgICAgICAgIDx1bD5cbiAgICAgICAgICAgICAgICA8bGk+RnVsbHkgY3VzdG9taXphYmxlIHdlYnNpdGVzIHRoYXQgd2lsbCBpbXByb3ZlIHlvdXIgYnJhbmQgYW5kIG9wdGltaXplIHlvdXIgd29ya2Zsb3c8L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5TZXR0aW5nIHVwIGNvbXBhbnkgZW1haWw8L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5TZXJ2ZXIgaW5zdGFsbGF0aW9uPC9saT5cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuPC9kaXY+YCIsIm1vZHVsZS5leHBvcnRzID0ge1xuXG4gICAgY29uc3RydWN0b3IoIGRhdGEsIG9wdHM9e30gKSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24oIHRoaXMsIHsgc3RvcmU6IHsgfSwgZGF0YSB9LCBvcHRzIClcblxuICAgICAgICBpZiggdGhpcy5zdG9yZUJ5ICkge1xuICAgICAgICAgICAgdGhpcy5zdG9yZUJ5LmZvckVhY2goIGtleSA9PiB0aGlzLnN0b3JlWyBrZXkgXSA9IHsgfSApXG4gICAgICAgICAgICB0aGlzLl9zdG9yZSgpXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH0sXG5cbiAgICBfc3RvcmUoKSB7XG4gICAgICAgIHRoaXMuZGF0YS5mb3JFYWNoKCBkYXR1bSA9PiB0aGlzLnN0b3JlQnkuZm9yRWFjaCggYXR0ciA9PiB0aGlzLl9zdG9yZUF0dHIoIGRhdHVtLCBhdHRyICkgKSApXG4gICAgfSxcblxuICAgIF9zdG9yZUF0dHIoIGRhdHVtLCBhdHRyICkge1xuICAgICAgICB0aGlzLnN0b3JlWyBhdHRyIF1bIGRhdHVtWyBhdHRyIF0gXSA9XG4gICAgICAgICAgICB0aGlzLnN0b3JlWyBhdHRyIF1bIGRhdHVtWyBhdHRyIF0gXVxuICAgICAgICAgICAgICAgID8gQXJyYXkuaXNBcnJheSggdGhpcy5zdG9yZVsgYXR0ciBdWyBkYXR1bVsgYXR0ciBdIF0gKVxuICAgICAgICAgICAgICAgICAgICA/IHRoaXMuc3RvcmVbIGF0dHIgXVsgZGF0dW1bIGF0dHIgXSBdLmNvbmNhdCggZGF0dW0gKVxuICAgICAgICAgICAgICAgICAgICA6WyB0aGlzLnN0b3JlWyBhdHRyIF1bIGRhdHVtWyBhdHRyIF0gXSwgZGF0dW0gXVxuICAgICAgICAgICAgICAgIDogZGF0dW1cbiAgICB9XG5cbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gZXJyID0+IHsgY29uc29sZS5sb2coIGVyci5zdGFjayB8fCBlcnIgKSB9XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHtcblxuICAgIGdldEludFJhbmdlKCBpbnQgKSB7XG4gICAgICAgIHJldHVybiBBcnJheS5mcm9tKCBBcnJheSggaW50ICkua2V5cygpIClcbiAgICB9LFxuXG4gICAgZ2V0UmFuZG9tSW5jbHVzaXZlSW50ZWdlciggbWluLCBtYXggKSB7XG4gICAgICAgIG1pbiA9IE1hdGguY2VpbChtaW4pXG4gICAgICAgIG1heCA9IE1hdGguZmxvb3IobWF4KVxuICAgICAgICByZXR1cm4gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbiArIDEpKSArIG1pblxuICAgIH0sXG5cbiAgICBvbWl0KCBvYmosIGtleXMgKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyggb2JqICkuZmlsdGVyKCBrZXkgPT4gIWtleXMuaW5jbHVkZXMoIGtleSApICkucmVkdWNlKCAoIG1lbW8sIGtleSApID0+IE9iamVjdC5hc3NpZ24oIG1lbW8sIHsgW2tleV06IG9ialtrZXldIH0gKSwgeyB9IClcbiAgICB9LFxuXG4gICAgcGljayggb2JqLCBrZXlzICkge1xuICAgICAgICByZXR1cm4ga2V5cy5yZWR1Y2UoICggbWVtbywga2V5ICkgPT4gT2JqZWN0LmFzc2lnbiggbWVtbywgeyBba2V5XTogb2JqW2tleV0gfSApLCB7IH0gKVxuICAgIH0sXG5cbiAgICBFcnJvcjogcmVxdWlyZSgnLi9NeUVycm9yJyksXG5cbiAgICBQOiAoIGZ1biwgYXJncz1bIF0sIHRoaXNBcmcgKSA9PlxuICAgICAgICBuZXcgUHJvbWlzZSggKCByZXNvbHZlLCByZWplY3QgKSA9PiBSZWZsZWN0LmFwcGx5KCBmdW4sIHRoaXNBcmcgfHwgdGhpcywgYXJncy5jb25jYXQoICggZSwgLi4uY2FsbGJhY2sgKSA9PiBlID8gcmVqZWN0KGUpIDogcmVzb2x2ZShjYWxsYmFjaykgKSApICksXG4gICAgXG4gICAgY29uc3RydWN0b3IoKSB7IHJldHVybiB0aGlzIH1cbn1cbiIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuXG5mdW5jdGlvbiBFdmVudEVtaXR0ZXIoKSB7XG4gIHRoaXMuX2V2ZW50cyA9IHRoaXMuX2V2ZW50cyB8fCB7fTtcbiAgdGhpcy5fbWF4TGlzdGVuZXJzID0gdGhpcy5fbWF4TGlzdGVuZXJzIHx8IHVuZGVmaW5lZDtcbn1cbm1vZHVsZS5leHBvcnRzID0gRXZlbnRFbWl0dGVyO1xuXG4vLyBCYWNrd2FyZHMtY29tcGF0IHdpdGggbm9kZSAwLjEwLnhcbkV2ZW50RW1pdHRlci5FdmVudEVtaXR0ZXIgPSBFdmVudEVtaXR0ZXI7XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUuX2V2ZW50cyA9IHVuZGVmaW5lZDtcbkV2ZW50RW1pdHRlci5wcm90b3R5cGUuX21heExpc3RlbmVycyA9IHVuZGVmaW5lZDtcblxuLy8gQnkgZGVmYXVsdCBFdmVudEVtaXR0ZXJzIHdpbGwgcHJpbnQgYSB3YXJuaW5nIGlmIG1vcmUgdGhhbiAxMCBsaXN0ZW5lcnMgYXJlXG4vLyBhZGRlZCB0byBpdC4gVGhpcyBpcyBhIHVzZWZ1bCBkZWZhdWx0IHdoaWNoIGhlbHBzIGZpbmRpbmcgbWVtb3J5IGxlYWtzLlxuRXZlbnRFbWl0dGVyLmRlZmF1bHRNYXhMaXN0ZW5lcnMgPSAxMDtcblxuLy8gT2J2aW91c2x5IG5vdCBhbGwgRW1pdHRlcnMgc2hvdWxkIGJlIGxpbWl0ZWQgdG8gMTAuIFRoaXMgZnVuY3Rpb24gYWxsb3dzXG4vLyB0aGF0IHRvIGJlIGluY3JlYXNlZC4gU2V0IHRvIHplcm8gZm9yIHVubGltaXRlZC5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUuc2V0TWF4TGlzdGVuZXJzID0gZnVuY3Rpb24obikge1xuICBpZiAoIWlzTnVtYmVyKG4pIHx8IG4gPCAwIHx8IGlzTmFOKG4pKVxuICAgIHRocm93IFR5cGVFcnJvcignbiBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyJyk7XG4gIHRoaXMuX21heExpc3RlbmVycyA9IG47XG4gIHJldHVybiB0aGlzO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5lbWl0ID0gZnVuY3Rpb24odHlwZSkge1xuICB2YXIgZXIsIGhhbmRsZXIsIGxlbiwgYXJncywgaSwgbGlzdGVuZXJzO1xuXG4gIGlmICghdGhpcy5fZXZlbnRzKVxuICAgIHRoaXMuX2V2ZW50cyA9IHt9O1xuXG4gIC8vIElmIHRoZXJlIGlzIG5vICdlcnJvcicgZXZlbnQgbGlzdGVuZXIgdGhlbiB0aHJvdy5cbiAgaWYgKHR5cGUgPT09ICdlcnJvcicpIHtcbiAgICBpZiAoIXRoaXMuX2V2ZW50cy5lcnJvciB8fFxuICAgICAgICAoaXNPYmplY3QodGhpcy5fZXZlbnRzLmVycm9yKSAmJiAhdGhpcy5fZXZlbnRzLmVycm9yLmxlbmd0aCkpIHtcbiAgICAgIGVyID0gYXJndW1lbnRzWzFdO1xuICAgICAgaWYgKGVyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgdGhyb3cgZXI7IC8vIFVuaGFuZGxlZCAnZXJyb3InIGV2ZW50XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBBdCBsZWFzdCBnaXZlIHNvbWUga2luZCBvZiBjb250ZXh0IHRvIHRoZSB1c2VyXG4gICAgICAgIHZhciBlcnIgPSBuZXcgRXJyb3IoJ1VuY2F1Z2h0LCB1bnNwZWNpZmllZCBcImVycm9yXCIgZXZlbnQuICgnICsgZXIgKyAnKScpO1xuICAgICAgICBlcnIuY29udGV4dCA9IGVyO1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgaGFuZGxlciA9IHRoaXMuX2V2ZW50c1t0eXBlXTtcblxuICBpZiAoaXNVbmRlZmluZWQoaGFuZGxlcikpXG4gICAgcmV0dXJuIGZhbHNlO1xuXG4gIGlmIChpc0Z1bmN0aW9uKGhhbmRsZXIpKSB7XG4gICAgc3dpdGNoIChhcmd1bWVudHMubGVuZ3RoKSB7XG4gICAgICAvLyBmYXN0IGNhc2VzXG4gICAgICBjYXNlIDE6XG4gICAgICAgIGhhbmRsZXIuY2FsbCh0aGlzKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDI6XG4gICAgICAgIGhhbmRsZXIuY2FsbCh0aGlzLCBhcmd1bWVudHNbMV0pO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgMzpcbiAgICAgICAgaGFuZGxlci5jYWxsKHRoaXMsIGFyZ3VtZW50c1sxXSwgYXJndW1lbnRzWzJdKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICAvLyBzbG93ZXJcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpO1xuICAgICAgICBoYW5kbGVyLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChpc09iamVjdChoYW5kbGVyKSkge1xuICAgIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpO1xuICAgIGxpc3RlbmVycyA9IGhhbmRsZXIuc2xpY2UoKTtcbiAgICBsZW4gPSBsaXN0ZW5lcnMubGVuZ3RoO1xuICAgIGZvciAoaSA9IDA7IGkgPCBsZW47IGkrKylcbiAgICAgIGxpc3RlbmVyc1tpXS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgfVxuXG4gIHJldHVybiB0cnVlO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5hZGRMaXN0ZW5lciA9IGZ1bmN0aW9uKHR5cGUsIGxpc3RlbmVyKSB7XG4gIHZhciBtO1xuXG4gIGlmICghaXNGdW5jdGlvbihsaXN0ZW5lcikpXG4gICAgdGhyb3cgVHlwZUVycm9yKCdsaXN0ZW5lciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcblxuICBpZiAoIXRoaXMuX2V2ZW50cylcbiAgICB0aGlzLl9ldmVudHMgPSB7fTtcblxuICAvLyBUbyBhdm9pZCByZWN1cnNpb24gaW4gdGhlIGNhc2UgdGhhdCB0eXBlID09PSBcIm5ld0xpc3RlbmVyXCIhIEJlZm9yZVxuICAvLyBhZGRpbmcgaXQgdG8gdGhlIGxpc3RlbmVycywgZmlyc3QgZW1pdCBcIm5ld0xpc3RlbmVyXCIuXG4gIGlmICh0aGlzLl9ldmVudHMubmV3TGlzdGVuZXIpXG4gICAgdGhpcy5lbWl0KCduZXdMaXN0ZW5lcicsIHR5cGUsXG4gICAgICAgICAgICAgIGlzRnVuY3Rpb24obGlzdGVuZXIubGlzdGVuZXIpID9cbiAgICAgICAgICAgICAgbGlzdGVuZXIubGlzdGVuZXIgOiBsaXN0ZW5lcik7XG5cbiAgaWYgKCF0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgLy8gT3B0aW1pemUgdGhlIGNhc2Ugb2Ygb25lIGxpc3RlbmVyLiBEb24ndCBuZWVkIHRoZSBleHRyYSBhcnJheSBvYmplY3QuXG4gICAgdGhpcy5fZXZlbnRzW3R5cGVdID0gbGlzdGVuZXI7XG4gIGVsc2UgaWYgKGlzT2JqZWN0KHRoaXMuX2V2ZW50c1t0eXBlXSkpXG4gICAgLy8gSWYgd2UndmUgYWxyZWFkeSBnb3QgYW4gYXJyYXksIGp1c3QgYXBwZW5kLlxuICAgIHRoaXMuX2V2ZW50c1t0eXBlXS5wdXNoKGxpc3RlbmVyKTtcbiAgZWxzZVxuICAgIC8vIEFkZGluZyB0aGUgc2Vjb25kIGVsZW1lbnQsIG5lZWQgdG8gY2hhbmdlIHRvIGFycmF5LlxuICAgIHRoaXMuX2V2ZW50c1t0eXBlXSA9IFt0aGlzLl9ldmVudHNbdHlwZV0sIGxpc3RlbmVyXTtcblxuICAvLyBDaGVjayBmb3IgbGlzdGVuZXIgbGVha1xuICBpZiAoaXNPYmplY3QodGhpcy5fZXZlbnRzW3R5cGVdKSAmJiAhdGhpcy5fZXZlbnRzW3R5cGVdLndhcm5lZCkge1xuICAgIGlmICghaXNVbmRlZmluZWQodGhpcy5fbWF4TGlzdGVuZXJzKSkge1xuICAgICAgbSA9IHRoaXMuX21heExpc3RlbmVycztcbiAgICB9IGVsc2Uge1xuICAgICAgbSA9IEV2ZW50RW1pdHRlci5kZWZhdWx0TWF4TGlzdGVuZXJzO1xuICAgIH1cblxuICAgIGlmIChtICYmIG0gPiAwICYmIHRoaXMuX2V2ZW50c1t0eXBlXS5sZW5ndGggPiBtKSB7XG4gICAgICB0aGlzLl9ldmVudHNbdHlwZV0ud2FybmVkID0gdHJ1ZTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJyhub2RlKSB3YXJuaW5nOiBwb3NzaWJsZSBFdmVudEVtaXR0ZXIgbWVtb3J5ICcgK1xuICAgICAgICAgICAgICAgICAgICAnbGVhayBkZXRlY3RlZC4gJWQgbGlzdGVuZXJzIGFkZGVkLiAnICtcbiAgICAgICAgICAgICAgICAgICAgJ1VzZSBlbWl0dGVyLnNldE1heExpc3RlbmVycygpIHRvIGluY3JlYXNlIGxpbWl0LicsXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2V2ZW50c1t0eXBlXS5sZW5ndGgpO1xuICAgICAgaWYgKHR5cGVvZiBjb25zb2xlLnRyYWNlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIC8vIG5vdCBzdXBwb3J0ZWQgaW4gSUUgMTBcbiAgICAgICAgY29uc29sZS50cmFjZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0aGlzO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5vbiA9IEV2ZW50RW1pdHRlci5wcm90b3R5cGUuYWRkTGlzdGVuZXI7XG5cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUub25jZSA9IGZ1bmN0aW9uKHR5cGUsIGxpc3RlbmVyKSB7XG4gIGlmICghaXNGdW5jdGlvbihsaXN0ZW5lcikpXG4gICAgdGhyb3cgVHlwZUVycm9yKCdsaXN0ZW5lciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcblxuICB2YXIgZmlyZWQgPSBmYWxzZTtcblxuICBmdW5jdGlvbiBnKCkge1xuICAgIHRoaXMucmVtb3ZlTGlzdGVuZXIodHlwZSwgZyk7XG5cbiAgICBpZiAoIWZpcmVkKSB7XG4gICAgICBmaXJlZCA9IHRydWU7XG4gICAgICBsaXN0ZW5lci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH1cbiAgfVxuXG4gIGcubGlzdGVuZXIgPSBsaXN0ZW5lcjtcbiAgdGhpcy5vbih0eXBlLCBnKTtcblxuICByZXR1cm4gdGhpcztcbn07XG5cbi8vIGVtaXRzIGEgJ3JlbW92ZUxpc3RlbmVyJyBldmVudCBpZmYgdGhlIGxpc3RlbmVyIHdhcyByZW1vdmVkXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyID0gZnVuY3Rpb24odHlwZSwgbGlzdGVuZXIpIHtcbiAgdmFyIGxpc3QsIHBvc2l0aW9uLCBsZW5ndGgsIGk7XG5cbiAgaWYgKCFpc0Z1bmN0aW9uKGxpc3RlbmVyKSlcbiAgICB0aHJvdyBUeXBlRXJyb3IoJ2xpc3RlbmVyIG11c3QgYmUgYSBmdW5jdGlvbicpO1xuXG4gIGlmICghdGhpcy5fZXZlbnRzIHx8ICF0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgcmV0dXJuIHRoaXM7XG5cbiAgbGlzdCA9IHRoaXMuX2V2ZW50c1t0eXBlXTtcbiAgbGVuZ3RoID0gbGlzdC5sZW5ndGg7XG4gIHBvc2l0aW9uID0gLTE7XG5cbiAgaWYgKGxpc3QgPT09IGxpc3RlbmVyIHx8XG4gICAgICAoaXNGdW5jdGlvbihsaXN0Lmxpc3RlbmVyKSAmJiBsaXN0Lmxpc3RlbmVyID09PSBsaXN0ZW5lcikpIHtcbiAgICBkZWxldGUgdGhpcy5fZXZlbnRzW3R5cGVdO1xuICAgIGlmICh0aGlzLl9ldmVudHMucmVtb3ZlTGlzdGVuZXIpXG4gICAgICB0aGlzLmVtaXQoJ3JlbW92ZUxpc3RlbmVyJywgdHlwZSwgbGlzdGVuZXIpO1xuXG4gIH0gZWxzZSBpZiAoaXNPYmplY3QobGlzdCkpIHtcbiAgICBmb3IgKGkgPSBsZW5ndGg7IGktLSA+IDA7KSB7XG4gICAgICBpZiAobGlzdFtpXSA9PT0gbGlzdGVuZXIgfHxcbiAgICAgICAgICAobGlzdFtpXS5saXN0ZW5lciAmJiBsaXN0W2ldLmxpc3RlbmVyID09PSBsaXN0ZW5lcikpIHtcbiAgICAgICAgcG9zaXRpb24gPSBpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAocG9zaXRpb24gPCAwKVxuICAgICAgcmV0dXJuIHRoaXM7XG5cbiAgICBpZiAobGlzdC5sZW5ndGggPT09IDEpIHtcbiAgICAgIGxpc3QubGVuZ3RoID0gMDtcbiAgICAgIGRlbGV0ZSB0aGlzLl9ldmVudHNbdHlwZV07XG4gICAgfSBlbHNlIHtcbiAgICAgIGxpc3Quc3BsaWNlKHBvc2l0aW9uLCAxKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5fZXZlbnRzLnJlbW92ZUxpc3RlbmVyKVxuICAgICAgdGhpcy5lbWl0KCdyZW1vdmVMaXN0ZW5lcicsIHR5cGUsIGxpc3RlbmVyKTtcbiAgfVxuXG4gIHJldHVybiB0aGlzO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5yZW1vdmVBbGxMaXN0ZW5lcnMgPSBmdW5jdGlvbih0eXBlKSB7XG4gIHZhciBrZXksIGxpc3RlbmVycztcblxuICBpZiAoIXRoaXMuX2V2ZW50cylcbiAgICByZXR1cm4gdGhpcztcblxuICAvLyBub3QgbGlzdGVuaW5nIGZvciByZW1vdmVMaXN0ZW5lciwgbm8gbmVlZCB0byBlbWl0XG4gIGlmICghdGhpcy5fZXZlbnRzLnJlbW92ZUxpc3RlbmVyKSB7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApXG4gICAgICB0aGlzLl9ldmVudHMgPSB7fTtcbiAgICBlbHNlIGlmICh0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgICBkZWxldGUgdGhpcy5fZXZlbnRzW3R5cGVdO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLy8gZW1pdCByZW1vdmVMaXN0ZW5lciBmb3IgYWxsIGxpc3RlbmVycyBvbiBhbGwgZXZlbnRzXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgZm9yIChrZXkgaW4gdGhpcy5fZXZlbnRzKSB7XG4gICAgICBpZiAoa2V5ID09PSAncmVtb3ZlTGlzdGVuZXInKSBjb250aW51ZTtcbiAgICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKGtleSk7XG4gICAgfVxuICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCdyZW1vdmVMaXN0ZW5lcicpO1xuICAgIHRoaXMuX2V2ZW50cyA9IHt9O1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgbGlzdGVuZXJzID0gdGhpcy5fZXZlbnRzW3R5cGVdO1xuXG4gIGlmIChpc0Z1bmN0aW9uKGxpc3RlbmVycykpIHtcbiAgICB0aGlzLnJlbW92ZUxpc3RlbmVyKHR5cGUsIGxpc3RlbmVycyk7XG4gIH0gZWxzZSBpZiAobGlzdGVuZXJzKSB7XG4gICAgLy8gTElGTyBvcmRlclxuICAgIHdoaWxlIChsaXN0ZW5lcnMubGVuZ3RoKVxuICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcnNbbGlzdGVuZXJzLmxlbmd0aCAtIDFdKTtcbiAgfVxuICBkZWxldGUgdGhpcy5fZXZlbnRzW3R5cGVdO1xuXG4gIHJldHVybiB0aGlzO1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5saXN0ZW5lcnMgPSBmdW5jdGlvbih0eXBlKSB7XG4gIHZhciByZXQ7XG4gIGlmICghdGhpcy5fZXZlbnRzIHx8ICF0aGlzLl9ldmVudHNbdHlwZV0pXG4gICAgcmV0ID0gW107XG4gIGVsc2UgaWYgKGlzRnVuY3Rpb24odGhpcy5fZXZlbnRzW3R5cGVdKSlcbiAgICByZXQgPSBbdGhpcy5fZXZlbnRzW3R5cGVdXTtcbiAgZWxzZVxuICAgIHJldCA9IHRoaXMuX2V2ZW50c1t0eXBlXS5zbGljZSgpO1xuICByZXR1cm4gcmV0O1xufTtcblxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5saXN0ZW5lckNvdW50ID0gZnVuY3Rpb24odHlwZSkge1xuICBpZiAodGhpcy5fZXZlbnRzKSB7XG4gICAgdmFyIGV2bGlzdGVuZXIgPSB0aGlzLl9ldmVudHNbdHlwZV07XG5cbiAgICBpZiAoaXNGdW5jdGlvbihldmxpc3RlbmVyKSlcbiAgICAgIHJldHVybiAxO1xuICAgIGVsc2UgaWYgKGV2bGlzdGVuZXIpXG4gICAgICByZXR1cm4gZXZsaXN0ZW5lci5sZW5ndGg7XG4gIH1cbiAgcmV0dXJuIDA7XG59O1xuXG5FdmVudEVtaXR0ZXIubGlzdGVuZXJDb3VudCA9IGZ1bmN0aW9uKGVtaXR0ZXIsIHR5cGUpIHtcbiAgcmV0dXJuIGVtaXR0ZXIubGlzdGVuZXJDb3VudCh0eXBlKTtcbn07XG5cbmZ1bmN0aW9uIGlzRnVuY3Rpb24oYXJnKSB7XG4gIHJldHVybiB0eXBlb2YgYXJnID09PSAnZnVuY3Rpb24nO1xufVxuXG5mdW5jdGlvbiBpc051bWJlcihhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdudW1iZXInO1xufVxuXG5mdW5jdGlvbiBpc09iamVjdChhcmcpIHtcbiAgcmV0dXJuIHR5cGVvZiBhcmcgPT09ICdvYmplY3QnICYmIGFyZyAhPT0gbnVsbDtcbn1cblxuZnVuY3Rpb24gaXNVbmRlZmluZWQoYXJnKSB7XG4gIHJldHVybiBhcmcgPT09IHZvaWQgMDtcbn1cbiIsIi8qXG4gKiBzbW9vdGhzY3JvbGwgcG9seWZpbGwgLSB2MC4zLjVcbiAqIGh0dHBzOi8vaWFtZHVzdGFuLmdpdGh1Yi5pby9zbW9vdGhzY3JvbGxcbiAqIDIwMTYgKGMpIER1c3RhbiBLYXN0ZW4sIEplcmVtaWFzIE1lbmljaGVsbGkgLSBNSVQgTGljZW5zZVxuICovXG5cbihmdW5jdGlvbih3LCBkLCB1bmRlZmluZWQpIHtcbiAgJ3VzZSBzdHJpY3QnO1xuXG4gIC8qXG4gICAqIGFsaWFzZXNcbiAgICogdzogd2luZG93IGdsb2JhbCBvYmplY3RcbiAgICogZDogZG9jdW1lbnRcbiAgICogdW5kZWZpbmVkOiB1bmRlZmluZWRcbiAgICovXG5cbiAgLy8gcG9seWZpbGxcbiAgZnVuY3Rpb24gcG9seWZpbGwoKSB7XG4gICAgLy8gcmV0dXJuIHdoZW4gc2Nyb2xsQmVoYXZpb3IgaW50ZXJmYWNlIGlzIHN1cHBvcnRlZFxuICAgIGlmICgnc2Nyb2xsQmVoYXZpb3InIGluIGQuZG9jdW1lbnRFbGVtZW50LnN0eWxlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLypcbiAgICAgKiBnbG9iYWxzXG4gICAgICovXG4gICAgdmFyIEVsZW1lbnQgPSB3LkhUTUxFbGVtZW50IHx8IHcuRWxlbWVudDtcbiAgICB2YXIgU0NST0xMX1RJTUUgPSA0Njg7XG5cbiAgICAvKlxuICAgICAqIG9iamVjdCBnYXRoZXJpbmcgb3JpZ2luYWwgc2Nyb2xsIG1ldGhvZHNcbiAgICAgKi9cbiAgICB2YXIgb3JpZ2luYWwgPSB7XG4gICAgICBzY3JvbGw6IHcuc2Nyb2xsIHx8IHcuc2Nyb2xsVG8sXG4gICAgICBzY3JvbGxCeTogdy5zY3JvbGxCeSxcbiAgICAgIGVsU2Nyb2xsOiBFbGVtZW50LnByb3RvdHlwZS5zY3JvbGwgfHwgc2Nyb2xsRWxlbWVudCxcbiAgICAgIHNjcm9sbEludG9WaWV3OiBFbGVtZW50LnByb3RvdHlwZS5zY3JvbGxJbnRvVmlld1xuICAgIH07XG5cbiAgICAvKlxuICAgICAqIGRlZmluZSB0aW1pbmcgbWV0aG9kXG4gICAgICovXG4gICAgdmFyIG5vdyA9IHcucGVyZm9ybWFuY2UgJiYgdy5wZXJmb3JtYW5jZS5ub3dcbiAgICAgID8gdy5wZXJmb3JtYW5jZS5ub3cuYmluZCh3LnBlcmZvcm1hbmNlKSA6IERhdGUubm93O1xuXG4gICAgLyoqXG4gICAgICogY2hhbmdlcyBzY3JvbGwgcG9zaXRpb24gaW5zaWRlIGFuIGVsZW1lbnRcbiAgICAgKiBAbWV0aG9kIHNjcm9sbEVsZW1lbnRcbiAgICAgKiBAcGFyYW0ge051bWJlcn0geFxuICAgICAqIEBwYXJhbSB7TnVtYmVyfSB5XG4gICAgICovXG4gICAgZnVuY3Rpb24gc2Nyb2xsRWxlbWVudCh4LCB5KSB7XG4gICAgICB0aGlzLnNjcm9sbExlZnQgPSB4O1xuICAgICAgdGhpcy5zY3JvbGxUb3AgPSB5O1xuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHJldHVybnMgcmVzdWx0IG9mIGFwcGx5aW5nIGVhc2UgbWF0aCBmdW5jdGlvbiB0byBhIG51bWJlclxuICAgICAqIEBtZXRob2QgZWFzZVxuICAgICAqIEBwYXJhbSB7TnVtYmVyfSBrXG4gICAgICogQHJldHVybnMge051bWJlcn1cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBlYXNlKGspIHtcbiAgICAgIHJldHVybiAwLjUgKiAoMSAtIE1hdGguY29zKE1hdGguUEkgKiBrKSk7XG4gICAgfVxuXG4gICAgLyoqXG4gICAgICogaW5kaWNhdGVzIGlmIGEgc21vb3RoIGJlaGF2aW9yIHNob3VsZCBiZSBhcHBsaWVkXG4gICAgICogQG1ldGhvZCBzaG91bGRCYWlsT3V0XG4gICAgICogQHBhcmFtIHtOdW1iZXJ8T2JqZWN0fSB4XG4gICAgICogQHJldHVybnMge0Jvb2xlYW59XG4gICAgICovXG4gICAgZnVuY3Rpb24gc2hvdWxkQmFpbE91dCh4KSB7XG4gICAgICBpZiAodHlwZW9mIHggIT09ICdvYmplY3QnXG4gICAgICAgICAgICB8fCB4ID09PSBudWxsXG4gICAgICAgICAgICB8fCB4LmJlaGF2aW9yID09PSB1bmRlZmluZWRcbiAgICAgICAgICAgIHx8IHguYmVoYXZpb3IgPT09ICdhdXRvJ1xuICAgICAgICAgICAgfHwgeC5iZWhhdmlvciA9PT0gJ2luc3RhbnQnKSB7XG4gICAgICAgIC8vIGZpcnN0IGFyZyBub3QgYW4gb2JqZWN0L251bGxcbiAgICAgICAgLy8gb3IgYmVoYXZpb3IgaXMgYXV0bywgaW5zdGFudCBvciB1bmRlZmluZWRcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG5cbiAgICAgIGlmICh0eXBlb2YgeCA9PT0gJ29iamVjdCdcbiAgICAgICAgICAgICYmIHguYmVoYXZpb3IgPT09ICdzbW9vdGgnKSB7XG4gICAgICAgIC8vIGZpcnN0IGFyZ3VtZW50IGlzIGFuIG9iamVjdCBhbmQgYmVoYXZpb3IgaXMgc21vb3RoXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cblxuICAgICAgLy8gdGhyb3cgZXJyb3Igd2hlbiBiZWhhdmlvciBpcyBub3Qgc3VwcG9ydGVkXG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdiZWhhdmlvciBub3QgdmFsaWQnKTtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBmaW5kcyBzY3JvbGxhYmxlIHBhcmVudCBvZiBhbiBlbGVtZW50XG4gICAgICogQG1ldGhvZCBmaW5kU2Nyb2xsYWJsZVBhcmVudFxuICAgICAqIEBwYXJhbSB7Tm9kZX0gZWxcbiAgICAgKiBAcmV0dXJucyB7Tm9kZX0gZWxcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBmaW5kU2Nyb2xsYWJsZVBhcmVudChlbCkge1xuICAgICAgdmFyIGlzQm9keTtcbiAgICAgIHZhciBoYXNTY3JvbGxhYmxlU3BhY2U7XG4gICAgICB2YXIgaGFzVmlzaWJsZU92ZXJmbG93O1xuXG4gICAgICBkbyB7XG4gICAgICAgIGVsID0gZWwucGFyZW50Tm9kZTtcblxuICAgICAgICAvLyBzZXQgY29uZGl0aW9uIHZhcmlhYmxlc1xuICAgICAgICBpc0JvZHkgPSBlbCA9PT0gZC5ib2R5O1xuICAgICAgICBoYXNTY3JvbGxhYmxlU3BhY2UgPVxuICAgICAgICAgIGVsLmNsaWVudEhlaWdodCA8IGVsLnNjcm9sbEhlaWdodCB8fFxuICAgICAgICAgIGVsLmNsaWVudFdpZHRoIDwgZWwuc2Nyb2xsV2lkdGg7XG4gICAgICAgIGhhc1Zpc2libGVPdmVyZmxvdyA9XG4gICAgICAgICAgdy5nZXRDb21wdXRlZFN0eWxlKGVsLCBudWxsKS5vdmVyZmxvdyA9PT0gJ3Zpc2libGUnO1xuICAgICAgfSB3aGlsZSAoIWlzQm9keSAmJiAhKGhhc1Njcm9sbGFibGVTcGFjZSAmJiAhaGFzVmlzaWJsZU92ZXJmbG93KSk7XG5cbiAgICAgIGlzQm9keSA9IGhhc1Njcm9sbGFibGVTcGFjZSA9IGhhc1Zpc2libGVPdmVyZmxvdyA9IG51bGw7XG5cbiAgICAgIHJldHVybiBlbDtcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBzZWxmIGludm9rZWQgZnVuY3Rpb24gdGhhdCwgZ2l2ZW4gYSBjb250ZXh0LCBzdGVwcyB0aHJvdWdoIHNjcm9sbGluZ1xuICAgICAqIEBtZXRob2Qgc3RlcFxuICAgICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAgICovXG4gICAgZnVuY3Rpb24gc3RlcChjb250ZXh0KSB7XG4gICAgICB2YXIgdGltZSA9IG5vdygpO1xuICAgICAgdmFyIHZhbHVlO1xuICAgICAgdmFyIGN1cnJlbnRYO1xuICAgICAgdmFyIGN1cnJlbnRZO1xuICAgICAgdmFyIGVsYXBzZWQgPSAodGltZSAtIGNvbnRleHQuc3RhcnRUaW1lKSAvIFNDUk9MTF9USU1FO1xuXG4gICAgICAvLyBhdm9pZCBlbGFwc2VkIHRpbWVzIGhpZ2hlciB0aGFuIG9uZVxuICAgICAgZWxhcHNlZCA9IGVsYXBzZWQgPiAxID8gMSA6IGVsYXBzZWQ7XG5cbiAgICAgIC8vIGFwcGx5IGVhc2luZyB0byBlbGFwc2VkIHRpbWVcbiAgICAgIHZhbHVlID0gZWFzZShlbGFwc2VkKTtcblxuICAgICAgY3VycmVudFggPSBjb250ZXh0LnN0YXJ0WCArIChjb250ZXh0LnggLSBjb250ZXh0LnN0YXJ0WCkgKiB2YWx1ZTtcbiAgICAgIGN1cnJlbnRZID0gY29udGV4dC5zdGFydFkgKyAoY29udGV4dC55IC0gY29udGV4dC5zdGFydFkpICogdmFsdWU7XG5cbiAgICAgIGNvbnRleHQubWV0aG9kLmNhbGwoY29udGV4dC5zY3JvbGxhYmxlLCBjdXJyZW50WCwgY3VycmVudFkpO1xuXG4gICAgICAvLyBzY3JvbGwgbW9yZSBpZiB3ZSBoYXZlIG5vdCByZWFjaGVkIG91ciBkZXN0aW5hdGlvblxuICAgICAgaWYgKGN1cnJlbnRYICE9PSBjb250ZXh0LnggfHwgY3VycmVudFkgIT09IGNvbnRleHQueSkge1xuICAgICAgICB3LnJlcXVlc3RBbmltYXRpb25GcmFtZShzdGVwLmJpbmQodywgY29udGV4dCkpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8qKlxuICAgICAqIHNjcm9sbHMgd2luZG93IHdpdGggYSBzbW9vdGggYmVoYXZpb3JcbiAgICAgKiBAbWV0aG9kIHNtb290aFNjcm9sbFxuICAgICAqIEBwYXJhbSB7T2JqZWN0fE5vZGV9IGVsXG4gICAgICogQHBhcmFtIHtOdW1iZXJ9IHhcbiAgICAgKiBAcGFyYW0ge051bWJlcn0geVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIHNtb290aFNjcm9sbChlbCwgeCwgeSkge1xuICAgICAgdmFyIHNjcm9sbGFibGU7XG4gICAgICB2YXIgc3RhcnRYO1xuICAgICAgdmFyIHN0YXJ0WTtcbiAgICAgIHZhciBtZXRob2Q7XG4gICAgICB2YXIgc3RhcnRUaW1lID0gbm93KCk7XG5cbiAgICAgIC8vIGRlZmluZSBzY3JvbGwgY29udGV4dFxuICAgICAgaWYgKGVsID09PSBkLmJvZHkpIHtcbiAgICAgICAgc2Nyb2xsYWJsZSA9IHc7XG4gICAgICAgIHN0YXJ0WCA9IHcuc2Nyb2xsWCB8fCB3LnBhZ2VYT2Zmc2V0O1xuICAgICAgICBzdGFydFkgPSB3LnNjcm9sbFkgfHwgdy5wYWdlWU9mZnNldDtcbiAgICAgICAgbWV0aG9kID0gb3JpZ2luYWwuc2Nyb2xsO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2Nyb2xsYWJsZSA9IGVsO1xuICAgICAgICBzdGFydFggPSBlbC5zY3JvbGxMZWZ0O1xuICAgICAgICBzdGFydFkgPSBlbC5zY3JvbGxUb3A7XG4gICAgICAgIG1ldGhvZCA9IHNjcm9sbEVsZW1lbnQ7XG4gICAgICB9XG5cbiAgICAgIC8vIHNjcm9sbCBsb29waW5nIG92ZXIgYSBmcmFtZVxuICAgICAgc3RlcCh7XG4gICAgICAgIHNjcm9sbGFibGU6IHNjcm9sbGFibGUsXG4gICAgICAgIG1ldGhvZDogbWV0aG9kLFxuICAgICAgICBzdGFydFRpbWU6IHN0YXJ0VGltZSxcbiAgICAgICAgc3RhcnRYOiBzdGFydFgsXG4gICAgICAgIHN0YXJ0WTogc3RhcnRZLFxuICAgICAgICB4OiB4LFxuICAgICAgICB5OiB5XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvKlxuICAgICAqIE9SSUdJTkFMIE1FVEhPRFMgT1ZFUlJJREVTXG4gICAgICovXG5cbiAgICAvLyB3LnNjcm9sbCBhbmQgdy5zY3JvbGxUb1xuICAgIHcuc2Nyb2xsID0gdy5zY3JvbGxUbyA9IGZ1bmN0aW9uKCkge1xuICAgICAgLy8gYXZvaWQgc21vb3RoIGJlaGF2aW9yIGlmIG5vdCByZXF1aXJlZFxuICAgICAgaWYgKHNob3VsZEJhaWxPdXQoYXJndW1lbnRzWzBdKSkge1xuICAgICAgICBvcmlnaW5hbC5zY3JvbGwuY2FsbChcbiAgICAgICAgICB3LFxuICAgICAgICAgIGFyZ3VtZW50c1swXS5sZWZ0IHx8IGFyZ3VtZW50c1swXSxcbiAgICAgICAgICBhcmd1bWVudHNbMF0udG9wIHx8IGFyZ3VtZW50c1sxXVxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIExFVCBUSEUgU01PT1RITkVTUyBCRUdJTiFcbiAgICAgIHNtb290aFNjcm9sbC5jYWxsKFxuICAgICAgICB3LFxuICAgICAgICBkLmJvZHksXG4gICAgICAgIH5+YXJndW1lbnRzWzBdLmxlZnQsXG4gICAgICAgIH5+YXJndW1lbnRzWzBdLnRvcFxuICAgICAgKTtcbiAgICB9O1xuXG4gICAgLy8gdy5zY3JvbGxCeVxuICAgIHcuc2Nyb2xsQnkgPSBmdW5jdGlvbigpIHtcbiAgICAgIC8vIGF2b2lkIHNtb290aCBiZWhhdmlvciBpZiBub3QgcmVxdWlyZWRcbiAgICAgIGlmIChzaG91bGRCYWlsT3V0KGFyZ3VtZW50c1swXSkpIHtcbiAgICAgICAgb3JpZ2luYWwuc2Nyb2xsQnkuY2FsbChcbiAgICAgICAgICB3LFxuICAgICAgICAgIGFyZ3VtZW50c1swXS5sZWZ0IHx8IGFyZ3VtZW50c1swXSxcbiAgICAgICAgICBhcmd1bWVudHNbMF0udG9wIHx8IGFyZ3VtZW50c1sxXVxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIExFVCBUSEUgU01PT1RITkVTUyBCRUdJTiFcbiAgICAgIHNtb290aFNjcm9sbC5jYWxsKFxuICAgICAgICB3LFxuICAgICAgICBkLmJvZHksXG4gICAgICAgIH5+YXJndW1lbnRzWzBdLmxlZnQgKyAody5zY3JvbGxYIHx8IHcucGFnZVhPZmZzZXQpLFxuICAgICAgICB+fmFyZ3VtZW50c1swXS50b3AgKyAody5zY3JvbGxZIHx8IHcucGFnZVlPZmZzZXQpXG4gICAgICApO1xuICAgIH07XG5cbiAgICAvLyBFbGVtZW50LnByb3RvdHlwZS5zY3JvbGwgYW5kIEVsZW1lbnQucHJvdG90eXBlLnNjcm9sbFRvXG4gICAgRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsID0gRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsVG8gPSBmdW5jdGlvbigpIHtcbiAgICAgIC8vIGF2b2lkIHNtb290aCBiZWhhdmlvciBpZiBub3QgcmVxdWlyZWRcbiAgICAgIGlmIChzaG91bGRCYWlsT3V0KGFyZ3VtZW50c1swXSkpIHtcbiAgICAgICAgb3JpZ2luYWwuZWxTY3JvbGwuY2FsbChcbiAgICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgICBhcmd1bWVudHNbMF0ubGVmdCB8fCBhcmd1bWVudHNbMF0sXG4gICAgICAgICAgICBhcmd1bWVudHNbMF0udG9wIHx8IGFyZ3VtZW50c1sxXVxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIExFVCBUSEUgU01PT1RITkVTUyBCRUdJTiFcbiAgICAgIHNtb290aFNjcm9sbC5jYWxsKFxuICAgICAgICAgIHRoaXMsXG4gICAgICAgICAgdGhpcyxcbiAgICAgICAgICBhcmd1bWVudHNbMF0ubGVmdCxcbiAgICAgICAgICBhcmd1bWVudHNbMF0udG9wXG4gICAgICApO1xuICAgIH07XG5cbiAgICAvLyBFbGVtZW50LnByb3RvdHlwZS5zY3JvbGxCeVxuICAgIEVsZW1lbnQucHJvdG90eXBlLnNjcm9sbEJ5ID0gZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgYXJnMCA9IGFyZ3VtZW50c1swXTtcblxuICAgICAgaWYgKHR5cGVvZiBhcmcwID09PSAnb2JqZWN0Jykge1xuICAgICAgICB0aGlzLnNjcm9sbCh7XG4gICAgICAgICAgbGVmdDogYXJnMC5sZWZ0ICsgdGhpcy5zY3JvbGxMZWZ0LFxuICAgICAgICAgIHRvcDogYXJnMC50b3AgKyB0aGlzLnNjcm9sbFRvcCxcbiAgICAgICAgICBiZWhhdmlvcjogYXJnMC5iZWhhdmlvclxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuc2Nyb2xsKFxuICAgICAgICAgIHRoaXMuc2Nyb2xsTGVmdCArIGFyZzAsXG4gICAgICAgICAgdGhpcy5zY3JvbGxUb3AgKyBhcmd1bWVudHNbMV1cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgLy8gRWxlbWVudC5wcm90b3R5cGUuc2Nyb2xsSW50b1ZpZXdcbiAgICBFbGVtZW50LnByb3RvdHlwZS5zY3JvbGxJbnRvVmlldyA9IGZ1bmN0aW9uKCkge1xuICAgICAgLy8gYXZvaWQgc21vb3RoIGJlaGF2aW9yIGlmIG5vdCByZXF1aXJlZFxuICAgICAgaWYgKHNob3VsZEJhaWxPdXQoYXJndW1lbnRzWzBdKSkge1xuICAgICAgICBvcmlnaW5hbC5zY3JvbGxJbnRvVmlldy5jYWxsKHRoaXMsIGFyZ3VtZW50c1swXSB8fCB0cnVlKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBMRVQgVEhFIFNNT09USE5FU1MgQkVHSU4hXG4gICAgICB2YXIgc2Nyb2xsYWJsZVBhcmVudCA9IGZpbmRTY3JvbGxhYmxlUGFyZW50KHRoaXMpO1xuICAgICAgdmFyIHBhcmVudFJlY3RzID0gc2Nyb2xsYWJsZVBhcmVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIHZhciBjbGllbnRSZWN0cyA9IHRoaXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cbiAgICAgIGlmIChzY3JvbGxhYmxlUGFyZW50ICE9PSBkLmJvZHkpIHtcbiAgICAgICAgLy8gcmV2ZWFsIGVsZW1lbnQgaW5zaWRlIHBhcmVudFxuICAgICAgICBzbW9vdGhTY3JvbGwuY2FsbChcbiAgICAgICAgICB0aGlzLFxuICAgICAgICAgIHNjcm9sbGFibGVQYXJlbnQsXG4gICAgICAgICAgc2Nyb2xsYWJsZVBhcmVudC5zY3JvbGxMZWZ0ICsgY2xpZW50UmVjdHMubGVmdCAtIHBhcmVudFJlY3RzLmxlZnQsXG4gICAgICAgICAgc2Nyb2xsYWJsZVBhcmVudC5zY3JvbGxUb3AgKyBjbGllbnRSZWN0cy50b3AgLSBwYXJlbnRSZWN0cy50b3BcbiAgICAgICAgKTtcbiAgICAgICAgLy8gcmV2ZWFsIHBhcmVudCBpbiB2aWV3cG9ydFxuICAgICAgICB3LnNjcm9sbEJ5KHtcbiAgICAgICAgICBsZWZ0OiBwYXJlbnRSZWN0cy5sZWZ0LFxuICAgICAgICAgIHRvcDogcGFyZW50UmVjdHMudG9wLFxuICAgICAgICAgIGJlaGF2aW9yOiAnc21vb3RoJ1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIHJldmVhbCBlbGVtZW50IGluIHZpZXdwb3J0XG4gICAgICAgIHcuc2Nyb2xsQnkoe1xuICAgICAgICAgIGxlZnQ6IGNsaWVudFJlY3RzLmxlZnQsXG4gICAgICAgICAgdG9wOiBjbGllbnRSZWN0cy50b3AsXG4gICAgICAgICAgYmVoYXZpb3I6ICdzbW9vdGgnXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH07XG4gIH1cblxuICBpZiAodHlwZW9mIGV4cG9ydHMgPT09ICdvYmplY3QnKSB7XG4gICAgLy8gY29tbW9uanNcbiAgICBtb2R1bGUuZXhwb3J0cyA9IHsgcG9seWZpbGw6IHBvbHlmaWxsIH07XG4gIH0gZWxzZSB7XG4gICAgLy8gZ2xvYmFsXG4gICAgcG9seWZpbGwoKTtcbiAgfVxufSkod2luZG93LCBkb2N1bWVudCk7XG4iLCJtb2R1bGUuZXhwb3J0cyA9ICgpID0+IGA8ZGl2PjwvZGl2PmBcbiIsIm1vZHVsZS5leHBvcnRzID0gKCkgPT4gXG5gPGRpdiBjbGFzcz1cImhpZGRlblwiPlxuICAgIDxkaXYgZGF0YS1qcz1cImljb25cIj48L2Rpdj5cbiAgICA8ZGl2PlxuICAgICAgICA8ZGl2IGRhdGEtanM9XCJ0aXRsZVwiPjwvZGl2PlxuICAgICAgICA8ZGl2IGRhdGEtanM9XCJtZXNzYWdlXCI+PC9kaXY+XG4gICAgPC9kaXY+XG48L2Rpdj5gIiwibW9kdWxlLmV4cG9ydHMgPSAocD17fSkgPT4gYDxzdmcgdmVyc2lvbj1cIjEuMVwiIGRhdGEtanM9XCIke3AubmFtZSB8fCAnY2hlY2ttYXJrJ31cIiBjbGFzcz1cImNoZWNrbWFya1wiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB4bWxuczp4bGluaz1cImh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmtcIiB4PVwiMHB4XCIgeT1cIjBweFwiXG5cdCB3aWR0aD1cIjk3LjYxOXB4XCIgaGVpZ2h0PVwiOTcuNjE4cHhcIiB2aWV3Qm94PVwiMCAwIDk3LjYxOSA5Ny42MThcIiBzdHlsZT1cImVuYWJsZS1iYWNrZ3JvdW5kOm5ldyAwIDAgOTcuNjE5IDk3LjYxODtcIlxuXHQgeG1sOnNwYWNlPVwicHJlc2VydmVcIj5cbjxnPlxuXHQ8cGF0aCBkPVwiTTk2LjkzOSwxNy4zNThMODMuOTY4LDUuOTU5Yy0wLjM5OC0wLjM1Mi0wLjkyNy0wLjUzMS0xLjQ0OS0wLjQ5NEM4MS45OSw1LjUsODEuNDk2LDUuNzQzLDgxLjE0Niw2LjE0MkwzNC4xLDU5LjY4OFxuXHRcdEwxNy4zNzIsMzcuNTQ3Yy0wLjMxOS0wLjQyMi0wLjc5NC0wLjcwMS0xLjMxOS0wLjc3M2MtMC41MjQtMC4wNzgtMS4wNTksMC4wNjQtMS40ODEsMC4zODVMMC43OTQsNDcuNTY3XG5cdFx0Yy0wLjg4MSwwLjY2Ni0xLjA1NiwxLjkyLTAuMzksMi44MDFsMzAuOTc0LDQwLjk5NmMwLjM2MiwwLjQ3OSwwLjkyMiwwLjc3MSwxLjUyMiwwLjc5M2MwLjAyNCwwLDAuMDQ5LDAsMC4wNzMsMFxuXHRcdGMwLjU3NCwwLDEuMTIyLTAuMjQ2LDEuNTAzLTAuNjhsNjIuNjQ0LTcxLjI5N0M5Ny44NSwxOS4zNTEsOTcuNzY5LDE4LjA4Niw5Ni45MzksMTcuMzU4elwiLz5cbjwvZz48L3N2Zz5gXG4iLCJtb2R1bGUuZXhwb3J0cyA9IChwPXt9KSA9PiBgPHN2ZyB2ZXJzaW9uPVwiMS4xXCIgZGF0YS1qcz1cIiR7cC5uYW1lIHx8ICdlcnJvcid9XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHhtbG5zOnhsaW5rPVwiaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGlua1wiIHg9XCIwcHhcIiB5PVwiMHB4XCIgdmlld0JveD1cIjAgMCAxOC45NzggMTguOTc4XCIgc3R5bGU9XCJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDE4Ljk3OCAxOC45Nzg7XCIgeG1sOnNwYWNlPVwicHJlc2VydmVcIj5cclxuPGc+XHJcbiAgICA8cGF0aCBkPVwiTTE2LjA4OCwxLjY3NWMtMC4xMzMtMC4xMDQtMC4zMDYtMC4xNDQtMC40Ny0wLjEwNWMtMC4wMTMsMC4wMDItMS4yNjEsMC4yOS0yLjU5NCwwLjI5XHJcbiAgICAgICAgYy0xLjc4OCwwLTIuNzg5LTAuNDc2LTIuOTc1LTEuNDE1QzkuOTk5LDAuMTkxLDkuNzc5LDAuMDA3LDkuNTIxLDBjLTAuMjU3LTAuMDA3LTAuNDg3LDAuMTY3LTAuNTUsMC40MThcclxuICAgICAgICBDOC43MjcsMS4zODYsNy43MSwxLjg3Nyw1Ljk1LDEuODc3Yy0xLjMzMiwwLTIuNTcxLTAuMzAyLTIuNTgzLTAuMzA1Yy0wLjE2Ni0wLjA0LTAuMzQtMC4wMDQtMC40NzQsMC4xMDJcclxuICAgICAgICBDMi43NiwxLjc3NywyLjY4MSwxLjkzOCwyLjY4MSwyLjEwOHY0Ljg2OWMwLDAuMDQsMC4wMDQsMC4wNzgsMC4wMTMsMC4xMTVjMC4wNTcsMS42NDcsMC42NSw4LjcxNCw2LjUyOCwxMS44MjJcclxuICAgICAgICBjMC4wOCwwLjA0MywwLjE2OSwwLjA2NCwwLjI1OCwwLjA2NGMwLjA5MiwwLDAuMTgzLTAuMDIxLDAuMjY2LTAuMDY2YzUuNzQtMy4xMzcsNi40NDUtMTAuMTE1LDYuNTMyLTExLjc5MVxyXG4gICAgICAgIGMwLjAxMi0wLjA0NiwwLjAxOS0wLjA5NCwwLjAxOS0wLjE0NFYyLjEwOEMxNi4yOTcsMS45MzksMTYuMjE5LDEuNzgsMTYuMDg4LDEuNjc1eiBNMTUuMTksNi44NTdcclxuICAgICAgICBjLTAuMDA3LDAuMDMxLTAuMDEyLDAuMDY0LTAuMDEzLDAuMDk3Yy0wLjA1MywxLjI5OC0wLjU3NCw3LjgzMi01LjcwMSwxMC44MzhjLTUuMjE1LTIuOTY1LTUuNjQ2LTkuNTI2LTUuNjgtMTAuODNcclxuICAgICAgICBjMC0wLjAyOS0wLjAwNC0wLjA1OC0wLjAwOS0wLjA4NVYyLjc4NEM0LjMyMiwyLjg3Nyw1LjExMiwyLjk4Miw1Ljk1LDIuOTgyYzEuOTExLDAsMi45NjUtMC41NCwzLjUzNy0xLjIwOFxyXG4gICAgICAgIGMwLjU1MywwLjY2MSwxLjU5OSwxLjE5MSwzLjUzNiwxLjE5MWMwLjgzOSwwLDEuNjMxLTAuMTAxLDIuMTY2LTAuMTg4TDE1LjE5LDYuODU3TDE1LjE5LDYuODU3elwiLz5cclxuICAgIDxwb2x5Z29uIHBvaW50cz1cIjEwLjI0MSwxMS4yMzcgMTAuNTI5LDUuMzExIDguNDQ5LDUuMzExIDguNzUsMTEuMjM3IFx0XHRcIi8+XHJcbiAgICA8cGF0aCBkPVwiTTkuNDk2LDExLjg5MWMtMC42OTQsMC0xLjE3OCwwLjQ5OC0xLjE3OCwxLjE4OWMwLDAuNjgyLDAuNDcxLDEuMTkxLDEuMTc4LDEuMTkxXHJcbiAgICAgICAgYzAuNzA2LDAsMS4xNjQtMC41MSwxLjE2NC0xLjE5MUMxMC42NDcsMTIuMzg5LDEwLjE4OSwxMS44OTEsOS40OTYsMTEuODkxelwiLz5cclxuPC9nPjwvc3ZnPmBcclxuIiwibW9kdWxlLmV4cG9ydHMgPSBPYmplY3QuY3JlYXRlKCBPYmplY3QuYXNzaWduKCB7fSwgcmVxdWlyZSgnLi4vLi4vLi4vY2xpZW50L2pzL3ZpZXdzL19fcHJvdG9fXycpLCB7XG5cbiAgICBUb2FzdE1lc3NhZ2U6IHJlcXVpcmUoJy4vVG9hc3RNZXNzYWdlJyksXG5cbiAgICBuYW1lOiAnVG9hc3QnLFxuXG4gICAgcG9zdFJlbmRlcigpIHtcbiAgICAgICAgdGhpcy5tZXNzYWdlcyA9IHsgfVxuXG4gICAgICAgIHJldHVybiB0aGlzXG4gICAgfSxcblxuICAgIHJlcXVpcmVzTG9naW46IGZhbHNlLFxuXG4gICAgY3JlYXRlTWVzc2FnZSggdHlwZSwgbWVzc2FnZSApIHtcbiAgICAgICAgaWYoICF0aGlzLm1lc3NhZ2VzWyBtZXNzYWdlIF0gKSB0aGlzLm1lc3NhZ2VzWyBtZXNzYWdlIF0gPSBPYmplY3QuY3JlYXRlKCB0aGlzLlRvYXN0TWVzc2FnZSwge1xuICAgICAgICAgICAgaW5zZXJ0aW9uOiB7IHZhbHVlOiB7IGVsOiB0aGlzLmVscy5jb250YWluZXIgfSB9XG4gICAgICAgIH0gKS5jb25zdHJ1Y3RvcigpXG5cbiAgICAgICAgcmV0dXJuIHRoaXMubWVzc2FnZXNbIG1lc3NhZ2UgXS5zaG93TWVzc2FnZSggdHlwZSwgbWVzc2FnZSApXG5cbiAgICB9LFxuXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoJy4uL3RlbXBsYXRlcy9Ub2FzdCcpXG5cbn0gKSwgeyB9IClcbiIsIm1vZHVsZS5leHBvcnRzID0gT2JqZWN0LmFzc2lnbigge30sIHJlcXVpcmUoJy4uLy4uLy4uL2NsaWVudC9qcy92aWV3cy9fX3Byb3RvX18nKSwge1xuXG4gICAgbmFtZTogJ1RvYXN0TWVzc2FnZScsXG5cbiAgICBJY29uczoge1xuICAgICAgICBlcnJvcjogcmVxdWlyZSgnLi4vdGVtcGxhdGVzL2xpYi9lcnJvcicpKCksXG4gICAgICAgIHN1Y2Nlc3M6IHJlcXVpcmUoJy4uL3RlbXBsYXRlcy9saWIvY2hlY2ttYXJrJykoKVxuICAgIH0sXG5cbiAgICBwb3N0UmVuZGVyKCkge1xuXG4gICAgICAgIHRoaXMub24oICdzaG93bicsICgpID0+IHRoaXMuc3RhdHVzID0gJ3Nob3duJyApXG4gICAgICAgIHRoaXMub24oICdoaWRkZW4nLCAoKSA9PiB0aGlzLnN0YXR1cyA9ICdoaWRkZW4nIClcblxuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH0sXG5cbiAgICByZXF1aXJlc0xvZ2luOiBmYWxzZSxcblxuICAgIHNob3dNZXNzYWdlKCB0eXBlLCBtZXNzYWdlICkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoICggcmVzb2x2ZSwgcmVqZWN0ICkgID0+IHtcbiAgICAgICAgICAgIGlmKCAvc2hvdy8udGVzdCggdGhpcy5zdGF0dXMgKSApIHRoaXMudGVhcmRvd24oKVxuXG4gICAgICAgICAgICB0aGlzLnJlc29sdXRpb24gPSByZXNvbHZlXG5cbiAgICAgICAgICAgIGlmKCB0eXBlICE9PSAnZXJyb3InICkgdGhpcy5lbHMuY29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ3N1Y2Nlc3MnKVxuXG4gICAgICAgICAgICB0aGlzLmVscy5tZXNzYWdlLnRleHRDb250ZW50ID0gbWVzc2FnZVxuICAgICAgICAgICAgdGhpcy5lbHMudGl0bGUudGV4dENvbnRlbnQgPSB0eXBlID09PSAnZXJyb3InID8gJ0Vycm9yJyA6ICdTdWNjZXNzJ1xuICAgICAgICAgICAgdGhpcy5zbHVycFRlbXBsYXRlKCB7IGluc2VydGlvbjogeyBlbDogdGhpcy5lbHMuaWNvbiB9LCB0ZW1wbGF0ZTogdHlwZSA9PT0gJ2Vycm9yJyA/IHRoaXMuSWNvbnMuZXJyb3IgOiB0aGlzLkljb25zLnN1Y2Nlc3MgfSApXG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHRoaXMuc3RhdHVzID0gJ3Nob3dpbmcnXG5cbiAgICAgICAgICAgIHRoaXMuc2hvdyggdHJ1ZSApXG4gICAgICAgICAgICAudGhlbiggKCkgPT4gdGhpcy5oaWRlKCB0cnVlICkgKVxuICAgICAgICAgICAgLnRoZW4oICgpID0+IHRoaXMudGVhcmRvd24oKSApXG4gICAgICAgICAgICAuY2F0Y2goIHJlamVjdCApXG4gICAgICAgIH0gKVxuICAgIH0sXG5cbiAgICB0ZWFyZG93bigpIHtcbiAgICAgICAgaWYoIHRoaXMuZWxzLmNvbnRhaW5lci5jbGFzc0xpc3QuY29udGFpbnMoJ3N1Y2Nlc3MnKSApIHRoaXMuZWxzLmNvbnRhaW5lci5jbGFzc0xpc3QucmVtb3ZlKCdzdWNjZXNzJylcbiAgICAgICAgdGhpcy5lbHMubWVzc2FnZS50ZXh0Q29udGVudCA9ICcnXG4gICAgICAgIHRoaXMuZWxzLm1lc3NhZ2UudGl0bGUgPSAnJ1xuICAgICAgICBpZiggdGhpcy5lbHMuaWNvbi5maXJzdENoaWxkICkgdGhpcy5lbHMuaWNvbi5yZW1vdmVDaGlsZCggdGhpcy5lbHMuaWNvbi5maXJzdENoaWxkIClcbiAgICAgICAgdGhpcy5yZXNvbHV0aW9uKClcbiAgICB9LFxuXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoJy4uL3RlbXBsYXRlcy9Ub2FzdE1lc3NhZ2UnKVxuXG59ICkiXX0=
